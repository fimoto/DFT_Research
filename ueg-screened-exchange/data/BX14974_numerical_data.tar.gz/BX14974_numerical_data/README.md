# Numerical data for RPA-screened second-order exchange in the uniform electron gas

Fumihiro Imoto

These data accompany *Low- and high-density asymptotics of RPA-screened second-order exchange in the spin-polarized uniform electron gas*. Here `rs` is the Wigner–Seitz radius in Bohr and `zeta` is the relative spin polarization. Energy fields ending in `_ry` and `_mry` are in Ry and mRy per electron, respectively.

To **run the direct kite integral** at one density and polarization, follow sections 1–2. To **repeat a published calculation on an HPC system**, use section 3 and the input guide in section 4. To **recover tables or inspect the interpolation using the supplied results**, go to section 5.

## 1. Set up Python

Unpack the archive on a filesystem visible to the compute nodes. All paths and commands below are relative to the extracted `BX14974_numerical_data/` directory.

```sh
tar -xzf BX14974_numerical_data.tar.gz
cd BX14974_numerical_data
```

Prepare the Python environment once, on a machine where packages can be installed. The following setup uses the versions recorded for the direct QMC runs.

```sh
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r code/original/requirements-tested.txt matplotlib
mkdir -p recomputed
```

A site-provided environment with these packages also works. For that option, create the output directory with `mkdir -p recomputed`. The original and follow-up QMC calculations used NumPy 2.3.5 and SciPy 1.17.0. The corrected ring runs 35–37 used NumPy 2.5.4 and SciPy 1.18.1. To match those runs, use a separate environment with those two versions. Each published run records its Python and library versions under `runtime` in its `manifest.json`. Matplotlib is used for figures.

## 2. Try the nine-dimensional quasi-Monte Carlo (QMC) integral

The direct integrand is `evaluate_term()` in **`code/original/vendor/external/benites_direct.py`**. It implements the two terms in Eqs. (28) and (29) of Benites, Rosado, and Manousakis (BRM), *Phys. Rev. B* **110**, 195151 (2024). Rotational symmetry lets the code orient the first momentum along the *z* axis. The remaining nine Sobol coordinates sample the coupling constant, the momenta and the mapped frequency. Each term has its own scrambled Sobol sequence. The full kite energy is the sum of both term means and the bare second-order exchange constant. Runs 50 and 51 provide a separate imaginary-frequency-axis check through `vendor/spin/reviewer_numerics.py` in their respective kits.

For one point, the module can be called directly. The following example takes four independent scrambles of 4,096 points **per term** at `rs=5`, `zeta=0`.

```sh
python code/original/vendor/external/benites_direct.py \
  --rs 5 --zeta 0 --m 12 --replicates 4 --seed 19 \
  --out recomputed/single_point.json
```

The JSON gives the two contributions in Ry and the full energy and sampling error in mRy. With the QMC environment above, the terminal prints `full kite = 5.3682 +- 1.6486 mRy` to the displayed precision. This small example checks the installation. Production inputs use more points and scrambles.

For production QMC, **`scripts/run.py` in the corresponding code kit** calls the same integrand from `qmc_task()`. It evaluates Sobol points in blocks and saves progress during each scramble. The input's `powers` are the exponents `m` that select `2**m` points per term, `replicates` is the number of scrambles, and `chunk_power` sets the block size. Estimates at increasing powers use prefixes of the same point sequence. In low-density groups with `references`, the code evaluates the target and reference at the same Sobol points and accumulates their difference before averaging.

## 3. Run and check an HPC calculation

There are three stages. `plan.py` expands an input JSON into a numbered list of tasks and seeds. `run.py` executes the tasks and writes one `raw/NNNNNNN.json` per completed task. `analyze.py` matches each record to its manifest, checks for missing tasks, and combines the independent scrambles.

### Small end-to-end test

From the archive root, run the following commands with the environment active and two CPUs available.

```sh
kit=code/original
run=recomputed/smoke
python "$kit/scripts/plan.py" "$kit/inputs/smoke/00_smoke.json" --run "$run"
python "$kit/scripts/run.py" --run "$run" --workers 2
python "$kit/scripts/analyze.py" --run "$run"
cat "$run/analysis/completion.json"
```

The expected report has `expected: 116`, `completed: 116` and `missing: []`. Use `--workers 1` on a single CPU.

### Production example, low-density run 10

Request one compute node with the desired number of CPU cores. Use the following commands as the body of the site's batch job, with the working directory set to the archive root. The example assumes 16 allocated cores. If the site supplies Python through modules, use its activation command in the job. Launch one Python driver with those cores on the same node. Its `--workers` option starts local Python processes. MPI is unnecessary. The worker count controls how many tasks run concurrently. Their sample sizes and seeds come from the input.

```sh
set -e
. .venv/bin/activate
workers=16
kit=code/original
run=recomputed/hpc_10_low_density

python "$kit/scripts/plan.py" "$kit/inputs/hpc/10_low_density.json" --run "$run"
python -u "$kit/scripts/run.py" --run "$run" --workers "$workers" >> "$run/execution.log" 2>&1
python "$kit/scripts/analyze.py" --run "$run"
cat "$run/analysis/completion.json"
```

The plan should contain **192 tasks** (three densities × 64 scrambles). While it runs, `python code/original/scripts/status.py --run recomputed/hpc_10_low_density` shows progress by group. On completion, open `analysis/energies.csv` inside the new run. For `rs=100000000`, `zeta=0`, `m=22`, `R=64`, the published `difference_ref_1e+30` row gives **−2.157569379 mRy** with a sampling error of **0.000583131 mRy**. This column is the paired difference. The low-density table adds the finite-reference energy from the three-term asymptote, giving **−2.157576380 mRy** for the same row.

**For a shorter comparison at production precision**, run just task 0 after planning, using `python "$kit/scripts/run.py" --run "$run" --task 0`. Compare `task` and `term_means` in the new `raw/0000000.json` with the same file under `results/original/hpc_10_low_density/`. The arrays contain the two term means at each requested power. Timings and run fingerprints can differ between environments. Starting the full driver afterwards skips this completed task.

**To resume after a wall-time limit**, reactivate the same environment and repeat the `run.py` command with the same run directory. Completed records are skipped, and interrupted direct-QMC tasks read their last saved checkpoint. If a hard stop leaves a task locked, first confirm its worker has exited, then remove only the empty `locks/<task-id>` directory named in the error. Use a new output directory for a change in input, source, or numerical environment. Keep `results/` as the published reference for comparisons.

For a multi-node job array, generate the manifest once on shared storage. Assign each array element a distinct **zero-based** manifest task ID and invoke `python "$kit/scripts/run.py" --run "$run" --task "$task_id" --workers 1`. For run 10 these IDs are 0–191. Run `analyze.py` once after all elements finish. The unfiltered `--workers` command above schedules the entire run on one host.

## 4. Select the input and postprocessing

`DATASETS.csv` indexes all 20 published data sets. For a new integration, take **the planner, driver and analyzer from the same kit**. In the run 10 example, change `kit`, the input path and the output directory together.

| Run(s) | Code kit | Input location within kit | Calculation |
|---|---|---|---|
| 10, 11, 12, 13 | `code/original` | `inputs/hpc/` (see run 13 below) | Low-density convergence, reference densities and momentum maps |
| 20, 30, 31, 32 | `code/original` | `inputs/hpc/` | High-density expansion, endpoint crossing, spin scan and curvatures |
| 40, 50 | `code/original` | `inputs/hpc/` | Energy grid for fitting (40) and independent imaginary-axis check (50) |
| 14, 33, 34, 51 | `code/followup` | `inputs/` | Second low-density map, refined spin and density grids, imaginary-axis resolution |
| 35, 36, 37 | `code/corrected_ring` | `inputs/` | Final ring contributions to the crossing, spin curvature and density curvature |
| 41 | `code/followup` | Options to `postprocess.py` | Coefficient quadrature and fits to saved data |
| 42, 43 | `code/corrected_ring/validation` | `inputs/` | Direct kite energies at 38 previously unused points and a second-map check at eight of them |

For additional per-run reports, execute the following after `analyze.py`, using the same `kit` and `run`. Run 20 uses `python "$kit/scripts/high_density.py" --run "$run" --bootstrap 1000`. Runs 14, 33, 34 and 51 use `python "$kit/scripts/followup_report.py" --run "$run"`. Their reports are written under `$run/analysis/`.

### Low-density run 13

Its exact input is stored in the published manifest. Extract the `input` object and plan a fresh run as follows. Then use the run and analysis commands from section 3.

```sh
kit=code/original
run=recomputed/hpc_13_low_density_precision
python - <<'PY'
import json
from pathlib import Path
manifest = Path("results/original/hpc_13_low_density_precision/manifest.json")
out = Path("recomputed/13_low_density_precision.json")
out.write_text(json.dumps(json.loads(manifest.read_text())["input"], indent=2) + "\n")
PY
python "$kit/scripts/plan.py" recomputed/13_low_density_precision.json --run "$run"
```

Expect 256 tasks. In this input the largest power is 27. A single complete scramble uses 134,217,728 points per term at the target and at each specified reference density.

### Final ring calculations, runs 35–37

Use `35_ring_transition.json`, `36_ring_spin_curvature.json` or `37_ring_density_curvature.json` from `code/corrected_ring/inputs/`, with `kit=code/corrected_ring`. Here `scripts/ring.py` evaluates deterministic panel quadratures, including the analytic density derivative. A plan showing zero QMC evaluations is expected. After `analyze.py`, run `python "$kit/scripts/ring_report.py" --run "$run"`. The final output is `analysis/corrected_ring_report.json`. For runs 35–36 the report reads the archived kite ensembles from run 33; for run 37 it reads those from run 34. Both snapshots are supplied in `code/corrected_ring/previous/`. To combine newly computed kite and ring data, copy the corrected ring kit to a working directory and place the new `ensembles.json` and `replicates.npz` in the corresponding `previous/` subdirectories **before planning**.

### Coefficient quadrature, run 41

This calculation reads the supplied run 40 fit ensembles and run 20 high-density data in `code/followup/previous/`. From the archive root, run

```sh
python code/followup/scripts/postprocess.py --run recomputed/hpc_41_fit_and_coefficients \
  --orders 80 160 240 --bootstrap 500 --workers 1
```

Set the worker count to the allocated cores. `summary.json` records completion and `coefficient_convergence.json` compares quadrature orders. The fit produced here is an earlier candidate. The paper's adopted six-parameter interpolation is in `models/compact6/`.

### Frozen interpolation test, runs 42–43

Run 42 supplies 38 new direct estimates. Run 43 repeats eight points using a different momentum map. For fresh integrations, use the validation subdirectory's own driver. Set the worker count to your allocation.

```sh
set -e
kit=code/corrected_ring/validation
workers=1
for name in 42_frozen_validation 43_validation_map4; do
  run="recomputed/local_$name"
  python "$kit/scripts/plan.py" "$kit/inputs/$name.json" --run "$run"
  python -u "$kit/scripts/run.py" --run "$run" --workers "$workers" >> "$run/execution.log" 2>&1
  python "$kit/scripts/analyze.py" --run "$run"
done
```

After both finish, compare the estimates with the fixed predictions.

```sh
python code/corrected_ring/scripts/validate_frozen.py \
  --primary recomputed/local_42_frozen_validation \
  --map-check recomputed/local_43_validation_map4 \
  --out recomputed/frozen_validation
```

To use the published integrations directly, substitute `results/local_validation/` for the two input directory prefixes. The 38-point root-mean-square residuals in `validation_results.json` are **0.0780 mRy** for the six-parameter model and **0.6995 mRy** for the published BRM parametrization.

## 5. Read the outputs and regenerate the published tables

| File or directory | Contents |
|---|---|
| `results/<family>/<run>/manifest.json` | Run configuration, software versions and, for integrations, the ordered task list and seeds where applicable |
| `raw/` within an integration run | One JSON record per task. For direct QMC a record contains term means by sample size. |
| `analysis/` within a run | `completion.json` gives task counts. For direct QMC, `energies.csv` gives means and sampling errors, `ensembles.json` gives covariance matrices, and `replicates.npz` retains the term estimates for paired analyses. Ring and imaginary-axis records are collected in `ring.json` and `axis.json`. |
| `analysis/tables/numerical_summary.json` at the archive root | Low- and high-density results, fit uncertainties and the endpoint crossing |
| `analysis/ring_convergence.json` | Ring-order, spin-window and density-step comparisons |
| `models/compact6/`, `models/BRM_comparison/` | Energy evaluator and coefficients for the adopted fit, and comparison with BRM Eq. (58) on the fit data |
| `code/corrected_ring/validation/results/validation_points.csv` | Direct energies, sampling errors and residuals for both formulas at each validation point |

From the archive root, the following commands reproduce the summary tables and validation figure from the distributed data, then independently reintegrate one highest-order ring point from each of runs 35–37.

```sh
python analysis/recompute_tables.py --data-root . --output recomputed/tables
python analysis/plot_validation.py --data-root . --output-dir recomputed/figures
python analysis/check_selected_integrals.py recomputed
```

To regenerate all three ring reports from their saved records:

```sh
mkdir -p recomputed/ring
cp -R results/corrected_ring/. recomputed/ring/
for run in recomputed/ring/hpc_*; do
  python code/corrected_ring/scripts/analyze.py --run "$run"
  python code/corrected_ring/scripts/ring_report.py --run "$run"
done
```

`python analysis/check_finite_part.py recomputed` independently repeats the coefficient quadrature at orders 80, 160 and 240. Monte Carlo standard errors come from the variation across independent scrambles. The stored replicates preserve shared random numbers across points for energy differences and derivatives. Ring quadrature convergence and the dependence on the differentiation window or step are reported separately.
