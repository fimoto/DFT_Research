"""Independent one-dimensional evaluation of B1 after analytically integrating ck.
G(x,y)-G(x,x) = Re[i*z*x*(y-x)/((x+i*z)^2*(y+i*z))].
The ck integral of sign(y-x)/(y+i*z) is log(1+i*z)+log(-1+i*z)-2*log(x+i*z).
Parity reduces cp to 0..1; no subtraction of two nearly equal G values remains.
"""
from pathlib import Path
import sys,json,math,warnings,numpy as np
from scipy.integrate import quad,IntegrationWarning
root = Path(__file__).resolve().parents[1]
KIT = root / 'code/followup'
BASE = root / 'results/followup'
WORK = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('recomputed')
WORK.mkdir(parents=True, exist_ok=True)
sys.path.insert(0,str(KIT/'scripts'))
from coefficients import values,H

def finite(z):
 def f1(x):
  den=x*x+z*z
  return (2*z*z*x*x*np.log1p((1-x*x)/den)-2*z*x*(x*x-z*z)*np.arctan(x/z))/(den*den)
 def f2(x):
  return x*x*(x*x-z*z)/(x*x+z*z)**2*(math.log(2)+1.5-math.log(x))
 opts={'epsabs':1e-12,'epsrel':2e-12,'limit':400,'points':[z] if z<1 else None}
 b1,e1=quad(f1,0,1,**opts);b2,e2=quad(f2,0,1,**opts)
 return 4*math.pi**2*b1+8*math.pi**2*b2,4*math.pi**2*e1+8*math.pi**2*e2
rows=[];capture=[]
with warnings.catch_warnings(record=True) as ww:
 warnings.simplefilter('always',IntegrationWarning)
 for n in [80,160,240]:
  orig=json.load(open(BASE/f'hpc_41_fit_and_coefficients/coefficients_{n}.json'));c=dict(orig);res=[finite(z) for z in c['z']];c['b']=[v for v,e in res];cs={}
  for z in [0,.2,.3,.4,.6,.7,.8,.9,1]:
   old=values(z,orig)[1];new=values(z,c)[1];cs[str(z)]={'original_c1':old,'new_c1':new,'difference':new-old}
  rows.append({'order':n,'max_abs_b_difference':float(np.max(abs(np.array(c['b'])-orig['b']))),'max_reported_b_quad_error':max(e for v,e in res),'c1':cs})
  print(rows[-1],flush=True)
 capture=[str(w.message) for w in ww]
(WORK/'finite_part_convergence.json').write_text(json.dumps({'orders':rows,'warnings':capture},indent=2)+'\n')
