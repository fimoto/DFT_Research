"""Direct rerun of three highest-order HPC task results on the local machine."""
from pathlib import Path
import sys,json,time
BASE = Path(__file__).resolve().parents[1]
KIT = BASE / 'code/corrected_ring'
RUNS = BASE / 'results/corrected_ring'
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('recomputed')
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0,str(KIT/'scripts'))
from ring import ring_observables,curvature_kernel
checks=[]
for run,rs,z in [('hpc_35_ring_transition',450.,.995),('hpc_36_ring_spin_curvature',32.,0.),('hpc_37_ring_density_curvature',70.,1.)]:
 rows=json.loads((RUNS/run/'analysis/ring.json').read_text())
 raw=next(r for r in rows if (r['task']['rs'],r['task']['zeta'],r['task']['n'],r['task']['span'])==(rs,z,320,1.25))
 start=time.monotonic();fresh=ring_observables(rs,z,320,1.25)
 checks.append({'run':run,'rs':rs,'zeta':z,'n':320,'span':1.25,'energy_delta_mry':1000*(fresh['energy_ry']-raw['energy_ry']),'density_curvature_delta_mry':1000*(fresh['density_curvature_ry']-raw['density_curvature_ry']),'wall_seconds':time.monotonic()-start})
 assert abs(checks[-1]['energy_delta_mry'])<1e-9 and abs(checks[-1]['density_curvature_delta_mry'])<1e-9
(OUT/'selected_integrals.json').write_text(json.dumps({'passed':True,'checks':checks},indent=2)+'\n')
print(json.dumps(checks,indent=2))
