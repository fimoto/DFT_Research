from pathlib import Path
import sys,json,hashlib,argparse
import numpy as np
from scipy.stats import norm
ap=argparse.ArgumentParser(description='Recompute tables from the supplied submission evidence archive.');ap.add_argument('--data-root',type=Path);ap.add_argument('--output',type=Path);args=ap.parse_args()
ROOT=(args.data_root or Path(__file__).resolve().parents[1]).resolve()
if args.data_root is None and not (ROOT/'results/original').exists(): ROOT=Path(__file__).resolve().parents[3]
archived=(ROOT/'results/original').exists()
ORIGINAL=ROOT/'results/original' if archived else ROOT/'review_all/runs'
FOLLOWUP=ROOT/'results/followup' if archived else ROOT/'review_followup/runs'
CODE=ROOT/'code/original' if archived else ROOT/'output/BX14974_additional_calculations'
sys.path.insert(0,str(CODE/'scripts'))
from common import E2X,asymptotic_kite
from high_density import regress
P=(args.output or Path(__file__).resolve().parent).resolve();P.mkdir(parents=True,exist_ok=True)
runs={'10':ORIGINAL/'hpc_10_low_density','13':ORIGINAL/'hpc_13_low_density_precision','14':FOLLOWUP/'hpc_14_low_density_map4','20':ORIGINAL/'hpc_20_high_density'}
out={'units':'LD energies mRy; HD coefficients Ry and covariances Ry^2','source_files':{},'low_density':{},'high_density':{}}
for name,r in runs.items():
 for f in ['analysis/ensembles.json','analysis/replicates.npz','manifest.json']:
  p=r/f;out['source_files'][str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
def ld(name,group,powers,counts=None):
 r=runs[name];ens=json.loads((r/'analysis/ensembles.json').read_text());arr=np.load(r/'analysis/replicates.npz');rows=[]
 for power in powers:
  key=f'{group}__m{power}__difference_ref_1e+30';e=ens[key];t=arr[key];assert e['constant_ry']==0
  for R in (counts or [len(t)]):
   a=t[:R];mean=a.mean(0).sum(0)+asymptotic_kite(1e30,0);se=np.sqrt(a.var(0,ddof=1).sum(0)/R)
   for i,(rs,z) in enumerate(e['points']):rows.append({'run':name,'group':group,'rs':rs,'zeta':z,'N_power':power,'R':R,'mean_mry':1000*float(mean[i]),'se_mry':1000*float(se[i]),'reference_correction_mry':1000*float(asymptotic_kite(1e30,0)),'three_term_mry':1000*float(asymptotic_kite(rs,z))})
 return rows
out['low_density']['N_table_10']=ld('10','low_density',[15,17,19,21,22])
out['low_density']['R_table_10']=ld('10','low_density',[22],[8,16,32,64])
out['low_density']['N_table_13']=ld('13','low_density_precision',[21,23,25,27])
out['low_density']['R_table_13']=ld('13','low_density_precision',[27],[32,64,128,256])
out['low_density']['map4_final']=ld('14','low_density_map4',[27])+ld('14','low_density_map4_1e6',[24])
out['low_density']['reference_note']='Finite reference energy at 1e30 restored using the three-term asymptote; correction is model-based, not an independently integrated exact expectation. R prefixes and N rows share samples and are not independent tests.'
r=runs['20'];ens=json.loads((r/'analysis/ensembles.json').read_text());a=np.load(r/'analysis/replicates.npz');key='high_density__m20__direct';e=ens[key];t=a[key];rr=np.array(e['points'])[:,0];mu=t.mean(0).sum(0);cov=np.diag(t.var(0,ddof=1).sum(0)/len(t));assert e['independent_points'];np.testing.assert_allclose(mu+E2X,e['mean_ry'],atol=2e-14,rtol=0);np.testing.assert_allclose(cov,e['covariance_mean_ry2'],atol=1e-25,rtol=1e-12)
for rmin in [.0001,.001]:
 for rmax in [.001,.003,.01,.03,.1]:
  m=(rr>=rmin)&(rr<=rmax)
  if m.sum()<3:continue
  fits={v:regress(rr[m],mu[m],cov[np.ix_(m,m)],v) for v in ['free','null','fixed','remainder_r2','remainder_log2']}
  f=fits['free'];f['observed_chd_z']=f['coef'][0]/f['se'][0];f['observed_normal_two_sided_p']=float(2*norm.sf(abs(f['observed_chd_z'])));f['delta_Q_null']=fits['null']['Q']-f['Q']
  out['high_density'][f'{rmin:g}_{rmax:g}']={'rmin':rmin,'rmax':rmax,'n_points':int(m.sum()),'R':len(t),'N_power':20,'independent_points':True,**fits}
out['high_density_notes']=['The 11 independent-density production nodes start at 1e-4, unlike the original 1e-3 pilot. Both lower limits are explicitly tabulated.','GLS uses full supplied covariance, diagonal by construction because seeds are disjoint across density. No covariance rescaling by Q/dof.','Conditional normal power assumes the chosen finite-density regression is correct and the estimated covariance is known. It is not unconditional finite-sample power or a bound on omitted terms.','Remainder r^2 and r^2 ln^2 r are sensitivity models, not derived remainder orders. At rmax=.01 the latter reduces the nominal chd significance to ~2 SE.','The high-density logarithmic coefficient is derived analytically; fits provide supporting tests with an explicit model-dependence qualification.']
fpfile=Path(__file__).resolve().with_name('finite_part_audit.json');fp=json.loads(fpfile.read_text());out['finite_part']={'source':'output/BX14974_followup_review/results/finite_part_audit.json','max_c1_change_after_stable_reintegration':max(abs(v['difference']) for row in fp['orders'] for v in row['c1'].values()),'c1_unpolarized_order240':fp['orders'][-1]['c1']['0'],'warning':'Some auxiliary b evaluations produced warnings at order240, but a stable reintegration changes assembled c1 by <=2.53e-12 Ry. This is not evidence for a significant c1 error.'}
# Final low-density differences retain paired covariance between reference choices.
out['low_density']['reference_limit_checks']=[]
for name,group,power in [('13','low_density_precision',27),('14','low_density_map4',27)]:
    rr=runs[name];arr=np.load(rr/'analysis/replicates.npz');diff=arr[f'{group}__m{power}__difference_ref_1e+24']-arr[f'{group}__m{power}__difference_ref_1e+30'];value=diff.mean(0).sum(0)+asymptotic_kite(1e24,0)-asymptotic_kite(1e30,0);se=np.sqrt(diff.var(0,ddof=1).sum(0)/len(diff));out['low_density']['reference_limit_checks'].append({'run':name,'group':group,'power':power,'corrected_ref24_minus_ref30_mry':(1000*value).tolist(),'paired_se_mry':(1000*se).tolist()})
# Coefficient decomposition is independently explicit in the frozen model's theory; obtain LD term from total-density power.
from math import gamma
alpha=(4/(9*np.pi))**(1/3);qtf=4*alpha/np.pi
A3=-16408/3375*np.sqrt(2*np.pi)/np.pi**2*gamma(.75)/gamma(.25)
L3=A3/(4*qtf/3)**.75
out['low_density']['third_term_tests']=[]
for row in out['low_density']['map4_final']:
    r=row['rs'];third=1000*L3*r**(-.75);three=row['three_term_mry'];two=three-third
    out['low_density']['third_term_tests'].append({'rs':r,'three_term_mry':three,'two_term_mry':two,'third_term_mry':third,'mean_minus_three_over_se':(row['mean_mry']-three)/row['se_mry'],'mean_minus_two_over_se':(row['mean_mry']-two)/row['se_mry']})
# Recompute the endpoint crossing from completed HPC35 raw ring values and HPC33 kite means.
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq
from common import hf
ens33=json.loads((FOLLOWUP/'hpc_33_spin_and_transition/analysis/ensembles.json').read_text())
e33=ens33['spin_precision__m22__direct']
pts=list(map(tuple,e33['points']))
mu=np.array(e33['mean_ry'])
rs=sorted({r for r,z in pts})
dy=np.array([mu[pts.index((r,1))]-mu[pts.index((r,0))] for r in rs])
x=np.log(rs)
ring_run=ROOT/'results/corrected_ring/hpc_35_ring_transition'
ring_rows=[json.loads(p.read_text()) for p in sorted((ring_run/'raw').glob('*.json'))]
ring={(v['task']['n'],v['task']['span'],v['task']['rs'],v['task']['zeta']):v['energy_ry'] for v in ring_rows}
fixed=np.array([hf(r,1)-hf(r,0)+ring[320,1.25,r,1]-ring[320,1.25,r,0] for r in rs])
report=json.loads((ring_run/'analysis/corrected_ring_report.json').read_text())
production=next(v for v in report['endpoint_crossings'] if v['power']==22 and v['n']==320 and v['span']==1.25)
computed=float(np.exp(brentq(PchipInterpolator(x,dy+fixed),x[0],x[-1])))
assert abs(computed-production['rs_crossing'])<1e-9
out['endpoint_crossings']={
    'kite_only_rs':float(np.exp(brentq(PchipInterpolator(x,dy),x[0],x[-1]))),
    'total_with_formal_corrected_ring_rs':computed,
    'sampling_interval_95':production['sampling_interval_95'],
    'bootstrap_valid':production['bootstrap_valid'],
    'bootstrap_total':production['bootstrap_total'],
    'ring_order':320,
    'ring_span':1.25,
    'status':'Completed HPC33 kite and formal HPC35 ring. The sampling interval is the archived 1000-bootstrap result. Ring convergence is assessed separately.',
    'interpolation':'PCHIP in log(rs), seven nodes 440 to470',
    'kite_source':'results/followup/hpc_33_spin_and_transition/analysis/ensembles.json',
    'ring_source':'results/corrected_ring/hpc_35_ring_transition/raw/',
    'bootstrap_source':'results/corrected_ring/hpc_35_ring_transition/analysis/corrected_ring_report.json'
}
for f in [ring_run/'manifest.json',ring_run/'analysis/corrected_ring_report.json']:
    out['source_files'][str(f.relative_to(ROOT))]=hashlib.sha256(f.read_bytes()).hexdigest()

(P/'numerical_evidence.json').write_text(json.dumps(out,indent=2)+'\n')
lines=[]
for k,v in out['low_density'].items():
 if not isinstance(v,list) or (v and 'N_power' not in v[0]):continue
 lines.append(k)
 for row in v:lines.append(f"r={row['rs']:g} m={row['N_power']} R={row['R']}: {row['mean_mry']:.9f} +/- {row['se_mry']:.9f}")
for k,v in out['high_density'].items():
 f=v['free'];lines.append(f"HD {k}: {f['coef']} +/- {f['se']}; Q/dof={f['Q']}/{f['dof']}, corr01={f['corr'][0][1]}, power={f['conditional_power_5pct']}, observedz={f['observed_chd_z']}")
lines+=out['high_density_notes'];lines+=[str(out['finite_part'])]
(P/'numerical_evidence.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
# Compact ready-to-copy tables, no surrounding float or cross-document labels.
tex=['% Generated from numerical_evidence.json. Energies mRy; all corrections restored.','\\begin{tabular}{crrr}\\toprule','$m$ & $r_s=10^6$ & $r_s=10^7$ & $r_s=10^8$\\\\\\midrule']
for m in [15,17,19,21,22]:
 rows=[v for v in out['low_density']['N_table_10'] if v['N_power']==m];tex.append(str(m)+' & '+' & '.join(f"${v['mean_mry']:.6f}\\pm{v['se_mry']:.6f}$" for v in rows)+'\\\\')
tex+=['\\bottomrule\\end{tabular}','% R=64, fixed scale2; N=2^m per term.']
(P/'low_density_N_table.tex').write_text('\n'.join(tex)+'\n')
