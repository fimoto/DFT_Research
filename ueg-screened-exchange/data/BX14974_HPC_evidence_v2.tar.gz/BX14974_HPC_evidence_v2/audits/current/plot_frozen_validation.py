from pathlib import Path
import csv
import argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
parser=argparse.ArgumentParser(description='Reproduce the frozen validation figure from the data archive.')
parser.add_argument('--data-root', type=Path, required=True)
parser.add_argument('--output-dir', type=Path, default=Path('.'))
args=parser.parse_args()
p=args.data_root/'code/corrected_ring/validation/results'
out=args.output_dir
out.mkdir(parents=True,exist_ok=True)
r=list(csv.DictReader((p/'validation_points.csv').open()));x=np.array([float(v['rs']) for v in r]);e=np.array([float(v['compact_residual_mry']) for v in r]);b=np.array([float(v['BRM_residual_mry']) for v in r]);se=np.array([float(v['sampling_SE_mry']) for v in r])
plt.rcParams.update({'font.family':'serif','font.size':9,'axes.labelsize':9,'legend.fontsize':8,'xtick.labelsize':8,'ytick.labelsize':8,'pdf.fonttype':42})
f,ax=plt.subplots(2,1,figsize=(6.3,4.8),sharex=True);f.subplots_adjust(left=.12,right=.98,bottom=.11,top=.98,hspace=.1)
ax[0].scatter(x,abs(b),marker='x',s=21,color='#d55e00',label='BRM Eqs. (58) and (59)');ax[0].scatter(x,abs(e),s=12,color='#0072b2',label='Six-constant expression');ax[0].set_yscale('log');ax[0].set_ylabel('Absolute residual (mRy)');ax[0].legend(loc='upper left')
ax[1].errorbar(x,e,yerr=2*se,fmt='o',ms=2.5,lw=.6,color='#0072b2',label='Six-constant expression');ax[1].axhline(0,color='0.5',lw=.5);ax[1].set_ylabel('Signed residual (mRy)');ax[1].set_xlabel(r'$r_s$')
for a in ax:a.set_xscale('log');a.grid(alpha=.15)
f.savefig(out/'fig_frozen_validation.pdf',metadata={'CreationDate':None})
f.savefig(out/'fig_frozen_validation.png',dpi=130)
