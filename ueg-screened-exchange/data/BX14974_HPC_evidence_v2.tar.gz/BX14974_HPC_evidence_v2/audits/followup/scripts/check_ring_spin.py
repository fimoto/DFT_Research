"""Audit-only panel quadrature for spin curvatures and endpoint crossings."""
import sys,json,time,numpy as np
from pathlib import Path
from audit_paths import ROOT as root,KIT,BASE,WORK
sys.path.insert(0,str(KIT/'scripts'))
from common import ALPHA_L,hf
from ring import log1pmx
from ueg_exchange.constants import q_tf_sq
from ueg_exchange.lindhard import lindhard_shape
from scipy.special import roots_legendre
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq
from functools import lru_cache
@lru_cache(None)
def nodes(n):return roots_legendre(n)
def grid(edges,n):
 x,w=nodes(n);a=[];b=[]
 for lo,hi in zip(edges[:-1],edges[1:]):
  l,h=np.log(lo),np.log(hi);v=np.exp(l+(x+1)*(h-l)/2);a.extend(v);b.extend(w*(h-l)/2*v)
 return np.array(a),np.array(b)
def energy(rs,z,n,span):
 Q2=q_tf_sq(rs);sq=max(1.,Q2**.25);sn=max(1.,np.sqrt(Q2/3));xs=[x for x in [(1+z)**(1/3),(1-z)**(1/3)] if x>0]
 q,wq=grid(sorted(set([sq*10**(-7*span),sq*10**(7*span)]+[c*x for x in xs for c in [.15,2,3]])),n)
 nu,wn=grid(sorted(set([sn*10**(-8*span),1e-4,1e-2,1.,sn,sn*10**(9*span)])),n);total=0.
 for k in range(0,len(q),8):
  qq=q[k:k+8,None];nn=nu[None,:];L=sum(.5*x*lindhard_shape(qq/x,nn/x**2) for x in xs);c=Q2*L/qq**2
  total+=np.sum((wq[k:k+8]*q[k:k+8]**2)[:,None]*wn[None,:]*log1pmx(c))
 return float(3/(4*np.pi)*2/(ALPHA_L*rs)**2*total)
rows=[]
for rs in [32,60,70,75,110]:
 for z in [0,.01,.02,.04,.06,.1,.15,.2]:
  for n,s in [(160,1.25),(240,1.25)]+([(240,1.)] if rs==70 else []):
   e=energy(rs,z,n,s);rows.append(dict(rs=rs,zeta=z,n=n,span=s,energy_ry=e))
 print('curvature density',rs,'complete',flush=True)
 (WORK/'ring_spin_energy_audit.json').write_text(json.dumps(rows,indent=2)+'\n')
for rs in [440,450,452.5,455,457.5,460,470]:
 for z in [0,1]:
  for n in [160,240]:rows.append(dict(rs=rs,zeta=z,n=n,span=1.25,energy_ry=energy(rs,z,n,1.25)))
 print('endpoint density',rs,'complete',flush=True)
 (WORK/'ring_spin_energy_audit.json').write_text(json.dumps(rows,indent=2)+'\n')
# Density curvature formula cross-check by a finite-difference of panel energies.
h=.01;rs=70;es=np.array([energy(rs*np.exp(j*h),1,240,1.25) for j in [-2,-1,0,1,2]]);w=(np.array([-1,16,-30,16,-1])/(12*h*h)-3*np.array([1,-8,0,8,-1])/(12*h))/9
(WORK/'ring_density_finite_diff_check.json').write_text(json.dumps({'rs':rs,'h':h,'K_ring_mry':float(1000*(es-es[2])@w)},indent=2)+'\n')
