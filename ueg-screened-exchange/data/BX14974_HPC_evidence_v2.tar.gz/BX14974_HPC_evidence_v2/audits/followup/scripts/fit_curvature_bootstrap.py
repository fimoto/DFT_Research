import sys,json,numpy as np
from pathlib import Path
from audit_paths import ROOT as root,KIT,BASE,WORK
sys.path.insert(0,str(KIT/'scripts'))
from common import E2X
from fit import endpoint,endpoint_fit,A
from analyze import bootstrap
p=KIT/'previous/hpc_40_global_fit/analysis';ee=json.load(open(p/'ensembles.json'));aa=np.load(p/'replicates.npz');key=max([k for k,v in ee.items() if v['group']=='fit_train' and v['column']=='direct'],key=lambda k:ee[k]['power']);e=ee[key];pts=np.array(e['points']);sel=pts[:,1]==0;r=pts[sel,0];se=np.sqrt(np.diag(e['covariance_mean_ry2']))[sel]
f=json.load(open(BASE/'hpc_41_fit_and_coefficients/fit_order_240/fit_results.json'));c1=f['analytic_c1_zero'];rng=np.random.default_rng(13906);vals=[]
for i in range(500):
 y=bootstrap(aa[key],False,rng)+E2X;p=endpoint_fit(r,y[sel],se,c1);h=.003;rr=70*A;em,e0,ep=endpoint(rr*np.exp(np.array([-h,0,h])),p,c1);k=1000*((ep-2*e0+em)/h**2-3*(ep-em)/(2*h))/9;vals.append(float(k))
v={'bootstrap':len(vals),'K_fit_mry':f['K_kite_endpoint_rs70_mry']['0.003'],'bootstrap_se_mry':float(np.std(vals,ddof=1)),'bootstrap_95_mry':np.percentile(vals,[2.5,50,97.5]).tolist(),'note':'Sampling uncertainty of endpoint fit only; model bias excluded. Independent bootstrap seed for audit.'};print(v);(WORK/'fit_curvature_bootstrap.json').write_text(json.dumps(v,indent=2)+'\n')
