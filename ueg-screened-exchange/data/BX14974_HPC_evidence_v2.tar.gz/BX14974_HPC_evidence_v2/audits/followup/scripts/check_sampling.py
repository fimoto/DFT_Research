from pathlib import Path
import sys,json,numpy as np
from audit_paths import ROOT as root,KIT,BASE,WORK
kit=KIT;base=BASE;sys.path.insert(0,str(kit/'scripts'))
from common import hf
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq
r=base/'hpc_33_spin_and_transition';E=json.load(open(r/'analysis/ensembles.json'));A=np.load(r/'analysis/replicates.npz');rg=json.load(open(r/'analysis/ring.json'));R={(v['task']['rs'],v['task']['zeta']):v['energy_ry'] for v in rg if v['task']['n']==1800 and v['task']['span']==1.25};keys=[f'spin_precision__m{m}__direct' for m in [20,21,22]];pts=[tuple(p) for p in E[keys[0]]['points']];rs=sorted({p[0] for p in pts});i0=[pts.index((x,0.)) for x in rs];i1=[pts.index((x,1.)) for x in rs];ds=[A[k][:,:,i1]-A[k][:,:,i0] for k in keys];offset=np.array([hf(x,1)-hf(x,0)+R[x,1]-R[x,0] for x in rs]);rng=np.random.default_rng(33319);roots=[]
for _ in range(1000):
 ii=rng.integers(128,size=(2,128));rr=[]
 for d in ds:
  y=sum(d[ii[t],t,:].mean(0) for t in range(2))+offset;f=PchipInterpolator(np.log(rs),y);rr.append(float(np.exp(brentq(f,np.log(rs[0]),np.log(rs[-1])))))
 roots.append(rr)
rr=np.array(roots);o={'crossing_sampling':{'powers':[20,21,22],'bootstrap_95':np.percentile(rr,[2.5,50,97.5],axis=0).T.tolist(),'last_power_shift_se':float(np.std(rr[:,2]-rr[:,1],ddof=1)),'last_power_shift_95':np.percentile(rr[:,2]-rr[:,1],[2.5,50,97.5]).tolist()}}
# Direct curvature sampling uncertainty, retaining correlations between powers and densities.
r=base/'hpc_34_density_curvature';E=json.load(open(r/'analysis/ensembles.json'));A=np.load(r/'analysis/replicates.npz');ks={};h=.01;w=(np.array([-1,16,-30,16,-1])/(12*h*h)-3*np.array([1,-8,0,8,-1])/(12*h))/9
for m in [21,22,23]:
 k=f'density_curvature__m{m}__direct';ps=np.array(E[k]['points'])[:,0];ids=[int(np.argmin(abs(ps-70*np.exp(t*h)))) for t in [-2,-1,0,1,2]];i0=int(np.argmin(abs(ps-70)));v=1000*((A[k][:,:,ids]-A[k][:,:,i0,None])@w);ks[m]=v
out=[]
for m,v in ks.items():
 d={'power':m,'mean_mry':float(v.mean(0).sum()),'se_mry':float(np.sqrt(v.var(0,ddof=1).sum()/len(v)))}
 if m>21:
  delta=v-ks[m-1];d.update(paired_change_mry=float(delta.mean(0).sum()),paired_change_se_mry=float(np.sqrt(delta.var(0,ddof=1).sum()/len(delta))))
 out.append(d)
o['density_curvature_sampling']=out
(WORK/'sampling_checks.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o,indent=2))
