"""Audit-only: differentiate the RPA integrand analytically before quadrature.
E=C*r^-2 integral f(c), c proportional to r, f=log(1+c)-c.
(D^2-3D)E=C*r^-2 integral [10f-6c f'+c^2 f''].
q panels split at the Lindhard branch boundaries and q=2*x_sigma.
"""
import sys,json,time,numpy as np
from pathlib import Path
from audit_paths import ROOT as root,KIT,BASE,WORK
sys.path.insert(0,str(KIT/'scripts'))
from common import ALPHA_L
from ueg_exchange.constants import q_tf_sq
from ueg_exchange.lindhard import lindhard_shape
from ring import log1pmx
from scipy.special import roots_legendre

def grid(edges,n):
 x,w=roots_legendre(n);a=[];b=[]
 for lo,hi in zip(edges[:-1],edges[1:]):
  l,h=np.log(lo),np.log(hi);v=np.exp(l+(x+1)*(h-l)/2);a.extend(v);b.extend(w*(h-l)/2*v)
 return np.array(a),np.array(b)
def curvature_kernel(c):
 v=np.empty_like(c);small=c<.05;t=c[small];v[small]=sum((-1.)**(k+1)*(k-2)*(k-5)/k*t**k for k in range(3,17));t=c[~small];v[~small]=10*(np.log1p(t)-t)+6*t*t/(1+t)-t*t/(1+t)**2
 return v

def calculate(rs,n,span):
 Q2=q_tf_sq(rs);sq=max(1.,Q2**.25);sn=max(1.,np.sqrt(Q2/3));xs=2**(1/3)
 q,wq=grid([sq*10**(-7*span),.15*xs,2*xs,3*xs,sq*10**(7*span)],n)
 nu,wn=grid(sorted([sn*10**(-8*span),1e-4,1e-2,1.,sn,sn*10**(9*span)]),n)
 energy=curvature=0.
 for k in range(0,len(q),8):
  qq=q[k:k+8,None];nn=nu[None,:];L=.5*xs*lindhard_shape(qq/xs,nn/xs**2);c=Q2*L/qq**2
  if np.any(c<0):raise ValueError('negative response')
  weight=(wq[k:k+8]*q[k:k+8]**2)[:,None]*wn[None,:]
  energy+=np.sum(weight*log1pmx(c));curvature+=np.sum(weight*curvature_kernel(c))
 fac=3/(4*np.pi)*2/(ALPHA_L*rs)**2
 return dict(rs=rs,zeta=1,n_per_panel=n,span=span,E_ring_mry=float(1000*fac*energy),K_ring_mry=float(1000*fac*curvature/9))
rows=[]
for r in [60,70,75]:
 for n,s in [(80,1.),(160,1.),(240,1.),(240,1.25)]:
  start=time.time();v=calculate(r,n,s);v['seconds']=time.time()-start;rows.append(v);print(v,flush=True)
  (WORK/'ring_density_audit.json').write_text(json.dumps(rows,indent=2)+'\n')
