from pathlib import Path
import sys,json,hashlib,re,numpy as np
from audit_paths import ROOT,KIT,BASE,WORK
sys.path.insert(0,str(KIT/'scripts'))
from common import digest,sources,E2X,hf,asymptotic_kite
from plan import build
from scipy.integrate import simpson
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq
report={'integrity':{},'qmc_statistics':{},'crossings':[]}
for run in sorted(BASE.glob('hpc_*')):
 m=json.load(open(run/'manifest.json'));check=dict(m);sig=check.pop('fingerprint');assert digest(check)==sig
 assert m['source_hashes']==sources(),run.name
 rec={'manifest_fingerprint_valid':True,'source_hashes_match_distributed_kit':True,'runtime':m['runtime'],'raw_present':(run/'raw').exists()}
 if 'tasks' in m:
  assert m['tasks']==build(m['input']);ts=m['tasks'];cfg=KIT/'inputs'/(run.name[4:]+'.json');assert m['input']==json.load(open(cfg))
  log=(run/'execution.log').read_text();ids=[int(x) for x in re.findall(r'^DONE (\d+) ',log,re.M)];assert sorted(ids)==list(range(len(ts)))
  rec.update(tasks=len(ts),done_log_ids_complete_unique=True,run_complete='RUN COMPLETE' in log)
  wall=[float(x) for x in re.findall(r'^DONE \d+ \S+ ([\d.]+)s$',log,re.M)];rec['task_hours']=sum(wall)/3600
  for kind in ['ring','axis']:
   rr=json.load(open(run/f'analysis/{kind}.json'));expect=[t for t in ts if t['kind']==kind];assert len(rr)==len(expect)
   for r in rr:
    t=r['task'];assert t==ts[t['id']] and r['signature']==sig
    if kind=='ring':assert np.isfinite(r['energy_ry'])
    else:
     val=np.zeros(t['replicates'])
     for p in r['profiles']:
      q=np.array(p['q']);v=np.array(p['qX']);n=t['nq'];x=np.log(q)
      val+=(1 if t['zeta']==0 else p['spin_scale']**3/2)*6/np.pi**3*(simpson(v[:,:n+1],x=x[:n+1],axis=1)+simpson(v[:,n:],x=x[n:],axis=1))
     np.testing.assert_allclose(val,r['replicates_ry'],rtol=1e-12,atol=1e-14)
     np.testing.assert_allclose([val.mean(),val.std(ddof=1)/np.sqrt(len(val))],[r['mean_ry'],r['se_ry']],rtol=1e-10,atol=1e-14)
  ee=json.load(open(run/'analysis/ensembles.json'));aa=np.load(run/'analysis/replicates.npz');assert set(aa.files)==set(ee)
  maxmean=maxcov=0
  for key,e in ee.items():
   a=aa[key];assert np.isfinite(a).all();g=next(g for g in m['input']['groups'] if g['name']==e['group']);assert a.shape==(g['replicates'],2,len(e['points']));assert e['replicate_ids']==list(range(g['replicates']))
   points=sorted({(t['rs'],t['zeta']) for t in ts if t['group']==g['name']});assert points==[tuple(p) for p in e['points']]
   mean=a.mean(0).sum(0)+e['constant_ry'];cov=sum(np.atleast_2d(np.cov(a[:,j,:],rowvar=False,ddof=1)) for j in (0,1))/len(a)
   maxmean=max(maxmean,float(np.max(abs(mean-np.array(e['mean_ry'])))));maxcov=max(maxcov,float(np.max(abs(cov-np.array(e['covariance_mean_ry2'])))))
   np.testing.assert_allclose(mean,e['mean_ry'],rtol=0,atol=2e-14);np.testing.assert_allclose(cov,e['covariance_mean_ry2'],rtol=1e-10,atol=1e-25)
  report['qmc_statistics'][run.name]={'ensembles':len(ee),'mean_max_abs_difference_ry':maxmean,'covariance_max_abs_difference':maxcov}
 else:
  assert json.load(open(run/'summary.json'))['status']=='completed'
  rec['integration_warning_count']=(run/'execution.log').read_text().count('IntegrationWarning:')
  for order in [80,160,240]:
   c=json.load(open(run/f'coefficients_{order}.json'));assert len(c['b'])==order and c['source_hashes']==sources();assert np.isfinite(c['b']).all()
 report['integrity'][run.name]=rec
# Reconstruct endpoint roots at each Sobol power and each ring setting.
r=BASE/'hpc_33_spin_and_transition';E=json.load(open(r/'analysis/ensembles.json'));A=np.load(r/'analysis/replicates.npz');rg=json.load(open(r/'analysis/ring.json'));R={(x['task']['n'],x['task']['span'],x['task']['rs'],x['task']['zeta']):x['energy_ry'] for x in rg};settings=sorted({(n,s) for n,s,x,z in R if x==455.})
for key,e in E.items():
 if e['group']!='spin_precision':continue
 pts=[tuple(p) for p in e['points']];rs=sorted({p[0] for p in pts});a=A[key];idx0=[pts.index((x,0.)) for x in rs];idx1=[pts.index((x,1.)) for x in rs];d=(a[:,:,idx1]-a[:,:,idx0]).mean(0).sum(0)+np.array([hf(x,1)-hf(x,0) for x in rs])
 for n,s in settings:
  y=d+np.array([R[n,s,x,1.]-R[n,s,x,0.] for x in rs]);f=PchipInterpolator(np.log(rs),y);root=float(np.exp(brentq(f,np.log(rs[0]),np.log(rs[-1]))));report['crossings'].append({'power':e['power'],'n':n,'span':s,'rs_crossing':root})
# Latest direct means and uncertainties and fit holdout tests.
e14=json.load(open(BASE/'hpc_14_low_density_map4/analysis/followup_report.json'))['qmc']['map_comparisons'];report['low_density']=[x for x in e14 if (x['rs']==1e8 and x['power']==27) or (x['rs']==1e6 and x['power']==24)]
f=json.load(open(BASE/'hpc_41_fit_and_coefficients/fit_order_240/fit_results.json'));h=f['holdout'];res=np.array(h['residual_mry']);se=np.array(h['combined_sampling_se_mry']);ci=np.array(h['residual_bootstrap_95_mry']);report['fit']={'train_rms_mry':f['rms_mry'],'holdout_rms_mry':float(np.sqrt(np.mean(res**2))),'holdout_max_abs_mry':float(max(abs(res))),'pointwise_95_CI_excludes_zero':int(np.sum((ci[:,0]>0)|(ci[:,2]<0))),'points':len(res),'worst':[{'point':h['points'][i],'residual_mry':res[i],'combined_se_mry':se[i],'CI95':ci[i].tolist()} for i in np.argsort(-abs(res))[:8]]}
report['axis']=json.load(open(BASE/'hpc_51_axis_resolution/analysis/followup_report.json'))['axis']
# Compare axis to the NEW precise 14 baseline at both low densities.
report['axis_new_direct_comparison']=[]
for v in report['axis']['estimates']:
 if v['group']=='axis_low_density' and v['setting']['label'] in ['joint_refined','wide_range']:
  b=next(b for b in report['low_density'] if b['rs']==v['rs']);d=v['mean_mry']-b['mean_mry'];se=np.hypot(v['se_mry'],b['se_mry']);report['axis_new_direct_comparison'].append({'rs':v['rs'],'label':v['setting']['label'],'difference_mry':d,'combined_se_mry':float(se),'sigma':float(d/se)})
(WORK/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='axis'},indent=2))
