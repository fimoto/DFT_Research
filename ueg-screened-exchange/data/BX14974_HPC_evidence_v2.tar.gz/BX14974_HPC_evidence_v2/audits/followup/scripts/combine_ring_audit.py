from pathlib import Path
import sys,json,numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq
from audit_paths import ROOT as root,KIT,BASE,WORK
sys.path.insert(0,str(KIT/'scripts'));from common import hf
base=BASE;rows=json.load(open(WORK/'ring_spin_energy_audit.json'));R={(v['n'],v['span'],v['rs'],v['zeta']):v['energy_ry'] for v in rows}
e=json.load(open(base/'hpc_33_spin_and_transition/analysis/ensembles.json'));a=np.load(base/'hpc_33_spin_and_transition/analysis/replicates.npz');key='curvature_precision__m22__direct';pts=[tuple(p) for p in e[key]['points']];terms=a[key];out={'spin_curvature':[],'crossings':[],'density_curvature':[]}
for rs in [32,60,70,75,110]:
 i0=pts.index((rs,0.))
 for maxz in [.04,.1,.2]:
  zz=np.array([z for r,z in pts if r==rs and 0<z<=maxz]);ids=[pts.index((rs,z)) for z in zz]
  for degree in [2,3]:
   D=np.column_stack([zz**(2*j) for j in range(1,degree+1)]);w=2*np.linalg.pinv(D)[0];tv=(terms[:,:,ids]-terms[:,:,i0,None])@w;km=float(tv.mean(0).sum());se=float(np.sqrt(tv.var(0,ddof=1).sum()/len(tv)));hh=float(w@np.array([hf(rs,z)-hf(rs,0) for z in zz]));ests=[]
   for n,s in [(160,1.25),(240,1.25)]+([(240,1.)] if rs==70 else []):
    rg=float(w@np.array([R[n,s,rs,z]-R[n,s,rs,0] for z in zz]));ests.append({'n':n,'span':s,'K_ring_mry':1000*rg,'K_total_mry':1000*(km+hh+rg)})
   out['spin_curvature'].append({'rs':rs,'max_zeta':maxz,'degree':degree,'K_kite_mry':1000*km,'sampling_se_mry':1000*se,'estimates':ests})
key='spin_precision__m22__direct';pts=[tuple(p) for p in e[key]['points']];means=np.array(e[key]['mean_ry']);rs=sorted({p[0] for p in pts})
for n in [160,240]:
 y=np.array([means[pts.index((x,1))]-means[pts.index((x,0))]+hf(x,1)-hf(x,0)+R[n,1.25,x,1]-R[n,1.25,x,0] for x in rs]);f=PchipInterpolator(np.log(rs),y);out['crossings'].append({'n':n,'span':1.25,'rs':float(np.exp(brentq(f,np.log(rs[0]),np.log(rs[-1]))))})
dens=json.load(open(base/'hpc_34_density_curvature/analysis/followup_report.json'))['density']['estimates'];rk=json.load(open(WORK/'ring_density_audit.json'))
for rs in [60,70,75]:
 rec=next(v for v in dens if v['rs']==rs and v['power']==23 and v['stencil']=='5point' and v['log_step']==.01);rg=next(v for v in rk if v['rs']==rs and v['n_per_panel']==240 and v['span']==1.25)
 out['density_curvature'].append({'rs':rs,'K_kite_mry':rec['K_kite_mry'],'sampling_se_mry':rec['sampling_se_mry'],'K_hf_mry':rec['K_hf_mry'],'K_ring_mry':rg['K_ring_mry'],'K_total_mry':rec['K_kite_mry']+rec['K_hf_mry']+rg['K_ring_mry']})
(WORK/'refined_ring_summary.json').write_text(json.dumps(out,indent=2)+'\n')
print('crossings',out['crossings']);print('density',out['density_curvature'])
for v in out['spin_curvature']:
 if v['max_zeta']==.04:print(v)
print('finite diff',json.load(open(WORK/'ring_density_finite_diff_check.json')))
