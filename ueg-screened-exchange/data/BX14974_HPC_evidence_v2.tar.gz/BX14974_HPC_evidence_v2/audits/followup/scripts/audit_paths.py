from pathlib import Path
import os
ROOT=Path(__file__).resolve().parents[1]
KIT=Path(os.environ.get("BX_KIT",str(ROOT.parent/"BX14974_followup"))).resolve()
BASE=Path(os.environ.get("BX_RESULTS",str(ROOT.parent/"review_followup/runs"))).resolve()
WORK=ROOT/"results"
WORK.mkdir(parents=True,exist_ok=True)
