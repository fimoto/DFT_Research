from pathlib import Path
import json,tarfile,hashlib,sys,re,collections,numpy as np
from scipy.integrate import simpson
ROOT=Path('/workspace/scratch/cddd47725493');KIT=ROOT/'output/BX14974_followup';BASE=ROOT/'review_followup/runs'
sys.path.insert(0,str(KIT/'scripts'))
from common import digest,sources

def bad_constant(x):raise ValueError('Nonfinite JSON constant: '+x)
def finite(x):
 if isinstance(x,float):assert np.isfinite(x)
 elif isinstance(x,dict):
  for v in x.values():finite(v)
 elif isinstance(x,list):
  for v in x:finite(v)
def load(p):return json.loads(p.read_text(),parse_constant=bad_constant)
def err(a,b):
 a=np.asarray(a);b=np.asarray(b);assert a.shape==b.shape
 return float(np.max(abs(a-b))) if a.size else 0.
report={'scope':'All supplied raw JSON records; no new production integration.','runs':{}}
for archive in sorted((ROOT/'upload').glob('hpc_*_raw.tar.gz')):
 name=archive.name.removesuffix('_raw.tar.gz');run=BASE/name;m=load(run/'manifest.json');obj=dict(m);sig=obj.pop('fingerprint');assert digest(obj)==sig;assert m['source_hashes']==sources()
 tasks={t['id']:t for t in m['tasks']};records={};names=set();hashes={};counts=collections.Counter()
 with tarfile.open(archive) as tar:
  for member in tar:
   assert member.name not in names,('duplicate tar member',member.name)
   names.add(member.name)
   if member.isdir():continue
   assert member.isfile(),('nonregular member',member.name)
   match=re.fullmatch(re.escape(name)+r'/raw/(\d{7})\.json',member.name);assert match,member.name
   ident=int(match[1]);assert ident in tasks and ident not in records
   data=tar.extractfile(member).read();r=json.loads(data,parse_constant=bad_constant);finite(r)
   assert r['task']==tasks[ident] and r['signature']==sig,(name,ident)
   assert r['wall_seconds_last_invocation']>=0
   if tasks[ident]['kind']=='qmc':
    t=tasks[ident];assert set(r['term_means'])=={str(p) for p in t['powers']}
    cols=['direct']+['difference_ref_'+str(x) for x in t['references']]+['reference_energy_'+str(x) for x in t['references']]
    assert r['columns']==cols and r['reference_energy_added'] is False
    for p in t['powers']:assert np.asarray(r['term_means'][str(p)]).shape==(2,len(cols))
   records[ident]=r;hashes[member.name]=hashlib.sha256(data).hexdigest();counts[tasks[ident]['kind']]+=1
 assert set(records)==set(tasks),('missing',name)
 log=(run/'execution.log').read_text();timings={int(i):float(t) for i,t in re.findall(r'^DONE (\d+) \S+ ([\d.]+)s$',log,re.M)}
 assert set(timings)==set(tasks)
 assert all(abs(r['wall_seconds_last_invocation']-timings[i])<=.00501 for i,r in records.items())
 stats={'raw_files':len(records),'expected':len(tasks),'kinds':dict(counts),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
 'manifest_and_source_hashes_valid':True,'missing':0,'extra':0,'duplicate_ids':0,'invalid_signatures':0,'nonfinite_values':0,'log_ids_and_times_match':True,
 'npz_arrays_compared':0,'npz_elements_compared':0,'npz_exact_matches':True,'max_mean_difference_ry':0.,'max_covariance_difference_ry2':0.,'embedded_raw_exact_matches':{}}
 ee=load(run/'analysis/ensembles.json');aa=np.load(run/'analysis/replicates.npz');assert set(aa.files)==set(ee)
 for key,e in ee.items():
  g=next(g for g in m['input']['groups'] if g['name']==e['group']);points=[tuple(p) for p in e['points']]
  rr=[r for r in records.values() if r['task']['group']==g['name']]
  assert len(rr)==g['replicates']*len(points)
  by={((r['task']['rs'],r['task']['zeta']),r['task']['rep']):r for r in rr};assert len(by)==len(rr)
  assert e['replicate_ids']==list(range(g['replicates']))
  vi=rr[0]['columns'].index(e['column']);p=str(e['power'])
  rebuilt=np.array([[by[point,j]['term_means'][p] for point in points] for j in range(g['replicates'])])[:,:,:,vi].transpose(0,2,1)
  assert np.array_equal(rebuilt,aa[key]),(name,key,'NPZ mismatch')
  stats['npz_arrays_compared']+=1;stats['npz_elements_compared']+=rebuilt.size
  mean=rebuilt.mean(0).sum(0)+e['constant_ry']
  if e['independent_points']:cov=np.diag(rebuilt.var(0,ddof=1).sum(0)/len(rebuilt))
  else:cov=sum(np.atleast_2d(np.cov(rebuilt[:,j,:],rowvar=False,ddof=1)) for j in (0,1))/len(rebuilt)
  dm=err(mean,e['mean_ry']);dc=err(cov,e['covariance_mean_ry2']);assert dm<2e-14 and dc<1e-20
  stats['max_mean_difference_ry']=max(stats['max_mean_difference_ry'],dm);stats['max_covariance_difference_ry2']=max(stats['max_covariance_difference_ry2'],dc)
 for kind in ['ring','axis']:
  embedded=load(run/f'analysis/{kind}.json');other={r['task']['id']:r for r in embedded};raw={i:r for i,r in records.items() if r['task']['kind']==kind}
  assert other==raw,(name,kind,'embedded record mismatch');stats['embedded_raw_exact_matches'][kind]=len(raw)
 if counts['axis']:
  groups={};max_energy=max_block_mean=max_block_se=0.
  for r in records.values():
   t=r['task'];integrals=np.zeros(t['replicates'])
   for profile in r['profiles']:
    q=np.asarray(profile['q']);val=np.asarray(profile['qX']);n=t['nq'];assert q.shape==(2*n+1,) and val.shape==(t['replicates'],2*n+1);assert np.all(np.diff(q)>0)
    assert np.isclose(q[0],t['qmin'],rtol=1e-13) and np.isclose(q[n],2,rtol=1e-13)
    if t.get('qmax') is not None:assert np.isclose(q[-1],t['qmax'],rtol=1e-13)
    x=np.log(q);v=6/np.pi**3*(simpson(val[:,:n+1],x=x[:n+1],axis=1)+simpson(val[:,n:],x=x[n:],axis=1));integrals+=(1 if t['zeta']==0 else profile['spin_scale']**3/2)*v
   assert err(integrals,r['replicates_ry'])<2e-14
   max_energy=max(max_energy,err(integrals,r['replicates_ry']));max_block_mean=max(max_block_mean,abs(integrals.mean()-r['mean_ry']));max_block_se=max(max_block_se,abs(integrals.std(ddof=1)/np.sqrt(len(integrals))-r['se_ry']))
   groups.setdefault((t['group'],t['rs'],t['zeta'],t['setting_id']),[]).append(r)
  estimates=load(run/'analysis/followup_report.json')['axis'];arrays={};setting={};max_mean=max_se=max_shift=max_pse=0.
  for k,rr in groups.items():
   rr.sort(key=lambda r:r['task']['replicate_start']);t=rr[0]['task'];ids=[];base=t['seed']-t['replicate_start']
   for r in rr:
    tt=r['task'];ids.extend(range(tt['replicate_start'],tt['replicate_start']+tt['replicates']));assert tt['seed']-tt['replicate_start']==base
   assert ids==list(range(t['total_replicates']))
   a=np.concatenate([r['replicates_ry'] for r in rr]);label=(k[0],k[1],t['label']);arrays[label]=a;setting[label]=base
   e=next(e for e in estimates['estimates'] if e['group']==k[0] and e['rs']==k[1] and e['setting']['setting_id']==k[3]);assert e['R']==len(a)
   dm=abs(a.mean()*1000-e['mean_mry']);ds=abs(a.std(ddof=1)/np.sqrt(len(a))*1000-e['se_mry']);assert dm<1e-10 and ds<1e-10;max_mean=max(max_mean,dm);max_se=max(max_se,ds)
  for e in estimates['paired_refinements']:
   ka=(e['group'],e['rs'],e['test']);kb=(e['group'],e['rs'],e['base']);assert setting[ka]==setting[kb];d=arrays[ka]-arrays[kb]
   dm=abs(d.mean()*1000-e['paired_shift_mry']);ds=abs(d.std(ddof=1)/np.sqrt(len(d))*1000-e['paired_se_mry']);assert dm<1e-10 and ds<1e-10;max_shift=max(max_shift,dm);max_pse=max(max_pse,ds)
  stats['axis_reintegration']={'settings':len(groups),'replicate_integrals':sum(len(a) for a in arrays.values()),'max_integral_difference_ry':max_energy,'max_block_mean_difference_ry':max_block_mean,'max_block_se_difference_ry':max_block_se,'max_group_mean_difference_mry':max_mean,'max_group_se_difference_mry':max_se,'paired_comparisons':len(estimates['paired_refinements']),'max_paired_shift_difference_mry':max_shift,'max_paired_se_difference_mry':max_pse}
 report['runs'][name]=stats
 print(name,'PASS',len(records),'records',flush=True)
 (ROOT/'raw_audit_work/raw_audit.json').write_text(json.dumps(report,indent=2)+'\n')
report['totals']={'raw_records':sum(v['raw_files'] for v in report['runs'].values()),'npz_arrays':sum(v['npz_arrays_compared'] for v in report['runs'].values()),'npz_elements':sum(v['npz_elements_compared'] for v in report['runs'].values()),'status':'PASS'}
(ROOT/'raw_audit_work/raw_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['totals'],indent=2))
