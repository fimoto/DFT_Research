Reproduction of the revision's numerical tables

From the root of BX14974_HPC_evidence_v1:
  python3 audits/current/recompute_evidence.py --data-root . --output audit_recomputed

Requires NumPy and SciPy, and the following bundled paths:
  results/original/hpc_10_low_density/
  results/original/hpc_13_low_density_precision/
  results/original/hpc_20_high_density/
  results/followup/hpc_14_low_density_map4/
  results/followup/hpc_33_spin_and_transition/
  code/original/scripts/ and code/original/vendor/
  audits/current/finite_part_audit.json
  audits/current/ring_spin_energy_audit.json

No new production integral is evaluated by this script. It independently
reaggregates stored term-replicate arrays, restores the finite-reference
energy, recomputes GLS fits and covariances, and recomputes PCHIP crossings.
The finite-part sidecar records a separate completed stable-quadrature audit.
The ring sidecar is a LOCAL panel-quadrature audit; formal corrected-ring
HPC jobs 35/36/37 are pending and must not be represented as complete.

Outputs:
  numerical_evidence.json: full machine-readable results and source hashes.
  numerical_evidence.txt: compact N/R and coefficient summaries.
  low_density_N_table.tex: optional ready-to-copy m15–m22 table, R=64.

Statistical interpretation:
- N rows and R prefixes are correlated because samples are nested.
- Two QMC terms use disjoint randomizations; their variances add.
- Shared-density covariance is preserved where present.
- The high-density ensemble uses independent density seeds, so the full
  energy covariance is diagonal by construction; fitted coefficients are
  nevertheless strongly correlated. Covariance is not rescaled by Q/dof.
- The reported statistical power is conditional Gaussian power for the
  stated regression and plug-in covariance, not an unconditional guarantee.
- r^2 and r^2 log^2(r) nuisance models test truncation sensitivity; neither
  is asserted to be the derived first omitted term.
- The finite reference correction at 1e30 uses the asymptotic expression.
  Its uncertainty is not magically included in a QMC sampling SE. Independent
  reference24/reference30 checks and momentum-map changes are reported.
- At1e8 the third asymptotic term is resolved against the two-term model;
  at1e6 the remaining higher-order contribution is also statistically
  resolved, so exact agreement with the three-term truncation is not claimed.
