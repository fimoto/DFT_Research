"""Audit supplied ring production results against the frozen input/source kit.
Usage: python audit_ring_results.py [results-or-archive-root] [code-kit-root] [output-directory]
Writes audit/audit_results.json and preserves a reaggregated copy under audit/recomputed.
"""
from pathlib import Path
import sys,json,hashlib,shutil,subprocess,math
import numpy as np
BASE=Path(sys.argv[1] if len(sys.argv)>1 else 'ring_results_v2_work').resolve()
KIT=Path(sys.argv[2] if len(sys.argv)>2 else 'output/BX14974_ring_and_validation').resolve()
ARCHIVE_LAYOUT = (BASE / 'results/corrected_ring').is_dir()
RUNS = BASE / 'results/corrected_ring' if ARCHIVE_LAYOUT else BASE / 'runs'
OUT = Path(sys.argv[3]).resolve() if len(sys.argv) > 3 else BASE / 'audit'
OUT.mkdir(parents=True, exist_ok=True)
def load(p): return json.loads(p.read_text())
def hashbytes(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def differences(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  if set(a)!=set(b): return [(path,'keys differ')]
  return sum((differences(a[k],b[k],path+'/'+k) for k in a),[])
 if isinstance(a,list) and isinstance(b,list):
  if len(a)!=len(b):return [(path,'length differs')]
  return sum((differences(x,y,path+f'/{i}') for i,(x,y) in enumerate(zip(a,b))),[])
 if isinstance(a,(float,int)) and isinstance(b,(float,int)) and a!=b:
  return [(path,a,b,abs(a-b))]
 return [] if a==b else [(path,a,b)]
summary={'runs':{},'validation':[]}
reports={}
for run in sorted(RUNS.iterdir()):
 m=load(run/'manifest.json');mcopy=dict(m);signature=mcopy.pop('fingerprint');assert digest(mcopy)==signature
 badsources=[name for name,h in m['source_hashes'].items() if not (KIT/name).is_file() or hashbytes(KIT/name)!=h]
 assert not badsources,badsources
 input_path=KIT/'inputs'/('{}_ring_{}.json'.format(run.name.split('_')[1], '_'.join(run.name.split('_')[3:])))
 assert m['input']==load(input_path),input_path
 rawpaths=sorted((run/'raw').glob('*.json'));assert len(rawpaths)==len(m['tasks'])
 rows=[]
 for p,t in zip(rawpaths,m['tasks']):
  r=load(p);assert p.name==f'{t["id"]:07d}.json' and r['task']==t and r['signature']==signature
  assert r['method']=='panel_analytic_density_v1'
  assert all(math.isfinite(r[k]) for k in ('energy_ry','density_curvature_ry'))
  rows.append(r)
 copy=OUT/'recomputed'/run.name
 shutil.copytree(run,copy,dirs_exist_ok=True)
 for script in ['analyze.py','ring_report.py']:
  result=subprocess.run([sys.executable,str(KIT/'scripts'/script),'--run',str(copy)],capture_output=True,text=True,check=True)
  (copy/(script+'.log')).write_text(result.stdout+result.stderr)
 checked=[]
 for name in ['ring.json','completion.json','corrected_ring_report.json']:
  ds=differences(load(run/'analysis'/name),load(copy/'analysis'/name));assert all(len(x)==4 and x[3]<1e-8 for x in ds),(name,ds[:3]);checked.append({'file':name,'exact':not ds,'max_absolute_float_difference':max((x[3] for x in ds),default=0.)})
 r=load(copy/'analysis/corrected_ring_report.json');reports[run.name]=r
 conv=r['convergence']
 def maxdiff(field, n1,s1,n2,s2):
  vals=[]
  for c in conv:
   ss={(x['n'],x['span']):x for x in c['settings']}
   vals.append((abs(ss[n1,s1][field]-ss[n2,s2][field]),c['rs'],c['zeta']))
  return max(vals)
 info={'tasks':len(rows),'source_hash_entries':len(m['source_hashes']),'source_hash_mismatches':badsources,'runtime':m['runtime'],'input_matches':True,'raw_identity_pass':True,'reaggregated_json_comparisons':checked,'max_abs_order240_to320_E_mry':maxdiff('E_mry',240,1.25,320,1.25),'max_abs_order120_to320_E_mry':maxdiff('E_mry',120,1.25,320,1.25),'max_abs_span1_to1p25_E_mry':maxdiff('E_mry',320,1.,320,1.25),'max_abs_order240_to320_K_mry':maxdiff('K_mry',240,1.25,320,1.25),'max_abs_span1_to1p25_K_mry':maxdiff('K_mry',320,1.,320,1.25)}
 summary['runs'][run.name]=info
r=reports['hpc_35_ring_transition'];c=[x for x in r['endpoint_crossings'] if x['power']==22]
best=next(x for x in c if x['n']==320 and x['span']==1.25)
summary['crossing']={'production':best,'all_m22_settings':c,'max_setting_shift':max(abs(x['rs_crossing']-best['rs_crossing']) for x in c),'powers_at_best':[x for x in r['endpoint_crossings'] if x['n']==320 and x['span']==1.25]}
# Spin-grid evidence relative to both endpoints, using same stored rows.
pol=[x for x in r['polarization_differences'] if x['power']==22]
polrows=[]
for rs in sorted({x['rs'] for x in pol}):
 vals=[x for x in pol if x['rs']==rs];v=[(x['zeta'],x['settings'][-1]['delta_total_from_unpolarized_mry']) for x in vals]
 endpoint=min(v[0][1],v[-1][1]);inter=[(z,e-endpoint) for z,e in v if 0<z<1]
 polrows.append({'rs':rs,'minimum_zeta':min(v,key=lambda t:t[1])[0],'min_interior_gap_above_lower_endpoint_mry':min(inter,key=lambda t:t[1]),'values':v})
summary['spin_grid']=polrows
r=reports['hpc_36_ring_spin_curvature'];rows=[x for x in r['spin_curvature'] if x['power']==22]
summary['spin_curvature']={'production':[x for x in rows if x['max_zeta']==.04 and x['degree']==2],'window_checks':[]}
for rs in sorted({x['rs'] for x in rows}):
 vals=[x for x in rows if x['rs']==rs]
 summary['spin_curvature']['window_checks'].append({'rs':rs,'values':[{'max_zeta':x['max_zeta'],'degree':x['degree'],'kite_mry':x['K_kite_mry'],'sampling_se_mry':x['kite_sampling_se_mry'],'ring_mry':x['settings'][-1]['K_ring_mry'],'total_mry':x['settings'][-1]['K_total_mry']} for x in vals]})
summary['spin_curvature']['max_order240_to320_shift_mry']=max(abs(x['settings'][5]['K_ring_mry']-x['settings'][7]['K_ring_mry']) for x in rows)
summary['spin_curvature']['max_span_shift_mry']=max(abs(x['settings'][6]['K_ring_mry']-x['settings'][7]['K_ring_mry']) for x in rows)
r=reports['hpc_37_ring_density_curvature'];rows=[x for x in r['density_curvature'] if x['power']==23]
summary['density_curvature']={'production':[x for x in rows if x['log_step']==.01],'step_checks':rows,'max_analytic_vs_fd_at_best_mry':max(abs(x['settings'][-1]['analytic_minus_fd_mry']) for x in rows)}
if ARCHIVE_LAYOUT:
    validation_hashes = load(Path(__file__).resolve().with_name('received_validation_hashes.json'))
    for run_name, expected in sorted(validation_hashes.items()):
        local = BASE / 'results/local_validation' / run_name
        actual = {path.relative_to(local).as_posix(): hashbytes(path)
                  for path in local.rglob('*') if path.is_file()}
        different = [name for name, checksum in expected.items()
                     if actual.get(name) != checksum]
        assert not different, (run_name, different)
        summary['validation'].append({
            'run': run_name, 'comparison_local_path': str(local),
            'comparison_basis': 'Per-file SHA256 values recorded from the supplied duplicate validation directories.',
            'file_count': len(expected), 'local_file_count': len(actual),
            'included_files_all_identical': not different, 'different': different,
        })
else:
    for run in sorted((BASE / 'validation/runs').iterdir()):
        local = KIT / 'validation/runs' / run.name
        supplied = {path.relative_to(run).as_posix(): hashbytes(path)
                    for path in run.rglob('*') if path.is_file()}
        original = {path.relative_to(local).as_posix(): hashbytes(path)
                    for path in local.rglob('*') if path.is_file()}
        different = [name for name, checksum in supplied.items()
                     if original.get(name) != checksum]
        assert not different, (run.name, different)
        summary['validation'].append({
            'run': run.name, 'comparison_local_path': str(local),
            'file_count': len(supplied), 'local_file_count': len(original),
            'identical': supplied == original,
            'included_files_all_identical': not different,
            'omitted_checkpoint_count': sum(name not in supplied and name.startswith('checkpoints/')
                                            for name in original),
            'different': different,
        })
# Nested QMC sample-power changes retain common scrambles and are sensitivity diagnostics.
summary['sample_power_checks']={}
for run,key in [('hpc_36_ring_spin_curvature','spin_curvature'),('hpc_37_ring_density_curvature','density_curvature')]:
    selected=[x for x in reports[run][key] if (key=='spin_curvature' and x['max_zeta']==.04 and x['degree']==2) or (key=='density_curvature' and x['log_step']==.01)]
    summary['sample_power_checks'][key]=[{'rs':x['rs'],'power':x['power'],'kite_mry':x.get('K_kite_mry'),'sampling_se_mry':x['kite_sampling_se_mry'],'total_mry':x['settings'][-1]['K_total_mry']} for x in selected]
summary['spin_curvature']['max_window_spread_total_mry']=max(max(x['total_mry'] for x in c['values'])-min(x['total_mry'] for x in c['values']) for c in summary['spin_curvature']['window_checks'])
summary['paired_sample_power_checks'] = []
for subdirectory, group, lower, upper in [
    ('33_spin_and_transition', 'curvature_precision', 21, 22),
    ('34_density_curvature', 'density_curvature', 22, 23),
]:
    previous = KIT / 'previous' / subdirectory
    ensembles = load(previous / 'ensembles.json')
    arrays = np.load(previous / 'replicates.npz')
    selections = {
        power: next((key, value) for key, value in ensembles.items()
                    if value['group'] == group and value['column'] == 'direct'
                    and value['power'] == power)
        for power in (lower, upper)
    }
    points = list(map(tuple, selections[upper][1]['points']))
    differences_array = arrays[selections[upper][0]] - arrays[selections[lower][0]]
    centers = [32., 60., 70., 75., 110.] if group == 'curvature_precision' else [60., 70., 75.]
    for center in centers:
        if group == 'curvature_precision':
            spins = np.array([spin for density, spin in points if density == center and 0 < spin <= .04])
            indices = [points.index((center, spin)) for spin in spins]
            zero = points.index((center, 0.))
            weights = 2 * np.linalg.pinv(np.column_stack([spins**2, spins**4]))[0]
        else:
            step = .01
            densities = np.array(points)[:, 0]
            indices = [int(np.argmin(abs(densities - target))) for target in center * np.exp(np.arange(-2, 3) * step)]
            zero = int(np.argmin(abs(densities - center)))
            weights = (np.array([-1, 16, -30, 16, -1]) / (12 * step**2)
                       - 3 * np.array([1, -8, 0, 8, -1]) / (12 * step)) / 9
        values = (differences_array[:, :, indices] - differences_array[:, :, zero, None]) @ weights
        mean = 1000 * values.mean(0).sum()
        standard_error = 1000 * np.sqrt(values.var(0, ddof=1).sum() / len(values))
        summary['paired_sample_power_checks'].append({
            'group': group, 'rs': center, 'lower_power': lower, 'upper_power': upper,
            'difference_mry': float(mean), 'paired_sampling_se_mry': float(standard_error),
            'difference_over_paired_se': float(mean / standard_error),
        })
(OUT/'audit_results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k in ['runs','validation']},indent=2))
