"""BRM (PRB 110,195151) Eq58/59 comparison. All energies in Ry/electron.
Run python compare.py; deterministic multi-start refits may take a minute.
"""
from pathlib import Path
import json,csv,hashlib
import numpy as np
from scipy.optimize import least_squares
import compact_kite as C
from theory import E2X
P=Path(__file__).resolve().parent
Z=np.array([0,.2,.4,.6,.8,.9,1.])
TABLE=np.array([[.10215,-.01382,.46529,.00364],[.10876,-.01317,.45202,.00329],[.10456,-.01305,.46978,.00291],[.07801,-.01265,.4441,.00277],[.06266,-.01023,.36888,.00179],[.05106,-.00835,.29562,.00148],[.04143,-.00571,.19503,.00088]])
POLY=np.array([[.10215,-.05028,-.01283],[-.01382,.00016,.00808],[.46529,.05868,-.32923],[.00364,-.00259,-.00021]])
def eq58(r,a,a0=.04836):
    a1,a2,a3,a4=np.moveaxis(np.asarray(a),-1,0)
    return a0/(1+a1*r)+a2*r*np.log1p(1/(r*(a3+a4*np.sqrt(r))))
def published(r,z,a0=.04836):
    x=np.asarray(z)**2
    return eq58(r,np.stack([np.ones_like(x),x,x*x],axis=-1)@POLY.T,a0)
def tabulated(r,z):
    i=np.argmin(abs(np.asarray(z)[...,None]-Z),axis=-1)
    if not np.allclose(Z[i],z,atol=1e-12,rtol=0):raise ValueError('No Table V coefficients at this zeta')
    return eq58(r,TABLE[i])
def bernstein(z):
    x=np.asarray(z)**2
    return np.stack([(1-x)**2,2*x*(1-x),x*x],axis=-1)
def global_model(r,z,p):
    a=(bernstein(z)@np.exp(p.reshape(4,3)).T)*np.array([1,-1,1,1])
    return eq58(r,a,E2X)
def stats(res,r,z):
    if len(res)==0:return None
    i=int(np.argmax(abs(res)))
    return dict(n=len(res),rms_mry=float(np.mean(res**2)**.5),max_abs_mry=float(abs(res[i])),worst_rs=float(r[i]),worst_zeta=float(z[i]))
def summary(pred,r,z,y):
    e=1000*(pred-y)
    masks={'all':np.ones(len(r),bool),'rs_le_1':r<=1,'rs_1_to_1000':(r>=1)&(r<=1000),'rs_gt_1000':r>1000,'endpoints':(z==0)|(z==1),'interior':(z>0)&(z<1)}
    return {k:stats(e[m],r[m],z[m]) for k,m in masks.items()}
d=np.load(P/'data/energy_data.npz')
r,z,y,se=[d[k] for k in ['r','z','y','se']]
hr,hz,hy,hse=[d['hold_'+k] for k in ['r','z','y','se']]
sigma=np.hypot(se,.000020)
assert len(r)==119 and len(hr)==44
assert abs(published(np.array([1.]),np.array([0.]))[0]-eq58(1.,TABLE[0]))<1e-15
assert np.allclose(POLY[:,0],TABLE[0])
# Positive Bernstein coefficients imply a1,a3,a4>0 and a2<0 for 0<=z<=1.
# This is a constrained subset of all positive quadratics, explicitly documented.
b0=np.stack([POLY[:,0],POLY[:,0]+POLY[:,1]/2,POLY.sum(axis=1)],axis=1)*np.array([1,-1,1,1])[:,None]
p0=np.log(b0).ravel();rng=np.random.default_rng(581959)
out={'reference':'Benites, Rosado, Manousakis, Phys Rev B 110,195151 (2024), Eq58/59, Tables V/VI','units':'mRy/electron for residuals','data_sha256':hashlib.sha256((P/'data/energy_data.npz').read_bytes()).hexdigest(),'published_polynomial_coefficients':POLY.tolist(),'published_table_V':TABLE.tolist(),'comparisons':{},'refits':{}}
models={'compact6':C.energy,'BRM_published_global':published,'BRM_published_exact_a0':lambda r,z:published(r,z,E2X)}
for name,mask in [('BRM_refit_global_full',np.ones(len(r),bool)),('BRM_refit_global_rs_le_1000',r<=1000)]:
    def fun(p):return (global_model(r[mask],z[mask],p)-y[mask])/sigma[mask]
    fits=[]
    for j in range(12):
        start=p0 if j==0 else np.clip(p0+rng.normal(0,.6,len(p0)),-23,6)
        f=least_squares(fun,start,bounds=(-24,7),max_nfev=1800,ftol=1e-10,xtol=1e-10,gtol=1e-7)
        fits.append(f)
    f=min(fits,key=lambda f:f.cost)
    p=f.x.copy();models[name]=lambda r,z,p=p:global_model(r,z,p)
    out['refits'][name]={'continuous_parameters':12,'training_points':int(mask.sum()),'log_bernstein_coefficients':p.tolist(),'objective':float(2*f.cost),'success':bool(f.success),'starts':12,'objectives':[float(2*f.cost) for f in fits],'note':'Same diagonal SE plus 0.020 mRy model floor as compact fit. Exact a0. Positive Bernstein controls; not a proof of global optimum or unconstrained polynomial optimum.'}
    print(name,2*f.cost,f.success,flush=True)
for name,fn in models.items():
    out['comparisons'][name]={'train':summary(fn(r,z),r,z,y),'hold':summary(fn(hr,hz),hr,hz,hy)}
out['comparisons']['BRM_published_TableV']={'train':summary(tabulated(r,z),r,z,y)}
hm=(hz==0)|(hz==1)
out['comparisons']['BRM_published_TableV']['hold_endpoints']=summary(tabulated(hr[hm],hz[hm]),hr[hm],hz[hm],hy[hm])
# Independent 4-parameter refit at each training spin. Compare endpoints only on holdouts.
per=[]
for j,zz in enumerate(Z):
    m=z==zz;start=np.log(TABLE[j]*np.array([1,-1,1,1]));fits=[]
    for k in range(8):
        p=start if k==0 else start+rng.normal(0,.6,4)
        f=least_squares(lambda p:(eq58(r[m],np.exp(p)*[1,-1,1,1],E2X)-y[m])/sigma[m],p,bounds=(-24,7),max_nfev=1800,ftol=1e-11,xtol=1e-11,gtol=1e-7)
        fits.append(f)
    f=min(fits,key=lambda f:f.cost);per.append(np.exp(f.x)*[1,-1,1,1])
per=np.array(per)
pred=eq58(r,per[np.argmin(abs(z[:,None]-Z),axis=1)],E2X)
hpred=eq58(hr[hm],per[np.where(hz[hm]==0,0,6)],E2X)
out['refits']['BRM_refit_per_spin']={'coefficients':per.tolist(),'parameters_per_spin':4,'total_parameters':28,'starts_per_spin':8}
out['comparisons']['BRM_refit_per_spin']={'train':summary(pred,r,z,y),'hold_endpoints':summary(hpred,hr[hm],hz[hm],hy[hm])}
out['low_density_z0']=[{'rs':rr,'reference_mry':ref,'se_mry':ss,**{name:float(1000*fn(np.array([rr]),np.array([0.]))[0]) for name,fn in models.items()}} for rr,ref,ss in [(1e6,-6.446452423039,.000367339241),(1e8,-2.157538732973007,.00003519886145)]]
out['notes']=['44 held-out points are excluded from coefficient optimization, but were inspected in earlier model development: not a blind validation.','QMC common scrambles imply correlated errors; objective is not independent chi-squared.','Published TableV applies only at tabulated spins; no invented interpolation.','Residuals compare with QMC sample means; QMC errors are not zero.','Full refits include densities to 1e8; restricted refit only uses rs<=1000 and extrapolates beyond that.']
(P/'results.json').write_text(json.dumps(out,indent=2)+'\n')
with (P/'pointwise.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['split','rs','zeta','QMC_mry','QMC_SE_mry']+[n+'_residual_mry' for n in models])
    for split,rr,zz,yy,ss in [('train',r,z,y,se),('hold',hr,hz,hy,hse)]:
        vals=[1000*(fn(rr,zz)-yy) for fn in models.values()]
        for i in range(len(rr)):w.writerow([split,rr[i],zz[i],1000*yy[i],1000*ss[i]]+[v[i] for v in vals])
for n,v in out['comparisons'].items():print(n,json.dumps(v.get('hold',v.get('hold_endpoints',{})).get('all',{})),flush=True)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(2,1,figsize=(8,7),sharex=True,layout='constrained')
colors=['#0072b2','#d55e00','#009e73','#cc79a7']
for ax,names in zip(axes,[['compact6','BRM_published_global'],['compact6','BRM_refit_global_full','BRM_refit_global_rs_le_1000']]):
    for k,n in enumerate(names):
        e=1000*(models[n](hr,hz)-hy)
        for zz in np.unique(hz):
            m=hz==zz;ax.plot(hr[m],e[m],'.-',lw=.7,alpha=.75,color=colors[k],label=n if zz==0 else None)
    ax.axhline(0,c='gray',lw=.7);ax.set_xscale('log');ax.set_ylabel('Fit − QMC (mRy/electron)');ax.legend(fontsize=8);ax.grid(alpha=.2)
axes[-1].set_xlabel(r'$r_s$');fig.suptitle('44 previously inspected holdout points; curves connect equal spin')
fig.savefig(P/'BRM_comparison.png',dpi=180)
