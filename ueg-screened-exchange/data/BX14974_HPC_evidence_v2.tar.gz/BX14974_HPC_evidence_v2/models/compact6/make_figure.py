from pathlib import Path
import numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from compact_kite import energy
P=Path(__file__).resolve().parent;d=np.load(P/'data/energy_data.npz');plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(1,2,figsize=(10,4),layout='constrained')
for a,(rk,zk,yk,title) in zip(ax,[('r','z','y','119 fitting points'),('hold_r','hold_z','hold_y','44 previously inspected holdouts')]):
 r,z,y=[d[k] for k in [rk,zk,yk]];e=1000*(energy(r,z)-y);sc=a.scatter(r,e,c=z,cmap='viridis',s=25,vmin=0,vmax=1)
 a.axhline(0,c='black',lw=.7);a.set(xscale='log',xlabel=r'$r_s$',ylabel='Fit minus QMC (mRy)',title=title,ylim=(-.23,.23))
fig.colorbar(sc,ax=ax,label=r'$\zeta$',shrink=.85);fig.savefig(P/'fit_comparison.png',dpi=170)
