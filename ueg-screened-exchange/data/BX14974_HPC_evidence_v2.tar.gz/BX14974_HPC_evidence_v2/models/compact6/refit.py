"""Reproduce the selected six-constant fit. Optional descriptive density CV.
The objective excludes the 44 energy holdouts and all derivative data.
"""
from pathlib import Path
from copy import deepcopy
import argparse,json,numpy as np
from scipy.optimize import least_squares
import compact_kite as M
from theory import moment,chd
arg=argparse.ArgumentParser();arg.add_argument('--cv',action='store_true');args=arg.parse_args()
ROOT=Path(__file__).resolve().parent;c=M.load_coefficients();d=np.load(ROOT/'data/energy_data.npz');cr=np.load(ROOT/'data/c1_reference.npz')
z=cr['z'];s=np.cbrt(1-z*z);m=moment(4,z);T=m**4*(cr['c1']+8*chd(z)*np.log(m))-c['c10'];B=s*(1-s)*(1+3*s);c['b']=float(B@T/(B@B))
x0=np.array(c['p']);lo=np.r_[np.full(4,-12),-2];hi=np.r_[np.full(4,8),2]
r,z,y,se=[d[k] for k in ['r','z','y','se']];sigma=np.hypot(se,c['model_floor_mry']/1000)
def unpack(x):cc=deepcopy(c);cc['p']=x.tolist();return cc
def fit(mask):
    pr=M.prepare(r[mask],z[mask],c)
    return least_squares(lambda x:(M.evaluate_prepared(pr,unpack(x))[0]-y[mask])/sigma[mask],x0,bounds=(lo,hi),max_nfev=2500,ftol=1e-11,xtol=1e-11,gtol=1e-7)
f=fit(np.ones(len(r),bool));cc=unpack(f.x);cc['refit']={'success':bool(f.success),'objective':float(2*f.cost)};(ROOT/'refitted_coefficients.json').write_text(json.dumps(cc,indent=2))
print('success',f.success,'objective',2*f.cost)
if args.cv:
    levels=np.unique(r)[1:-1];records=[]
    for j in range(3):
        test=np.isin(r,levels[j::3]);ff=fit(~test);res=1000*(M.energy(r[test],z[test],unpack(ff.x))-y[test]);records.append({'fold':j,'success':bool(ff.success),'held_densities':levels[j::3].tolist(),'rms_mry':float(np.mean(res*res)**.5),'max_abs_mry':float(max(abs(res)))})
    (ROOT/'density_cv.json').write_text(json.dumps({'note':'Descriptive only. Densities share QMC scrambles and the model family was explored with previously inspected data.','folds':records},indent=2));print(records)
