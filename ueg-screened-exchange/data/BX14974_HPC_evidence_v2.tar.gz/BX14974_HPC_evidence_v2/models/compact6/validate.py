from pathlib import Path
import json,platform,numpy as np
from theory import *
from compact_kite import load_coefficients,c1_approx,energy,evaluate,density_curvature
ROOT=Path(__file__).resolve().parent;c=load_coefficients();d=np.load(ROOT/'data/energy_data.npz')
tr=1000*(energy(d['r'],d['z'],c)-d['y']);hr=d['hold_r'];hz=d['hold_z'];res=1000*(energy(hr,hz,c)-d['hold_y'])
out={'status':'Exploratory, not blind/global error certification','energy_unit':'Ry/electron','runtime':{'python':platform.python_version(),'numpy':np.__version__},'adjustable_constant_count':6,'train_rms_mry':float(np.mean(tr*tr)**.5),'train_max_mry':float(max(abs(tr))),'holdout_rms_mry':float(np.mean(res*res)**.5),'holdout_max_mry':float(max(abs(res))),'holdout_points':np.c_[hr,hz].tolist(),'holdout_residual_mry':res.tolist()}
# Finite-domain diagnostics; absence of positive poles also follows algebraically.
r=np.geomspace(1e-8,1e12,2001);z=np.array([0,.1,.3,.5,.7,.9,.99,.9999,1.]);rr,zz=np.meshgrid(r,z);e,d1,d2=evaluate(rr,zz,c);assert np.isfinite(e).all() and np.isfinite(d1).all() and np.isfinite(d2).all()
ident=float(np.max(abs(energy(r,1,c)-energy(2**(-4/3)*r,0,c))));even=float(np.max(abs(energy(rr,zz,c)-energy(rr,-zz,c))));assert ident<1e-14 and even<1e-14
out['structural_checks']={'finite_grid_points':e.size,'domain_rs':[1e-8,1e12],'endpoint_identity_max_abs_ry':ident,'spin_evenness_max_abs_ry':even,'positive_pole_exclusion':'x>=0 and all q_j>0 imply Q>=1','energy_zero_counts_on_grid':[int(np.sum(e[j,1:]*e[j,:-1]<0)) for j in range(len(z))],'density_stationary_point_counts_on_grid':[int(np.sum(d1[j,1:]*d1[j,:-1]<0)) for j in range(len(z))],'zeta_grid':z.tolist()}
rr,zz=np.meshgrid(np.geomspace(.002,1e8,37),np.linspace(0,1,9));e,d1,d2=evaluate(rr,zz,c);h=.001;em2=energy(rr*np.exp(-2*h),zz,c);em=energy(rr*np.exp(-h),zz,c);ep=energy(rr*np.exp(h),zz,c);ep2=energy(rr*np.exp(2*h),zz,c)
f1=((em2-e)-8*(em-e)+8*(ep-e)-(ep2-e))/(12*h);f2=(-(em2-e)+16*(em-e)+16*(ep-e)-(ep2-e))/(12*h*h);err1=float(np.max(abs(f1-d1)));err2=float(np.max(abs(f2-d2)));assert err1<1e-9 and err2<1e-7
out['derivative_checks']={'max_D_difference_ry':err1,'max_D2_difference_ry':err2}
cv=np.load(ROOT/'data/c1_validation.npz');dc=c1_approx(cv['z'],c)-cv['c1'];out['c1_approx_max_error']=float(max(abs(dc)));maxde=0.
for r in np.geomspace(1e-5,1e4,200):
 z=cv['z'];m4=moment(4,z);r0=r/m4**4
 t=r0**.25;q2,q4,q5,q8=np.exp(c['p'][:4]);Q=1+q2*t*t+q4*t**4+q5*t**5+q8*t**8
 maxde=max(maxde,float(np.max(np.abs(r*dc*(-np.log1p(1/r0))/Q))))
out['c1_approx_effect_mesh_max_mry']=1000*maxde
K=1000*density_curvature(np.array([60.,70,75]),1,c);ref=np.array([3.924227653762966,3.701324724208,3.597047556026224]);out['density_curvature']={'rs':[60,70,75],'model_mry':K.tolist(),'reference_mry':ref.tolist(),'residual_mry':(K-ref).tolist(),'not_in_loss':True}
sc=json.loads((ROOT/'data/spin_curvature.json').read_text());r=np.array([v['rs'] for v in sc]);target=np.array([v['K_kite_mry'] for v in sc]);h=.002;e=energy(r[:,None],np.array([0,h,2*h]),c);S=1000*(32*(e[:,1]-e[:,0])-2*(e[:,2]-e[:,0]))/(12*h*h)
out['spin_curvature']={'rs':r.tolist(),'model_mry':S.tolist(),'reference_mry':target.tolist(),'residual_mry':(S-target).tolist(),'not_in_loss':True}
out['low_density']=[]
for r,ref,se in [(1e6,-6.446452423039,.000367339241),(1e8,-2.157538732973007,.00003519886145)]:
 val=float(1000*energy(r,0,c));out['low_density'].append({'rs':r,'fit_mry':val,'reference_mry':ref,'sampling_se_mry':se,'residual_mry':val-ref})
(ROOT/'validation_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['holdout_points','holdout_residual_mry']},indent=2))
