Start with DESIGN_ja.md. The selected formula has 6 adjustable constants for all spin polarizations.
python validate.py
python refit.py --cv
python make_figure.py
Evaluation only: NumPy. Fitting: SciPy. Figure: Matplotlib.
This is an energy interpolation candidate, not a replacement for precise spin-curvature or transition calculations.
The earlier 17-constant package and all original HPC sources/results are unchanged.
