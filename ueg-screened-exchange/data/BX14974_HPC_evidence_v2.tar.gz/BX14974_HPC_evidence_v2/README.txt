BX14974 numerical evidence archive, v2 (15 November 2026)
Author: Fumihiro Imoto

Completed corrected-ring HPC jobs 35, 36 and 37 are incorporated in this version.
The archive contains 20 indexed result sets and 57,846 RAW records, including
1,304 new ring records and 1,472 previously completed local validation records.
The supplied 42/43 validation files match the previous local results. Their
origin remains local, and the duplicate files are represented once.

DATASETS.csv lists each dataset and its role. STATUS.json records completion.
SHA256SUMS records the distribution's file hashes.

Layout
  results/original/          Original completed HPC jobs 10--50.
  results/followup/          Completed followups 14,33,34,41,51.
  results/corrected_ring/    Formal ring jobs 35 (728 tasks), 36 (360), 37 (216).
  results/local_validation/  Frozen-model validation at 38 new points and 8
                             independent map checks, computed locally.
  code/original/            Original source and input kit.
  code/followup/            Followup kit, including earlier input snapshots.
  code/corrected_ring/      Source and inputs used for jobs 35--37, with the
                             archived kite ensembles from jobs 33/34.
  models/compact6/          Frozen six-constant formula and development checks.
  models/BRM_comparison/    Published Eq58/59 and same-data comparisons.
  audits/current/          Recomputed numerical tables for revision v2.
  audits/corrected_ring/   Formal ring audit code, results and provenance.
  audits/historical_v1/    Previous revision's audit reports and local-ring
                             evidence, retained as dated historical records.
  audits/followup/         Earlier followup audits.
  audits/raw/              Earlier RAW-to-aggregate integrity audit.

Verification (Python standard library only)
  python3 verify_archive.py
This verifies distribution hashes, manifest fingerprints, every RAW task
identity and the source hashes in all manifests. There are 543 source-hash
entries across the 20 result sets.

Reproduce the corrected-ring analysis
Install the NumPy/SciPy versions appropriate to the code kit in a separate venv.
The commands below create copies for reanalysis, preserving the archived files.
Run from the root of this archive:

  mkdir -p reanalysis
  cp -a results/corrected_ring/. reanalysis/
  for run in reanalysis/hpc_35_ring_transition \
             reanalysis/hpc_36_ring_spin_curvature \
             reanalysis/hpc_37_ring_density_curvature; do
    python3 code/corrected_ring/scripts/analyze.py --run "$run"
    python3 code/corrected_ring/scripts/ring_report.py --run "$run"
  done

ring_report.py uses code/corrected_ring/previous/33_spin_and_transition and
previous/34_density_curvature. These archived kite replicas retain the shared
randomization covariance used for polarization and density differences.
The reported 1,000-bootstrap sampling interval uses the fixed source-code seed.
The archive's audit records the differences between the supplied HPC reports
and local reaggregation under the available numerical runtime.

Reproduce the low/high-density tables and formal endpoint crossing
  python3 audits/current/recompute_evidence.py --data-root . --output audit_recomputed
The endpoint crossing is recomputed from HPC35 RAW ring values at n=320 and
span=1.25, combined with the completed HPC33 kite means. Its sampling interval
is read from the report reproduced by the full ring analysis above.
To reproduce the frozen validation figure:
  python3 audits/current/plot_frozen_validation.py --data-root . --output-dir figures_recomputed

Interpretation of the data
  * The formal ring results supersede the earlier ring totals in jobs33/34.
    The earlier QMC values remain the kite source for the current results.
  * The compact six-constant formula supersedes the provisional fit in job41.
    Job41's coefficient calculations remain part of the supporting evidence.
  * Ring quadrature convergence, kite sampling uncertainty, spin-window
    dependence and density finite-difference step dependence are separate
    diagnostics. Quadrature differences provide empirical convergence checks.
  * The endpoint crossing and curvatures describe homogeneous HF+ring+kite
    energies on the sampled density/spin ranges. A finite spin grid cannot
    determine a continuous global minimum, and homogeneous density curvature
    cannot locate a finite-wave-vector CDW transition.
  * QMC sampling standard errors exclude common numerical/model systematics.
    N/R prefixes are correlated. Use paired differences when samples are shared.
  * Finite-reference correction uses the derived asymptote. The rs=1e6
    residual resolves higher-order terms. High-density fitted coefficients and
    power depend on the finite-density regression and remainder model.
  * The frozen38-point validation establishes improvement on those points.
    Energy-fit residuals and derivative accuracy require their own diagnostics.

The new ring audit closes the pending-HPC status of revision v1. Statements
about pending jobs in audits/historical_v1/ and the original code-kit README
record the earlier state before these computations were received.
Third-party papers and private referee reports are omitted from this data kit.
Journal upload and any public repository release are separate author actions.
