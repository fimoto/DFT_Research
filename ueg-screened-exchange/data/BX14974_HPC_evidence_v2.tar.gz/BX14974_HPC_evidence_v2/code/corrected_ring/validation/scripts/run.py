"""Run task IDs locally or inside a scheduler array. Safe resume; no MPI dependency."""
import argparse,time,concurrent.futures,warnings,signal
from common import *
from scipy.stats import qmc
import benites_direct as bd

def qmc_task(t,checkpoint,signature,stop_after=None):
    state=load(checkpoint) if checkpoint.exists() else {'signature':signature,'terms':{},'seconds':0.}
    if state['signature']!=signature:raise RuntimeError('checkpoint signature mismatch')
    scale=float(q_star(t['rs'])) if t['scale']=='qstar' else float(t['scale'])
    if scale<=0:raise ValueError('q scale must be positive')
    refs=t['references'];nv=1+2*len(refs);blocks=0;start=time.perf_counter()
    for term in (0,1):
        s=state['terms'].setdefault(str(term),{'n':0,'sum':[0.]*nv,'checkpoints':{}})
        sob=qmc.Sobol(9,scramble=True,seed=t['seeds'][term])
        if s['n']:sob.fast_forward(s['n'])
        for power in t['powers']:
            target=2**power
            while s['n']<target:
                count=min(2**min(t['chunk_power'],power),target-s['n'])
                u=sob.random(count);v=bd.evaluate_term(u,t['rs'],t['zeta'],term+1,scale)
                vals=[float(np.sum(v,dtype=np.float64))];rv=[]
                for ref in refs:
                    vref=bd.evaluate_term(u,ref,t['zeta'],term+1,scale)
                    vals.append(float(np.sum(v-vref,dtype=np.float64)));rv.append(float(np.sum(vref,dtype=np.float64)))
                vals+=rv
                if not np.isfinite(vals).all():raise ArithmeticError('nonfinite integrand/sum')
                s['sum']=(np.array(s['sum'])+vals).tolist();s['n']+=count;blocks+=1
                if s['n']==target:s['checkpoints'][str(power)]=(np.array(s['sum'])/target).tolist()
                if blocks%16==0 or s['n']==target:
                    save(checkpoint,state)
                if stop_after and blocks>=stop_after:
                    save(checkpoint,state);return None
    state['seconds']+=time.perf_counter()-start;save(checkpoint,state)
    return {'task':t,'signature':signature,'term_means':{str(m):[state['terms'][str(k)]['checkpoints'][str(m)] for k in (0,1)] for m in t['powers']},
            'columns':['direct']+['difference_ref_'+str(r) for r in refs]+['reference_energy_'+str(r) for r in refs],
            'reference_energy_added':False,'seconds':state['seconds']}

def one(args):
    run,t,signature,stop=args;out=run/'raw'/f'{t["id"]:07d}.json';ck=run/'checkpoints'/f'{t["id"]:07d}.json';lock=run/'locks'/str(t['id'])
    if out.exists():
        if load(out)['signature']!=signature:raise RuntimeError('output signature mismatch')
        return 'SKIP '+str(t['id'])
    lock.parent.mkdir(parents=True,exist_ok=True)
    try:lock.mkdir()
    except FileExistsError:raise RuntimeError(f'Task {t["id"]} locked. If its previous process is dead, remove ONLY {lock}')
    try:
        start=time.perf_counter()
        if t['kind']=='qmc':r=qmc_task(t,ck,signature,stop)
        elif t['kind']=='ring':
            from ring import ring
            r={'task':t,'signature':signature,'energy_ry':ring(t['rs'],t['zeta'],t['n'],t['span'])}
        else:
            import reviewer_numerics as rn
            v=rn.energy(t['rs'],t['zeta'],power=t['power'],reps=t['replicates'],nq=t['nq'],order=t['order'],nk=t['nk'],qmin=t['qmin'],qmax=t.get('qmax'),seed=t['seed'],bare=t.get('bare',False))
            r={'task':t,'signature':signature,'replicates_ry':v['replicates'].tolist(),'mean_ry':float(v['mean']),'se_ry':float(v['se']), 'profiles':[{'q':p['q'].tolist(),'qX':p['qX'].tolist(),'spin_scale':p['spin_scale']} for p in v['profiles']]}
        if r is None:return 'CHECKPOINT '+str(t['id'])
        r['wall_seconds_last_invocation']=time.perf_counter()-start;save(out,r)
        return f'DONE {t["id"]} {t["group"]} {r["wall_seconds_last_invocation"]:.2f}s'
    finally:lock.rmdir()

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',required=True);p.add_argument('--workers',type=int,default=1)
    p.add_argument('--task',type=int);p.add_argument('--group');p.add_argument('--max-tasks',type=int);p.add_argument('--stop-after-blocks',type=int,help='restart test only')
    a=p.parse_args()
    signal.signal(signal.SIGTERM,lambda signum,frame: (_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))
    run=Path(a.run).resolve();m=load(run/'manifest.json')
    check=dict(m);sig=check.pop('fingerprint');assert digest(check)==sig,'modified manifest'
    if sources()!=m['source_hashes']:raise SystemExit('Source changed after planning; create a new run directory.')
    now=runtime()
    # Machine/kernel strings may differ between scheduler nodes; numerical versions must not.
    for k in ['python','numpy','scipy','machine']:
        if now[k]!=m['runtime'][k]:raise SystemExit('Runtime differs from manifest: '+k)
    tasks=m['tasks']
    if a.task is not None:
        if not 0<=a.task<len(tasks):p.error('task outside 0..N-1')
        tasks=[tasks[a.task]]
    if a.group:
        tasks=[t for t in tasks if t['group']==a.group]
        if not tasks:p.error('no such group')
    if a.max_tasks:tasks=tasks[:a.max_tasks]
    jobs=[(run,t,sig,a.stop_after_blocks) for t in tasks]
    if a.workers==1:
        for x in jobs:print(one(x),flush=True)
    else:
        if a.workers<1:p.error('workers must be positive')
        with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as ex:
            for result in ex.map(one,jobs):print(result,flush=True)
if __name__=='__main__':main()
