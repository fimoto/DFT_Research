"""Fixed theory inputs, not empirical interpolation constants.
Phi branches use algebraically equivalent convergent series for stability.
"""
from pathlib import Path
from math import gamma
import json
import numpy as np

ALPHA=(4/(9*np.pi))**(1/3)
QTF=4*ALPHA/np.pi
E2X=np.log(2)/3-3*1.2020569031595942854/(2*np.pi**2)
CH0=-ALPHA*(1-np.log(2))/(6*np.pi**3)
A1=-4/(7*np.sqrt(2)*np.pi**1.5)*gamma(.25)/gamma(.75)
A2=8/15
A3=-16408/3375*np.sqrt(2*np.pi)/np.pi**2*gamma(.75)/gamma(.25)
LD=np.array([A1,A2,A3])/(4*QTF/3)**(np.arange(1,4)/4)

def load_coefficients(path=None):
    return json.loads(Path(path or Path(__file__).with_name('coefficients.json')).read_text())

def phi(a):
    """Closed Phi(a), with stable series near its removable limits.
    Numerical branches adapted from the project's highdensity.Phi_spin.
    They are evaluations of the same elementary logarithmic function.
    """
    a=np.asarray(a,float);ans=np.zeros_like(a)
    m=(a>0)&(a<=.5);x=a[m];acc=np.zeros_like(x)
    for k in range(67,3,-1):acc=acc*x+(-1)**(k+1)*(1/k+2/(k-3))
    ans[m]=1.5*x*x+x**3/3+2*x**3*np.log(x)+acc*x**4
    m=(a>.5)&(a<2);x=a[m]
    ans[m]=2*x*x-x+(1-2*x**3)*np.log1p(x)+2*x**3*np.log(x)
    m=a>=2;x=a[m];u=1/x;acc=np.zeros_like(x)
    for k in range(64,0,-1):acc=acc*u+(-1)**(k+1)*3*(k+1)/(k*(k+3))
    ans[m]=np.log(x)-2/3+acc*u
    return ans

def chd(zeta):
    z=np.asarray(zeta,float);xs=[np.cbrt(1+z),np.cbrt(1-z)];tot=np.zeros_like(z)
    for x in xs:
        for y in xs:
            a=np.divide(y,x,out=np.zeros_like(z),where=x>0)
            tot+=x*x*phi(a)
    return CH0*tot/(4*(1-np.log(2)))

def moment(n,z):
    return ((1+z)**(n/3)+(1-z)**(n/3))/2

