"""Six-constant compact fit: sparse log-Pade, no empirical spin correction."""
from pathlib import Path
import json,numpy as np
from theory import E2X,LD,chd,moment

def load_coefficients(path=None):
    return json.loads(Path(path or Path(__file__).with_name('coefficients.json')).read_text())

def c1_bar(z,c):
    s=np.cbrt(1-np.asarray(z)**2);return c['c10']+s*(1-s)*(c['b']*(1+3*s))

def c1_approx(z,c=None):
    c=c or load_coefficients();m4=moment(4,np.asarray(z));return c1_bar(z,c)/m4**4-8*chd(z)*np.log(m4)

def prepare(rs,zeta,c):
    r,z=np.broadcast_arrays(np.asarray(rs,float),np.asarray(zeta,float));shape=r.shape;r=r.ravel();z=z.ravel()
    if np.any(~np.isfinite(r)) or np.any(r<=0) or np.any(~np.isfinite(z)) or np.any(abs(z)>1):raise ValueError('Require finite rs>0, |zeta|<=1')
    m4=moment(4,z);m5=moment(5,z);m6=moment(6,z);r0=r/m4**4;t=r0**.25;L=np.array([np.full_like(r,LD[0]),LD[1]*m5/m4**2,LD[2]*(1160*m6+891*m4*m5)/2051/m4**3])
    ell=-np.log1p(1/r0);a=m4**4*chd(z);b=c1_bar(z,c);ep=1/(1+r0);epp=-r0/(1+r0)**2;g=a*ell**2+b*ell;gp=(2*a*ell+b)*ep;gpp=2*a*ep**2+(2*a*ell+b)*epp
    return {'shape':shape,'t':t,'L':L,'logs':np.array([r0*g,r0*(g+gp),r0*(g+2*gp+gpp)])}

def evaluate_prepared(d,c):
    p=np.asarray(c['p']);q2,q4,q5,q8=np.exp(p[:4]);p4=p[4];t=d['t'];L=d['L'];u=1/(1+t);s=t/(1+t)
    q={0:1,2:q2,4:q4,5:q5,8:q8};p={0:E2X,2:E2X*q2,4:p4,5:q8*L[2],6:q8*L[1],7:q8*L[0]};Q=np.zeros((3,len(t)));N=np.zeros_like(Q)
    for j in range(3):
        Q[j]=sum((k/4)**j*a*s**k*u**(8-k) for k,a in q.items());N[j]=sum((k/4)**j*a*s**k*u**(8-k) for k,a in p.items())
    N+=d['logs']*u**8;E=N[0]/Q[0];D=(N[1]-E*Q[1])/Q[0];D2=(N[2]-E*Q[2]-2*D*Q[1])/Q[0]
    return tuple(v.reshape(d['shape']) for v in (E,D,D2))

def evaluate(rs,zeta=0,c=None):
    c=c or load_coefficients();return evaluate_prepared(prepare(rs,zeta,c),c)

def energy(rs,zeta=0,c=None):return evaluate(rs,zeta,c)[0]

def density_curvature(rs,zeta=0,c=None):
    e,d,d2=evaluate(rs,zeta,c);return (d2-3*d)/9
