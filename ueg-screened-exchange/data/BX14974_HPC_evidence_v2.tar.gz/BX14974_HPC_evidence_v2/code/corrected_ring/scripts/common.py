from pathlib import Path
import os,sys,json,hashlib,platform,tempfile
ROOT=Path(__file__).resolve().parents[1]
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[k]='1'
sys.path[:0]=[str(ROOT/'vendor/src'),str(ROOT/'vendor/external'),str(ROOT/'vendor/spin')]
import numpy as np
import scipy
from ueg_exchange.constants import E2X,ALPHA_L,q_star,asymptotic_kite

def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def sources():
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['scripts','vendor','previous'] for p in sorted((ROOT/folder).rglob('*')) if p.is_file() and p.suffix in ('.py','.json','.npz')}
def runtime():return {'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'machine':platform.machine()}
def save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.tmp.',dir=path.parent)
    try:
        with os.fdopen(fd,'w') as f:json.dump(obj,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
def load(p):return json.loads(Path(p).read_text())
def stats(a):
    a=np.asarray(a);return a.mean(axis=0),a.std(axis=0,ddof=1)/np.sqrt(len(a))
def hf(rs,z):
    return 3/(5*ALPHA_L**2*rs**2)*((1+z)**(5/3)+(1-z)**(5/3))/2-3/(2*np.pi*ALPHA_L*rs)*((1+z)**(4/3)+(1-z)**(4/3))/2
