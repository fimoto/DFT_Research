"""Freeze one input JSON into independent, restartable tasks; never submits jobs."""
import argparse,collections
from common import *

def build(cfg):
    tasks=[];seen=set()
    for g in cfg['groups']:
        if g['gid'] in seen:raise ValueError('duplicate seed group id')
        seen.add(g['gid'])
        points=g.get('points',[[r,z] for r in g.get('rs',[]) for z in g.get('zeta',[0.])])
        if g.get('scaled_endpoints'):
            points=points+[[r*2**(-4/3),0.] for r in g['rs']]
        points=list(dict.fromkeys((float(r),float(z)) for r,z in points))
        if not points or any(r<=0 or abs(z)>1 for r,z in points):raise ValueError('invalid points')
        if len(points)>4000:raise ValueError('seed stride exceeded: too many density nodes')
        if g['kind']=='qmc':
            if not (2<=g['replicates']<=512):raise ValueError('replicates must be 2..512')
            if not 0<=min(g['powers'])<=max(g['powers'])<=30:raise ValueError('invalid Sobol power')
        for pi,(rs,z) in enumerate(points):
            if g['kind']=='qmc':
                node=pi if g.get('independent_points',False) else 0
                for rep in range(g['replicates']):
                    base=cfg['seed_base']+g['gid']*10000000+node*2048+2*rep
                    if base+1>=2**32:raise ValueError('seed exceeds uint32')
                    t=dict(kind='qmc',group=g['name'],gid=g['gid'],point=pi,rs=rs,zeta=z,rep=rep,seeds=[base,base+1],
                        powers=sorted(set(g['powers'])),chunk_power=cfg['chunk_power'],scale=g.get('scale',2.),references=g.get('references',[]),
                        independent_points=g.get('independent_points',False))
                    tasks.append(t)
            elif g['kind']=='ring':
                for n in g['orders']:
                    for span in g.get('spans',[1.0]):tasks.append(dict(kind='ring',group=g['name'],gid=g['gid'],rs=rs,zeta=z,n=n,span=span))
            elif g['kind']=='axis':
                for setting_id,setting in enumerate(g['settings']):
                    setting=dict(setting); reps=setting.pop('replicates'); block=g.get('replicate_block',2)
                    if reps<2 or block<2 or reps%block:raise ValueError('axis replicate blocks must divide R and be >=2')
                    for start in range(0,reps,block):
                        tasks.append(dict(kind='axis',group=g['name'],gid=g['gid'],rs=rs,zeta=z,
                            seed=cfg['seed_base']+g['gid']*10000000+start,
                            setting_id=setting_id,replicate_start=start,total_replicates=reps,replicates=block,**setting))
            else:raise ValueError('unknown calculation kind')
    for i,t in enumerate(tasks):t['id']=i
    return tasks

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input');p.add_argument('--run',required=True);a=p.parse_args()
    cfg=load(a.input);tasks=build(cfg);run=Path(a.run);mp=run/'manifest.json'
    obj={'schema':1,'input':cfg,'source_hashes':sources(),'runtime':runtime(),'tasks':tasks}
    obj['fingerprint']=digest(obj)
    if mp.exists():
        old=load(mp); check=dict(old); signature=check.pop('fingerprint')
        if digest(check)!=signature:raise SystemExit('Modified manifest')
        if any(old[k]!=obj[k] for k in ['input','source_hashes','tasks']) or any(old['runtime'][k]!=obj['runtime'][k] for k in ['python','numpy','scipy','machine']):raise SystemExit('Existing run has different input, source or numerical environment; choose a NEW --run directory.')
    else:save(mp,obj)
    counts=collections.Counter(t['group'] for t in tasks)
    evaluations=sum(2*(1+len(t['references']))*2**max(t['powers']) for t in tasks if t['kind']=='qmc')
    print(json.dumps({'tasks':len(tasks),'groups':dict(counts),'qmc_evaluations':evaluations,'manifest':str(mp)},indent=2))
if __name__=='__main__':main()
