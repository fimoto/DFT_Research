"""Plot completed frozen validation; requires matplotlib (plotting only)."""
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1];out=root/'validation/results'
rows=list(csv.DictReader((out/'validation_points.csv').open()))
def arr(key):return np.array([float(v[key]) for v in rows])
r=arr('rs');z=arr('zeta');c=arr('compact_residual_mry');b=arr('BRM_residual_mry');se=arr('sampling_SE_mry')
fig,axes=plt.subplots(2,1,figsize=(8,7),sharex=True,layout='constrained')
axes[0].scatter(r,abs(b),c='#d55e00',marker='x',label='BRM Eq. (58)+(59), published')
axes[0].scatter(r,abs(c),c='#0072b2',marker='o',s=22,label='Frozen six-constant formula')
axes[0].set_yscale('log');axes[0].set_ylabel('Absolute residual (mRy/electron)');axes[0].legend(fontsize=9)
axes[1].errorbar(r,c,yerr=2*se,fmt='o',ms=3,color='#0072b2',ecolor='#8db7d3',lw=.8,label='Frozen formula; bars = 2 sampling SE')
axes[1].axhline(0,c='gray',lw=.8)
for y in [-.25,.25]:axes[1].axhline(y,c='#d55e00',ls='--',lw=.8)
axes[1].set_ylabel('Signed residual (mRy/electron)');axes[1].set_xlabel(r'$r_s$');axes[1].legend(fontsize=9)
for ax in axes:ax.set_xscale('log');ax.grid(alpha=.2)
fig.suptitle('38 new direct-integration points; no refitting')
fig.savefig(out/'frozen_validation.png',dpi=180)
