"""Panel-quadrature RPA energy and analytic fixed-spin density curvature.

D = d/d log(rs), K=(D^2-3D)E/9. With E=C rs^-2 int f(c),
c proportional to rs, f(c)=log(1+c)-c, the kernel for 9K is
10 f - 6c f' + c^2 f''. Finite integration limits are checked by span.
"""
from common import *
from functools import lru_cache
from scipy.special import roots_legendre
from ueg_exchange.constants import q_tf_sq
from ueg_exchange.lindhard import lindhard_shape

@lru_cache(None)
def gauss(n):return roots_legendre(n)

def log1pmx(c):
    c=np.asarray(c,float);out=np.empty_like(c);m=c<.001;x=c[m]
    out[m]=-x*x/2+x**3/3-x**4/4+x**5/5-x**6/6
    out[~m]=np.log1p(c[~m])-c[~m]
    return out

def curvature_kernel(c):
    c=np.asarray(c,float);out=np.empty_like(c);m=c<.05;t=c[m]
    out[m]=sum((-1.)**(k+1)*(k-2)*(k-5)/k*t**k for k in range(3,17))
    t=c[~m];out[~m]=10*(np.log1p(t)-t)+6*t*t/(1+t)-t*t/(1+t)**2
    return out

def grid(edges,n):
    edges=np.unique(np.asarray(edges,float))
    if np.any(edges<=0):raise ValueError('positive quadrature bounds required')
    x,w=gauss(n);a=[];b=[]
    for lo,hi in zip(edges[:-1],edges[1:]):
        l,h=np.log(lo),np.log(hi);v=np.exp(l+(x+1)*(h-l)/2)
        a.extend(v);b.extend(w*(h-l)/2*v)
    return np.array(a),np.array(b)

def ring_observables(rs,zeta,n=240,span=1.25):
    if not np.isfinite(rs) or rs<=0 or not np.isfinite(zeta) or abs(zeta)>1 or n<2 or span<1:raise ValueError('invalid ring input')
    Q2=q_tf_sq(rs);sq=max(1.,Q2**.25);sn=max(1.,np.sqrt(Q2/3))
    xs=[x for x in [np.cbrt(1+zeta),np.cbrt(1-zeta)] if x>0]
    qlo,qhi=sq*10**(-7*span),sq*10**(7*span)
    # Internal panels respect both response branches and each 2*kF cusp.
    qe=[qlo,qhi]+[c*x for x in xs for c in [.15,2,3] if qlo<c*x<qhi]
    nlo,nhi=sn*10**(-8*span),sn*10**(9*span)
    ne=[nlo,nhi]+[v for v in [1e-4,1e-2,1.,sn] if nlo<v<nhi]
    q,wq=grid(qe,n);nu,wn=grid(ne,n);e=k=0.
    for j in range(0,len(q),8):
        qq=q[j:j+8,None];nn=nu[None,:]
        L=sum(.5*x*lindhard_shape(qq/x,nn/x**2) for x in xs);c=Q2*L/qq**2
        if np.any(c<0) or not np.isfinite(c).all():raise ArithmeticError('invalid Lindhard response')
        weight=(wq[j:j+8]*q[j:j+8]**2)[:,None]*wn[None,:]
        e+=np.sum(weight*log1pmx(c));k+=np.sum(weight*curvature_kernel(c))
    fac=3/(4*np.pi)*2/(ALPHA_L*rs)**2
    return {'energy_ry':float(fac*e),'density_curvature_ry':float(fac*k/9),
            'method':'panel_analytic_density_v1','n_per_panel':n,'q_nodes':len(q),'nu_nodes':len(nu),'span':span}

def ring(rs,zeta,n=240,span=1.25):return ring_observables(rs,zeta,n,span)['energy_ry']
