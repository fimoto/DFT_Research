"""Aggregate complete independent scrambles; retain covariance and missing-task lists."""
import argparse,csv
from common import *

def aggregate(run,allow=False):
    manifest=load(run/'manifest.json');sig=manifest['fingerprint'];records=[];missing=[]
    for t in manifest['tasks']:
        p=run/'raw'/f'{t["id"]:07d}.json'
        if not p.exists():missing.append(t['id']);continue
        r=load(p)
        if r['signature']!=sig or r['task']!=t:raise ValueError('mismatched result '+str(p))
        records.append(r)
    report=run/'analysis';report.mkdir(exist_ok=True);save(report/'completion.json',{'missing':missing,'expected':len(manifest['tasks']),'completed':len(records)})
    if missing and not allow:raise SystemExit(f'{len(missing)} tasks incomplete; see analysis/completion.json. Finish or use --allow-incomplete for diagnostics only.')
    ensembles={};arrays={};rows=[];prefix=[]
    for g in manifest['input']['groups']:
        rr=[r for r in records if r['task']['group']==g['name']]
        if g['kind']!='qmc' or not rr:continue
        pts=sorted({(t['rs'],t['zeta']) for t in manifest['tasks'] if t['group']==g['name']})
        # Require the SAME independent replica IDs at every point. Partial results are not padded.
        by={p:{r['task']['rep']:r for r in rr if (r['task']['rs'],r['task']['zeta'])==p} for p in pts}
        reps=sorted(set.intersection(*(set(v) for v in by.values())))
        if len(reps)<2:continue
        for power in g['powers']:
            arr=np.array([[by[p][j]['term_means'][str(power)] for p in pts] for j in reps]) # R,P,2,V
            for vi,col in enumerate(rr[0]['columns']):
                terms=arr[:,:,:,vi].transpose(0,2,1) # R,2,P
                const=0. if col.startswith('difference_ref_') else E2X
                est=terms.mean(0).sum(0)+const
                if g.get('independent_points',False):cov=np.diag(terms.var(0,ddof=1).sum(0)/len(reps))
                else:cov=sum(np.atleast_2d(np.cov(terms[:,k,:],rowvar=False,ddof=1)) for k in (0,1))/len(reps)
                key=f'{g["name"]}__m{power}__{col}'
                ensembles[key]={'group':g['name'],'power':power,'column':col,'points':pts,'replicate_ids':reps,'independent_points':g.get('independent_points',False),'constant_ry':const,'mean_ry':est.tolist(),'covariance_mean_ry2':cov.tolist(),'incomplete':len(reps)!=g['replicates'],'references_corrected':False if col.startswith('difference') else None}
                arrays[key]=terms
                for pi,(rs,z) in enumerate(pts):
                    rows.append(dict(group=g['name'],m=power,R=len(reps),column=col,rs=rs,zeta=z,mean_mry=1000*est[pi],se_mry=1000*np.sqrt(cov[pi,pi]),three_term_mry=1000*asymptotic_kite(rs,z)))
                for count in sorted(set([2,4,8,16,32,64,128,len(reps)])):
                    if count>len(reps):continue
                    tt=terms[:count];ee=tt.mean(0).sum(0)+const;se=np.sqrt(tt.var(0,ddof=1).sum(0)/count)
                    for pi,(rs,z) in enumerate(pts):prefix.append(dict(group=g['name'],m=power,R=count,column=col,rs=rs,zeta=z,mean_mry=1000*ee[pi],se_mry=1000*se[pi]))
    save(report/'ensembles.json',ensembles);np.savez_compressed(report/'replicates.npz',**arrays)
    for name,data in [('energies.csv',rows),('replicate_prefixes.csv',prefix)]:
        if data:
            with (report/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=data[0]);w.writeheader();w.writerows(data)
    ringrows=[r for r in records if r['task']['kind']=='ring'];axisrows=[r for r in records if r['task']['kind']=='axis']
    save(report/'ring.json',ringrows);save(report/'axis.json',axisrows)
    # Paired reference differences include covariance (do not add their SEs independently).
    checks=[]
    for key,v in ensembles.items():
        if not v['column'].startswith('difference_ref_'):continue
        cousins=[(k,w) for k,w in ensembles.items() if w['group']==v['group'] and w['power']==v['power'] and w['column'].startswith('difference_ref_') and k>key]
        for k,w in cousins:
            d=arrays[key]-arrays[k];mean=d.mean(0).sum(0);se=np.sqrt(d.var(0,ddof=1).sum(0)/len(d))
            checks.append({'left':key,'right':k,'points':v['points'],'paired_difference_mry':(1000*mean).tolist(),'paired_se_mry':(1000*se).tolist()})
    save(report/'reference_sensitivity.json',checks)
    print(f'{len(ensembles)} ensembles; CSV, full covariance and raw scrambles in {report}')
    return ensembles

def bootstrap(terms,independent,rng):
    R,T,P=terms.shape
    if independent:
        return np.array([sum(terms[rng.integers(R,size=R),t,p].mean() for t in range(T)) for p in range(P)])
    return sum(terms[rng.integers(R,size=R),t,:].mean(0) for t in range(T))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',required=True);p.add_argument('--allow-incomplete',action='store_true');a=p.parse_args();aggregate(Path(a.run),a.allow_incomplete)
if __name__=='__main__':main()
