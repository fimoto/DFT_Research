"""Evaluate frozen predictions against NEW direct integrals; never fits anything."""
import argparse,csv,hashlib
from common import *

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--primary',required=True);ap.add_argument('--map-check');ap.add_argument('--out',default=str(ROOT/'validation/results'));args=ap.parse_args()
    outdir=Path(args.out);outdir.mkdir(parents=True,exist_ok=True);vroot=ROOT/'validation';freeze=load(vroot/'freeze.json')
    for name,h in freeze['fit_files'].items():
        assert hashlib.sha256((vroot/'frozen_fit'/name).read_bytes()).hexdigest()==h,'Frozen model changed'
    audit=load(ROOT/'verification/validation_freeze_hash.json')
    assert hashlib.sha256((vroot/'freeze.json').read_bytes()).hexdigest()==audit['sha256'],'Freeze changed'
    primary=Path(args.primary);man=load(primary/'manifest.json');ens=load(primary/'analysis/ensembles.json');aa=np.load(primary/'analysis/replicates.npz')
    assert load(primary/'analysis/completion.json')['missing']==[]
    assert man['input']==load(vroot/'inputs/42_frozen_validation.json')
    key='frozen_validation__m20__direct';e=ens[key];pts=list(map(tuple,e['points']));fr=list(map(tuple,freeze['points']));order=[fr.index(p) for p in pts]
    assert len(pts)==38 and set(pts)==set(fr) and e['independent_points']
    r,z=np.array(pts).T;target=np.array(e['mean_ry']);t=aa[key];se=np.sqrt(np.diag(e['covariance_mean_ry2']))
    predictions={'compact6':np.array(freeze['compact_predictions_ry'])[order],'BRM_published_global':np.array(freeze['BRM_predictions_ry'])[order]}
    table0=np.array([.10215,-.01382,.46529,.00364]);table1=np.array([.04143,-.00571,.19503,.00088]);end=(z==0)|(z==1)
    a=np.where((z==0)[:,None],table0,table1).T;a1,a2,a3,a4=a
    tab=.04836/(1+a1*r)+a2*r*np.log1p(1/(r*(a3+a4*np.sqrt(r))));tab[~end]=np.nan
    categories=np.array(freeze['point_categories'])[order];masks={'all':np.ones(len(r),bool),'broad_grid':categories=='broad_grid','focus':categories=='focused_check','rs_le_1':r<=1,'rs_1_to_1000':(r>=1)&(r<=1000),'rs_gt_1000':r>1000,'spin_endpoints':end,'spin_interior':~end}
    def stat(pred,y,mask):
        err=1000*(pred-y);idx=np.flatnonzero(mask);j=idx[np.argmax(abs(err[mask]))]
        return {'n':int(mask.sum()),'rms_mry':float(np.mean(err[mask]**2)**.5),'max_abs_mry':float(max(abs(err[mask]))),'worst_rs':float(r[j]),'worst_zeta':float(z[j]),'worst_sampling_se_mry':float(1000*se[j])}
    summary={name:{band:stat(p,target,m) for band,m in masks.items()} for name,p in predictions.items()}
    summary['BRM_TableV_endpoints']={'spin_endpoints':stat(tab,target,end)}
    # Stratified nonparametric bootstrap: each point has independent scrambles, and the two terms use independent seeds.
    rng=np.random.default_rng(422026);br=[]
    for _ in range(2000):
        yy=np.full(len(pts),e['constant_ry'])
        for k in [0,1]:
            ids=rng.integers(len(t),size=(len(t),len(pts)));yy+=np.take_along_axis(t[:,k,:],ids,axis=0).mean(0)
        rms=[float(np.mean((1000*(p-yy))**2)**.5) for p in predictions.values()]
        br.append([*rms,rms[1]-rms[0]])
    br=np.array(br);boots={name:np.quantile(br[:,j],[.025,.975]).tolist() for j,name in enumerate(['compact_rms_mry','BRM_rms_mry','BRM_minus_compact_rms_mry'])}
    convergence=[]
    for power in [18,19]:
        k=f'frozen_validation__m{power}__direct';low=ens[k];assert low['points']==e['points'];dt=t-aa[k];delta=dt.mean(0).sum(0);ds=np.sqrt(dt.var(0,ddof=1).sum(0)/len(t))
        convergence.append({'low_power':power,'high_power':20,'paired_difference_mry':(1000*delta).tolist(),'paired_se_mry':(1000*ds).tolist(),'points_over_3se':[list(pts[i]) for i in np.flatnonzero(abs(delta)>3*ds)],'low_power_summary':{name:stat(p,np.array(low['mean_ry']),masks['all']) for name,p in predictions.items()}})
    maps=[]
    if args.map_check:
        mp=Path(args.map_check);assert load(mp/'analysis/completion.json')['missing']==[]
        assert load(mp/'manifest.json')['input']==load(vroot/'inputs/43_validation_map4.json')
        me=load(mp/'analysis/ensembles.json')['validation_map4__m20__direct'];mm=np.array(me['mean_ry']);ms=np.sqrt(np.diag(me['covariance_mean_ry2']))
        for j,p in enumerate(me['points']):
            i=pts.index(tuple(p));diff=1000*(mm[j]-target[i]);combined=1000*np.hypot(ms[j],se[i])
            maps.append({'rs':p[0],'zeta':p[1],'scale2_mry':1000*target[i],'scale4_mry':1000*mm[j],'difference_mry':diff,'independent_combined_se_mry':combined,'difference_over_se':diff/combined,'compact_residual_scale4_mry':1000*(predictions['compact6'][i]-mm[j]),'scale4_se_mry':1000*ms[j]})
    err=1000*(predictions['compact6']-target);threshold=freeze['acceptance']
    result={'status':'Prospective frozen-model validation on 38 new points; no refitting','freeze_sha256':audit['sha256'],'run_fingerprint':man['fingerprint'],'units':'mRy/electron for errors','summary':summary,'bootstrap_95_sampling_only':boots,'pointwise_sampling_se_mry':(1000*se).tolist(),'powers':convergence,'map_check':maps,'model_targets':threshold,'diagnostics':{'rms_target_met_on_sample_means':summary['compact6']['all']['rms_mry']<=threshold['exploratory_rms_target_mry'],'max_target_met_on_sample_means':summary['compact6']['all']['max_abs_mry']<=threshold['exploratory_max_abs_target_mry'],'reference_se_target_met_all_points':bool(np.all(1000*se<=threshold['numerical_reference_se_target_mry'])),'largest_sampling_se_mry':float(1000*max(se)),'improved_points_vs_published_BRM':int(np.sum(abs(err)<abs(1000*(predictions['BRM_published_global']-target))))},'notes':['Bootstrap covers finite-replica sampling, not integrand systematics or a global interpolation bound.','Equal weighting of the predefined points; parameter estimates and model form unchanged.','Fixed-spin TableV comparison applies only to endpoints.','Thresholds were recorded before new integral results; failure is reported, not repaired by retuning.','m18/m19 are nested checkpoints of m20, so convergence SEs use paired differences.']}
    save(outdir/'validation_results.json',result)
    with (outdir/'validation_points.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['rs','zeta','category','QMC_mry','sampling_SE_mry','compact6_mry','BRM_global_mry','compact_residual_mry','BRM_residual_mry','BRM_TableV_mry_endpoints_only'])
        for i,(rr,zz) in enumerate(pts):w.writerow([rr,zz,categories[i],1000*target[i],1000*se[i],1000*predictions['compact6'][i],1000*predictions['BRM_published_global'][i],err[i],1000*(predictions['BRM_published_global'][i]-target[i]),1000*tab[i] if end[i] else ''])
    print(json.dumps({k:result[k] for k in ['summary','bootstrap_95_sampling_only','diagnostics']},indent=2))
if __name__=='__main__':main()
