"""Independent derivative and regression checks for corrected ring integrator."""
from common import *
from ring import ring_observables,ring,curvature_kernel
import time
def main():
    start=time.time();rows=[]
    # Leading kernel coefficient is -2*c^3/3; c^2 cancels identically.
    assert abs(float(curvature_kernel(np.array([1e-7]))[0])/(-2e-21/3)-1)<1e-6
    for rs,expected in [(60.,-4.118478979089417),(70.,-3.858757050045261),(75.,-3.7448570185352614)]:
        v=ring_observables(rs,1.,240,1.25);err=1000*v['density_curvature_ry']-expected
        assert abs(err)<1e-8,err
        rows.append({'rs':rs,'regression_delta_K_mry':err})
    center=70.;h=.01
    for z in [0.,1.]:
        vals=[ring_observables(center*np.exp(j*h),z,180,1.25) for j in range(-2,3)]
        e=np.array([v['energy_ry'] for v in vals]);w=(np.array([-1,16,-30,16,-1])/(12*h*h)-3*np.array([1,-8,0,8,-1])/(12*h))/9
        fd=float((e-e[2])@w);analytic=vals[2]['density_curvature_ry'];error=1000*(fd-analytic)
        assert abs(error)<1e-5,error
        rows.append({'rs':center,'zeta':z,'analytic_K_mry':1000*analytic,'fd_K_mry':1000*fd,'difference_mry':error,'h':h})
    # Independently known audit spin curvature at rs=70 is cross-checked through existing reference file by report, not assumed here.
    a=ring(60.,.3,120,1.25);b=ring(60.,-.3,120,1.25);assert abs(a-b)<1e-13
    out={'passed':True,'checks':rows,'spin_evenness_error_ry':a-b,'seconds':time.time()-start,'note':'Regression uses previous panel audit; finite-difference check independently tests the density derivative kernel at two spins.'}
    save(ROOT/'verification/ring_tests.json',out);print(json.dumps(out,indent=2))
if __name__=='__main__':main()
