"""Ring-only reanalysis using archived, unchanged kite ensembles (33/34).
Numerical convergence differences are diagnostics, not rigorous error bounds.
"""
import argparse
from common import *
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq

def estimate(t):return float(t.mean(0).sum()),float(np.sqrt(t.var(0,ddof=1).sum()/len(t)))
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run',required=True);args=ap.parse_args();run=Path(args.run)
    m=load(run/'manifest.json');rows=load(run/'analysis/ring.json')
    complete=load(run/'analysis/completion.json')
    if complete['missing']:raise SystemExit('Incomplete ring results')
    if any(v.get('method')!='panel_analytic_density_v1' for v in rows):raise ValueError('old or unknown ring result')
    R={(v['task']['n'],v['task']['span'],v['task']['rs'],v['task']['zeta']):v for v in rows}
    settings=sorted({k[:2] for k in R});best=max(settings)
    out={'definition':'Ry/electron; K_n=(D^2-3D)E/9; spin curvature=d^2 E/d zeta^2 at zero spin','best_setting':best,'settings':settings,'convergence':[],
         'warning':'Ring quadrature differences are not rigorous bounds. Kite sampling SE is separate. HF+RPA-ring+kite is an approximation, not an exact UEG phase diagram.'}
    for r,z in sorted({k[2:] for k in R}):
        b=R[best[0],best[1],r,z];out['convergence'].append({'rs':r,'zeta':z,'settings':[{'n':n,'span':s,'E_mry':1000*R[n,s,r,z]['energy_ry'],'K_mry':1000*R[n,s,r,z]['density_curvature_ry'],'delta_E_from_best_mry':1000*(R[n,s,r,z]['energy_ry']-b['energy_ry']),'delta_K_from_best_mry':1000*(R[n,s,r,z]['density_curvature_ry']-b['density_curvature_ry'])} for n,s in settings]})
    names={g['name'] for g in m['input']['groups']}
    if 'ring_density_curvature' in names:
        old=ROOT/'previous/34_density_curvature';ens=load(old/'ensembles.json');aa=np.load(old/'replicates.npz');out['density_curvature']=[]
        for key,e in ens.items():
            if e['group']!='density_curvature' or e['column']!='direct':continue
            rs=np.array(e['points'])[:,0];t=aa[key]
            for center in [60.,70.,75.]:
                i0=int(np.argmin(abs(rs-center)))
                for h in [.005,.01,.02]:
                    target=center*np.exp(np.arange(-2,3)*h);ids=[int(np.argmin(abs(rs-v))) for v in target]
                    assert np.allclose(rs[ids],target,rtol=1e-13,atol=0)
                    w=(np.array([-1,16,-30,16,-1])/(12*h*h)-3*np.array([1,-8,0,8,-1])/(12*h))/9
                    km,se=estimate((t[:,:,ids]-t[:,:,i0,None])@w)
                    # Analytic HF density derivative (kinetic r^-2 and exchange r^-1).
                    from common import ALPHA_L
                    ehf_kin=3/(5*ALPHA_L**2*center**2)*2**(2/3)
                    ehf_x=-3/(2*np.pi*ALPHA_L*center)*2**(1/3)
                    khf=(10*ehf_kin+4*ehf_x)/9
                    vals=[]
                    for n,s in settings:
                        analytic=R[n,s,center,1.]['density_curvature_ry']
                        finite=float(w@np.array([R[n,s,float(v),1.]['energy_ry']-R[n,s,center,1.]['energy_ry'] for v in rs[ids]]))
                        vals.append({'n':n,'span':s,'K_ring_analytic_mry':1000*analytic,'K_ring_fd_mry':1000*finite,'analytic_minus_fd_mry':1000*(analytic-finite),'K_total_mry':1000*(khf+km+analytic)})
                    out['density_curvature'].append({'rs':center,'power':e['power'],'log_step':h,'stencil':'5point','K_kite_mry':1000*km,'K_hf_mry':1000*khf,'kite_sampling_se_mry':1000*se,'settings':vals})
    else:
        old=ROOT/'previous/33_spin_and_transition';ens=load(old/'ensembles.json');aa=np.load(old/'replicates.npz')
        if 'ring_curvature_precision' in names:
            out['spin_curvature']=[]
            for key,e in ens.items():
                if e['group']!='curvature_precision' or e['column']!='direct':continue
                pts=list(map(tuple,e['points']));t=aa[key]
                for rs in [32.,60.,70.,75.,110.]:
                    i0=pts.index((rs,0.))
                    for maxz in [.04,.1,.2]:
                        zs=np.array([z for r,z in pts if r==rs and 0<z<=maxz]);ids=[pts.index((rs,float(z))) for z in zs]
                        for degree in [2,3]:
                            w=2*np.linalg.pinv(np.column_stack([zs**(2*j) for j in range(1,degree+1)]))[0]
                            km,se=estimate((t[:,:,ids]-t[:,:,i0,None])@w)
                            khf=float(w@np.array([hf(rs,z)-hf(rs,0) for z in zs]));vals=[]
                            for n,s in settings:
                                kr=float(w@np.array([R[n,s,rs,float(z)]['energy_ry']-R[n,s,rs,0.]['energy_ry'] for z in zs]))
                                vals.append({'n':n,'span':s,'K_ring_mry':1000*kr,'K_total_mry':1000*(khf+km+kr)})
                            out['spin_curvature'].append({'rs':rs,'power':e['power'],'max_zeta':maxz,'degree':degree,'K_kite_mry':1000*km,'kite_sampling_se_mry':1000*se,'settings':vals})
        if 'ring_spin_precision' in names:
            out['endpoint_crossings']=[];out['polarization_differences']=[];rng=np.random.default_rng(352026)
            for key,e in ens.items():
                if e['group']!='spin_precision' or e['column']!='direct':continue
                pts=list(map(tuple,e['points']));t=aa[key];rs=sorted({r for r,z in pts});ids0=[pts.index((r,0.)) for r in rs];ids1=[pts.index((r,1.)) for r in rs]
                delta=t[:,:,ids1]-t[:,:,ids0];mu=delta.mean(0).sum(0);x=np.log(rs)
                for n,s in settings:
                    fixed=np.array([hf(r,1)-hf(r,0)+R[n,s,r,1.]['energy_ry']-R[n,s,r,0.]['energy_ry'] for r in rs])
                    def crossing(y):
                        if y[0]*y[-1]>=0:return None
                        return float(np.exp(brentq(PchipInterpolator(x,y),x[0],x[-1])))
                    rec={'power':e['power'],'n':n,'span':s,'rs_crossing':crossing(fixed+mu),'delta_at_nodes_mry':(1000*(fixed+mu)).tolist(),'rs_nodes':rs}
                    if (n,s)==best:
                        roots=[]
                        for _ in range(1000):
                            bm=sum(delta[rng.integers(len(t),size=len(t)),j,:].mean(0) for j in [0,1]);root=crossing(fixed+bm)
                            if root is not None:roots.append(root)
                        rec['bootstrap_valid']=len(roots);rec['bootstrap_total']=1000;rec['sampling_interval_95']=np.quantile(roots,[.025,.975]).tolist() if roots else None
                    out['endpoint_crossings'].append(rec)
                for i,(r,z) in enumerate(pts):
                    i0=pts.index((r,0.));km,se=estimate(t[:,:,i]-t[:,:,i0]);vals=[]
                    for n,s in settings:
                        total=km+hf(r,z)-hf(r,0)+R[n,s,r,z]['energy_ry']-R[n,s,r,0.]['energy_ry']
                        vals.append({'n':n,'span':s,'delta_total_from_unpolarized_mry':1000*total})
                    out['polarization_differences'].append({'rs':r,'zeta':z,'power':e['power'],'kite_sampling_se_mry':1000*se,'settings':vals})
    save(run/'analysis/corrected_ring_report.json',out)
    print('Saved',run/'analysis/corrected_ring_report.json')
if __name__=='__main__':main()
