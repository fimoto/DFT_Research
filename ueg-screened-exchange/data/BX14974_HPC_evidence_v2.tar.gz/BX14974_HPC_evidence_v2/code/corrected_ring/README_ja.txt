BX14974: 修正版ringの正式再計算 + 固定解析式の新規点検証

この一式は、従来のBX14974_followupとは別のディレクトリで使用してください。
古いrunディレクトリへ上書きしないでください。旧コード・旧結果は変更していません。

1. まず実行する3ジョブ

展開後:
  cd BX14974_ring_and_validation

既存venvを再利用する場合:
  qsub -v BX_VENV=/実際のパス/.venv run_hpc_age.sh inputs/35_ring_transition.json
  qsub -v BX_VENV=/実際のパス/.venv run_hpc_age.sh inputs/36_ring_spin_curvature.json
  qsub -v BX_VENV=/実際のパス/.venv run_hpc_age.sh inputs/37_ring_density_curvature.json

新しくvenvを作る場合（ログインノードで1回だけ）:
  python3 -m venv .venv
  . .venv/bin/activate
  python -m pip install -r requirements.txt
  qsub run_hpc_age.sh inputs/35_ring_transition.json
  qsub run_hpc_age.sh inputs/36_ring_spin_curvature.json
  qsub run_hpc_age.sh inputs/37_ring_density_curvature.json

35: rs=440–470、全13偏極、転移付近のringエネルギー。728タスク。
36: rs=32,60,70,75,110、零偏極付近と完全偏極、スピン曲率。360タスク。
37: rs=60,70,75を中心としたlog(rs)差分格子、完全偏極、密度曲率。216タスク。
3ジョブは互いの出力を読みません。同時投入可能です。

既定は mjobs.q、def_slot、16スロット、1ホスト内のPythonプロセス並列です。
MPIプログラムではありません。mpi-fillupは使用しません。
割当が複数ホストに分散した場合は、実行前に停止します。
8並列へ変更する場合は、例えば:
  qsub -pe def_slot 8 run_hpc_age.sh inputs/35_ring_transition.json
既存venvを指定するときは -v BX_VENV=/... も加えてください。
待ち時間・WallTime制限はHPC側の設定によります。本一式から予約待ち時間は予測しません。

2. 今回のringの変更

・対数積分区間をLindhard関数の枝境界 q=.15*x_sigma, 3*x_sigma と
  q=2*x_sigma の位置で分割。周波数方向も複数区間に分割。
・次数120,180,240,320は「各区間のGauss-Legendre点数」です。
  旧版の全区間次数800,1200,...と同じ意味ではありません。
・積分範囲span=1.0,1.25を独立に比較します。
・エネルギーに加えて密度曲率を積分内の解析微分から直接計算します。

  D=d/d ln(rs), K_n=(D^2-3D)E/9,
  E=C*rs^-2*integral f(c), f(c)=ln(1+c)-c, c proportional to rs.
  9*K_n の被積分関数 = 10*f(c)-6*c*f'(c)+c^2*f''(c).

小cでの桁落ちは級数で処理します。c^2項は厳密に相殺し、先頭は-2*c^3/3です。
rsの微分はスピン偏極一定で定義します。有限の積分範囲による誤差はspan比較で確認します。
スピン曲率は、安定化したringエネルギーの偶数次多項式による推定です。
これをスピン方向の解析微分実装と呼ぶことはしません。

3. kite再計算は不要

previous/に、既に終了・監査済みの33と34のQMC ensembles.json/replicates.npzを同梱しました。
再計算するのはringのみです。以前のringの数値は新しい解析に混ぜません。
解析で使うkiteの乱数相関はreplicates.npzから保持します。
入力・ソース・既存kiteデータ・数値環境の指紋をmanifestに記録します。

35の解析:
  全スピン格子のHF+ring+kiteエネルギー差、両端偏極の交差位置、
  kiteサンプリングのbootstrap区間、ring次数・範囲依存。
  有限のスピン格子だけから、連続した偏極全域の最小値を保証しません。
36の解析:
  スピン曲率をzeta上限=.04,.1,.2、偶数次次数2,3で比較。
37の解析:
  kiteをlog差分幅=.005,.01,.02で比較し、ringは解析密度微分を採用。
  ringエネルギーの5点差分との一致も別項目で出力。
  K_n=n*dmu/dn。逆圧縮率そのものはn*K_nです。
  負のK_nは有限波数のCDW転移位置の決定ではありません。

4. 結果の確認・再開

各ジョブ終了時に標準出力にCompletedが出ます。
  tail -30 runs/hpc_35_ring_transition/execution.log
  cat runs/hpc_35_ring_transition/analysis/completion.json

completion.jsonのmissingが空配列、completedがexpectedと一致することを確認。
主な解析結果:
  runs/hpc_35_ring_transition/analysis/corrected_ring_report.json
  runs/hpc_36_ring_spin_curvature/analysis/corrected_ring_report.json
  runs/hpc_37_ring_density_curvature/analysis/corrected_ring_report.json

convergenceには全次数・範囲のエネルギーと密度曲率が入っています。
best_setting=(320,1.25)は最大設定の採用であり、自動の収束認定ではありません。
次数依存と範囲依存を分けて確認してください。数値差は厳密な誤差上界ではありません。

同一ソース・同一入力・同じ数値環境なら、同じqsubコマンドで未完了分を再開できます。
完了済みタスクはSKIPされます。ソースや入力が変わったら新しいrunディレクトリが必要です。
強制終了後にlocks/が残った場合は、そのタスクを実行するプロセスが無いことを確認した上で、
該当する空のlockディレクトリだけをrmdirしてください。実行中のlockは削除しないでください。

計算終了後、結果一式を圧縮:
  sh pack_results.sh
作成されるBX14974_corrected_ring_results.tar.gzを返してください。
raw/, manifest.json, analysis/, execution.logを残してください。

5. 現在の6定数式を固定した新規検証

validation/frozen_fit/に前回の式・係数をバイト単位で変更せず同梱しました。
validation/freeze.jsonは、新しい積分結果を見る前に決めた点・予測・評価基準とファイル指紋です。
verification/validation_freeze_hash.jsonでfreeze自体の変更も検出します。

既存の計算点492組との重複を除外しました。完全偏極スケーリングで同じエネルギーになる既存点も除外。
30点の広域格子:
  rs=.0065,.065,.65,1.6,6.5,25.5,85.5,255,2550,25500
  zeta=0,.5,1
8点の重点検証:
  (45.5,.55), (45.5,.75), (85.5,.65), (85.5,.85),
  (155,.75), (155,.95), (25.5,.995), (85.5,.999)

各点について独立な32 scrambled Sobol反復、最大2^20点/項、2項を直接積分。
2^18,2^19を同じ列の入れ子で保存し、収束差をpaired SEで評価。
8重点点では運動量写像scale=4も別乱数で計算し、scale=2と比較。
全38点を保持し、結果が不都合な点を除外したり、係数・式を調整したりしません。
BRM式は公表Eq58+59を使用。zeta=0,1ではTableV直接係数による比較も別記します。

事前の目安: RMS<=.10 mRy、最大残差<=.25 mRy、各参照SE<=.05 mRy。
これは診断用の目標で、達成を保証する設定でも、全領域の誤差保証でもありません。
モデル誤差、標本誤差、入れ子次数差、写像差を別々に報告します。
bootstrap区間はサンプリング誤差のみを扱い、カーネルの共通系統誤差は含みません。

この検証は今回のローカル環境で実施し、結果はvalidation/results/に収録します。
正式なringジョブを行うために42・43を再計算する必要はありません。
HPCでも再現したい場合だけ、追加で以下を実行できます（35–37とは独立）:
  qsub run_hpc_age.sh validation/inputs/42_frozen_validation.json
  qsub run_hpc_age.sh validation/inputs/43_validation_map4.json
終了後:
  python scripts/validate_frozen.py --primary validation/runs/hpc_42_frozen_validation --map-check validation/runs/hpc_43_validation_map4 --out validation/hpc_results

ローカルで添付済みの結果を再集計:
  python scripts/validate_frozen.py --primary validation/runs/local_42_frozen_validation --map-check validation/runs/local_43_validation_map4 --out validation/results

6. 配布前の確認

verification/に、解析微分とエネルギー差分の比較、旧panel監査との一致、
次数240/320・範囲1.0/1.25の7点確認、全3解析経路の低次数スモーク試験、
QMCチェックポイント再開と入力不一致拒否の試験結果を保存します。
これらは利用者のHPC上での正式な3ジョブの実行結果ではありません。
環境の実測バージョンはverification/environment_tested.jsonを参照してください。
