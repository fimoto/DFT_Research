#!/bin/sh
#$ -S /bin/sh
#$ -pe def_slot 16
#$ -cwd
#$ -j y
#$ -q mjobs.q
set -eu
test "$#" -eq 1 || { echo 'Usage: qsub run_hpc_age.sh inputs/35_ring_transition.json'; exit 2; }
test -f scripts/ring_report.py || { echo 'Submit from BX14974_ring_and_validation/'; exit 2; }
input=$1
test -f "$input" || { echo "Missing input: $input"; exit 2; }
name=$(basename "$input" .json)
case "$name" in
  35_ring_transition|36_ring_spin_curvature|37_ring_density_curvature) engine=. ;;
  42_frozen_validation|43_validation_map4) engine=validation ;;
  *) echo 'Unknown input name'; exit 2 ;;
esac
venv=${BX_VENV:-.venv}
test -f "$venv/bin/activate" || { echo 'Create .venv or pass qsub -v BX_VENV=/absolute/path/.venv'; exit 2; }
. "$venv/bin/activate"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
workers=${NSLOTS:-16}
case "$workers" in ''|*[!0-9]*|0) echo 'Invalid NSLOTS'; exit 2;; esac
if [ -n "${PE_HOSTFILE:-}" ]; then
    echo 'Allocated hosts and slots:'
    cat "$PE_HOSTFILE"
    test "$(awk '{print $1}' "$PE_HOSTFILE" | sort -u | wc -l)" -eq 1 || { echo 'One host required. Use def_slot, not mpi-fillup.'; exit 2; }
fi
run=$engine/runs/hpc_$name
mkdir -p "$run"
python "$engine/scripts/plan.py" "$input" --run "$run"
{
    echo "START: $input; workers=$workers"
    date
    python "$engine/scripts/run.py" --run "$run" --workers "$workers"
    python "$engine/scripts/analyze.py" --run "$run"
    if [ "$engine" = . ]; then python scripts/ring_report.py --run "$run"; fi
    echo 'RUN COMPLETE'
    date
} >> "$run/execution.log" 2>&1
echo "Completed: $run; see execution.log and analysis/"
