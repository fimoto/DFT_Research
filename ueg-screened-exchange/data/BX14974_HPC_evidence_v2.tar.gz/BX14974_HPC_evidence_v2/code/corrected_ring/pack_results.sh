#!/bin/sh
set -eu
test -f scripts/ring_report.py || { echo 'Run from package root'; exit 2; }
set -- runs
if [ -d validation/runs ]; then set -- "$@" validation/runs; fi
tar -czf BX14974_corrected_ring_results.tar.gz "$@"
echo 'Created BX14974_corrected_ring_results.tar.gz'
