Generate Slurm/PBS Pro scripts on the TARGET machine:
python scripts/prepare_array.py --run runs/your_run --scheduler slurm
or --scheduler pbs

No submission is performed. Add site-specific account/queue/partition directives
before the first shell command, then submit the generated scripts yourself.
The interpreter is the one that runs prepare_array.py; activate the intended
Python environment before planning or generating scripts.
