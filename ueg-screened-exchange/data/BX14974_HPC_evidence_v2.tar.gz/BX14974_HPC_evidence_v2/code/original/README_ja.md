# BX14974 追加計算キット

Fumihiro Imoto / MBPT_Kite / 2026-11-14

統合Replyと変更表示原稿の追加計算を、PCまたはHPCで実行するための独立した作業用キットです。GitHubへのアクセスや元リポジトリの配置は不要です。元の物理積分カーネルとLICENSE、JSON入力、並列実行・再開・集計コードを同梱しています。元リポジトリを書き換えません。

**本番計算は未実行です。** 同梱の確認結果は小規模な動作試験です。`pc` は初回の精度確認用、`hpc` は高精度計算の候補設定で、レフェリーの要求精度を自動的に保証するものではありません。まず必要な計算群だけを実行してください。

## 1. 展開と環境

```bash
tar -xzf BX14974_additional_calculations.tar.gz
cd BX14974_additional_calculations
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python tests/test_workflow.py
```

Python 3.10以降、NumPy、SciPyを使います。C/Fortranコンパイラ・MPI・GPUは不要です。試験環境は Python 3.12.14、NumPy 2.3.5、SciPy 1.17.0。再現用の版指定は `requirements-tested.txt` にあります。同じrun内でPython/NumPy/SciPyの版やCPUアーキテクチャを変更すると再開を停止します。別環境の結果を混ぜず、新しいrun名を使ってください。

HPCでは、サイト指定のPython環境で必要パッケージを準備してください。計算ノードでは外部ネットワークを使いません。環境作成やパッケージ導入はログインノード等で行えます。

## 2. 最初は小規模の動作確認

```bash
python scripts/plan.py inputs/smoke/00_smoke.json --run runs/smoke
python scripts/run.py --run runs/smoke --workers 2
python scripts/status.py --run runs/smoke
python scripts/analyze.py --run runs/smoke
python scripts/high_density.py --run runs/smoke --bootstrap 20
python scripts/polarization.py --run runs/smoke --bootstrap 20
python scripts/fit.py --run runs/smoke --bootstrap 10
python scripts/diagnostics.py --run runs/smoke
```

`smoke` のエネルギー・fit・交差には物理的精度を期待しないでください。積分から集計までの接続を確認するため、サンプル数を意図的に減らしています。すべてのスクリプトはこのディレクトリで実行する想定です。

## 3. 自分のPCで計算時間を測る

```bash
python scripts/plan.py inputs/smoke/01_benchmark.json --run runs/benchmark
python scripts/run.py --run runs/benchmark --workers 1
python scripts/benchmark_report.py --benchmark-run runs/benchmark \
  --input inputs/pc/10_low_density.json --workers 4
```

CPU実測から積分評価回数に比例した見積りを出します。密度やサンプリングスケールによる負荷差、メモリ競合、ring・独立軸積分、待ち時間を含まないため、各本番群の1タスクでも時間を測ってください。再開後のbenchmarkは所要時間を過小評価するので、新しいrun名で測り直してください。

## 4. 計算群と推奨順序

| 入力（`inputs/pc/` または `inputs/hpc/`） | 内容 | 対応箇所 |
|---|---|---|
| `10_low_density.json` | 10^6、10^7、10^8の直接積分・同一点参照差分、N/R収束 | R1.3、本文V A、SM S23 |
| `11_reference_and_map_checks.json` | map scale 1,2,4,q* と参照密度10^20,10^26,10^30 | 参照・サンプリング系統差 |
| `20_high_density.json` | 10^-4〜0.1の11密度、密度ごとに独立seed | R1.4、SM S24 |
| `30_endpoint_crossing.json` | 端点差、厳密再スケーリング、ring格子/範囲の精緻化 | R1.2、SM S25 |
| `31_spin_minimum.json` | 中間偏極、ζ=0/1近傍の細分点 | 第一次転移か、中間極小があるか |
| `32_curvatures.json` | 小さいζを含む32,60,70,75,110での差 | R2.1、SM S27 |
| `40_global_fit.json` | 学習格子と別seedのholdout格子 | R2.2、SM S26 |
| `50_independent_axis.json` | 独立な虚周波数表示での格子・周波数・cutoffチェック | 直接積分との相互確認 |
| `inputs/hpc/12_low_density_extended.json` | **必要時のみ**10^8で2^25点、128反復まで | 第3項の識別が不十分な場合 |

まず10→11→20→30を行い、次に31・32・40へ進むことを想定しています。50は別表示による確認であり、設定を増やしただけで収束が保証されるわけではありません。全群を一度に流す必要はありません。

### PCでの例：低密度

```bash
python scripts/plan.py inputs/pc/10_low_density.json --run runs/low_density
python scripts/run.py --run runs/low_density --workers 4
python scripts/analyze.py --run runs/low_density
```

他の入力も同じ3ステップです。例えば高密度計算後は:

```bash
python scripts/high_density.py --run runs/high_density --bootstrap 1000
```

端点計算後は:

```bash
python scripts/polarization.py --run runs/endpoint --group endpoint --bootstrap 1000
python scripts/diagnostics.py --run runs/endpoint
```

中間スピン・曲率の場合は、それぞれ `--group spin_scan`、`--group curvature` に変更します。ring計算は対応するJSON入力に含まれています。

`--workers` は同時に動かすプロセス数です。1プロセスの内部スレッド数は1に固定し、多重並列を避けています。まず2〜4で試し、使用メモリを測って増やしてください。

## 5. HPC：Slurm / PBS Pro

キットをHPCへコピーし、**HPC上で**環境を用意してplanと配列スクリプトを生成します。これにより正しい絶対パス・Python実行ファイルが埋め込まれます。

```bash
python scripts/plan.py inputs/hpc/10_low_density.json --run runs/low_density_hpc
python scripts/prepare_array.py --run runs/low_density_hpc \
  --scheduler slurm --chunk 1000 --concurrency 16
```

PBS Proなら `--scheduler pbs`。生成された `runs/.../jobs/*.sh` の冒頭に、サイト固有のaccount・partition・queue等を追記してから、表示された `sbatch` または `qsub` コマンドを実行してください。**生成コマンド自体はジョブを投入しません。**

1配列要素=1タスク、CPU 1、メモリ2 GB、最大24時間を初期テンプレートにしています。計算機の規則と実測に合わせて変更してください。配列が分割された場合、同時数制限は配列ごとなので、同時数16を維持したければ各配列を順番に投入します。PBSテンプレートはPBS Pro用で、Torque固有の変数・構文への対応はサイトで調整が必要です。

MPIランク間通信はありません。同じrunディレクトリへ書ける共有ファイルシステムが必要です。集計は全配列終了後に1プロセスで実行します。

## 6. 再開・設定の変更

同じ `run.py` コマンドを再実行すると、完了済みのタスクを検証してskipし、未完了タスクをcheckpointから再開します。積分は小さなchunkに分け、原則16chunkごとと指定サンプル数到達時に保存します。

```bash
python scripts/status.py --run runs/low_density
python scripts/run.py --run runs/low_density --workers 4
```

Nは2のべき乗。各タスクは最大Nまで1回だけ進め、途中のNの結果も保存するため、収束表の各Nを別々に再計算しません。R収束表は同一反復集合のprefixで作ります。NやRの異なる行は独立ではありません。

入力・ソースはplan時に固定されます。N、R、格子、コード、環境を変更する場合は入力JSONをコピーして編集し、**新しいrunディレクトリ**を使ってください。出力の黙った上書きや、異なる設定の混在を防ぎます。PC版とHPC版は同じseed設計なので、別々に実行した両者を独立データとしてpoolしてはいけません。別独立campaignは入力の `seed_base` を変更し、重複を確認してください。

異常終了で `runs/.../locks/タスク番号/` が残った場合は、そのタスクのプロセス/ジョブが確実に終了していることを確認し、その空lockディレクトリだけを `rmdir` で削除してください。checkpointは残します。実行中のlockは削除しないでください。

`analyze.py` は通常、未完了タスクがあると停止します。進捗診断だけなら `--allow-incomplete` を付けられますが、結果は不完全と記録され、全点に共通してそろった反復だけを使います。途中の結果を最終値として採用しないでください。

## 7. 精度を判断する出力

`runs/<name>/analysis/` に以下が出ます。

- `completion.json`: 未完了タスク一覧。
- `energies.csv`: N・密度・偏極・参照ごとの平均、標準誤差、3項漸近値。
- `replicate_prefixes.csv`: R=2,4,8,16,...での変化。
- `ensembles.json`, `replicates.npz`: 点間の共分散と、項・反復ごとの生の推定量。
- `reference_sensitivity.json`: 同じ乱数で差を取った参照密度依存性。
- `high_density_fits.json`: free/null/constrained fits、共分散、相関、条件付き検出力、bootstrap、仮定したremainder項への感度。
- `polarization_<group>.json`: 全エネルギー差、PCHIP/cubicの交差、交差のbootstrap分布、格子上の最小偏極、小さいζへのfitによる曲率。
- `numerical_diagnostics.json`: ring/虚周波数表示の格子・範囲の差。`diagnostics.py` で生成。

エネルギーの内部記録はRy/electron、表示CSVはmRy。誤差は独立scramble間の標準誤差で、数値系統誤差を含みません。乱数seedは各反復・2項で重複しません。スピン・密度の差に使う点間だけは意図的に共有します。高密度11点は密度間も独立です。共通乱数の共分散を保持し、ノード誤差を独立として足す処理はしません。

参照差分列は `C(rs)-C(r_ref)` であり、有限参照の `e(r_ref)` を加えていません。原稿の予備値と同じ定義です。参照依存性と解析的な参照残差の大きさを確認してから採用してください。`reference_energy_...` 列は参照の普通の推定値で、参照差分より大きい分散を持つことがあります。解析的漸近値そのものを差し引いて、数値検証を見かけ上改善する方式ではありません。

10^8で第3項は約0.000458 mRyです。例えばその項の有意な識別を狙う場合は、標準誤差だけでなく参照・map・積分の系統差も十分小さい必要があります。extended入力はそのための追加候補であり、必須の一括ジョブではありません。

交差のbootstrapは2項を独立にresampleし、各項の同じ反復を全密度・全偏極で共有します。交差を持たないbootstrap標本数も出力します。ring格子差は別に報告し、bootstrap区間へ混ぜて確率的誤差と解釈しません。有限スピングリッドだけでは、格子の間の狭い極小を除外できません。

## 8. 全密度・スピンfit

まず `40_global_fit.json` を実行・集計します。unpolarized fitとζ=1端点だけなら:

```bash
python scripts/fit.py --run runs/global_fit --bootstrap 200
```

三次switchと正の分母パラメータを使い、既知の低密度3項と高密度2対数項を保持します。ζ=1は厳密なdensity rescalingです。

任意ζの候補fitには、S19の有限部分B(z)を計算したcacheを準備します:

```bash
python scripts/coefficients.py --order 80 --output runs/coefficients_80.json
python scripts/coefficients.py --order 160 --output runs/coefficients_160.json
python scripts/coefficients.py --order 240 --output runs/coefficients_240.json
python scripts/fit.py --run runs/global_fit \
  --coefficients runs/coefficients_160.json --bootstrap 200
```

cache計算も再開可能です。80/160/240の係数変化を確認してください。Bの被積分関数は同梱の既存 `hd_kernel.py` から取り、hとその組合せは既存の安定な実装で評価します。

全スピン候補は、端点補間に既知の高・低密度スピン係数の差を足し、さらにζ=0/1と高・低密度の既知項を変えない残差基底でfitします。c1(ζ)はcacheの積分を任意ζで評価し、単なる表の補間にはしません。式と範囲は `METHODS.md` に記載しました。

`fit_results.json` と `fit_grid.csv` を出力します。`fit_holdout` は学習とは別seed・別格子で、学習から除外します。fitの重みは点ごとの標準誤差で、目的関数を厳密なχ²とは扱いません。bootstrapには点間の相関を保持します。holdoutのpullはholdout標準誤差で規格化した診断で、fitパラメータ誤差を含む信頼区間ではありません。

これは**検証用の候補fitコード**です。小規模テストで代数的端点条件等を確認しましたが、本番データに対する精度・曲率・相図はまだ検証していません。まずholdout残差、分母の正値性、格子依存、導関数の差分幅依存を確認し、原稿へ採用してください。有限qのCDW閾値や、完全な一電子条件、未計算のladder/Fock相殺を検証するコードではありません。

## 9. ソースと検証記録

- `vendor/`: 提供済み2026-10-04アーカイブから必要なコードを無変更で収録。`PROVENANCE.json` にハッシュ。直接積分とLindhardの核は、以前確認したcommit `d836aae6284568368f63bb456298d65244789e59` と末尾空行を除いて一致。
- `reference/`: 以前の解析結果。新規計算の集計やfitには自動で混入しません。
- `verification/`: このキットで実施した小規模テストの記録。
- `tests/`: seed重複、再開の一致、参照同一時の差分ゼロ、スピン反転、回帰、fitの漸近・端点条件を確認。
- `SHA256SUMS`: 配布ファイルの整合性確認用。

計算後は `runs/<name>/manifest.json`、`raw/`、`analysis/`、標準出力ログをまとめて返していただければ、収束の判定、必要な追加点の選定、Reply/原稿の予備値の置換まで進められます。checkpointは再開用なので、計算完了後の解析だけなら不要です。
