"""Constrained endpoint and density-dependent spin fit; errors are empirical, not bounds."""
import argparse
from common import *
from analyze import bootstrap
from scipy.optimize import least_squares,minimize_scalar
from ueg_exchange.constants import A1,A2,A3,Q_TF_SQ_COEFF,spin_moment
from ueg_exchange.highdensity import C_ln2_zeta
from coefficients import values

A=2**(-4/3);C1=0.011499642149291289

def endpoint(r,p,c10=C1):
    r=np.asarray(r);c2,lr,D,E,F=p;q=q_star(r);w=1/(1+(r/np.exp(lr))**3)
    B=A2+A1*D;C=A3+B*D-A1*(D*D-E)
    H=E2X+r*(C_ln2_zeta(0)*np.log(r)**2+c10*np.log(r)+c2)
    L=(A1*q*q+B*q+C)/(q**3+D*q*q+E*q+F)
    return w*H+(1-w)*L

def endpoint_fit(r,y,se,c10):
    if len(r)<6:raise ValueError('at least six unpolarized densities needed')
    f=least_squares(lambda p:(endpoint(r,p,c10)-y)/se,[-.018,np.log(1.),.7,.06,3.],bounds=([-.2,-8,1e-8,1e-8,1e-8],[.2,8,30,30,100]),max_nfev=10000)
    if not f.success:raise RuntimeError(f.message)
    return f.x

def spin_base(r,z,p,cache):
    r=np.asarray(r);z=np.asarray(z);fx=(((1+z)**(4/3)+(1-z)**(4/3))/2-1)/(2**(1/3)-1)
    ch0,c10=values(0.,cache);chz=np.array([C_ln2_zeta(float(v)) for v in z]);c1z=np.array([values(float(v),cache)[1] for v in z]);logA=np.log(A)
    base=(1-fx)*endpoint(r,p,c10)+fx*endpoint(A*r,p,c10)
    w=1/(1+(r/np.exp(p[1]))**3)
    dh=chz-((1-fx)+fx*A)*C_ln2_zeta(0)
    d1=c1z-((1-fx)*c10+fx*A*(c10+2*logA*C_ln2_zeta(0)))
    m4,m5,m6=[((1+z)**(k/3)+(1-z)**(k/3))/2 for k in [4,5,6]];S3=(1160*m6+891*m4*m5)/2051
    tail=0.
    for k,c,m in [(1,A1,m4),(2,A2,m5),(3,A3,S3)]:tail+=c*(m-((1-fx)+fx*A**(-k/4)))/q_star(r)**k
    ans=base+w*r*(dh*np.log(r)**2+d1*np.log(r))+(1-w)*tail
    ans=np.where(z==0,endpoint(r,p,c10),ans);ans=np.where(abs(z)==1,endpoint(A*r,p,c10),ans)
    return ans

def design(r,z):
    r=np.asarray(r);z=np.asarray(z);t=np.tanh(np.log(r)/4);pref=z*z*(1-z*z)*r/(1+r)**2
    return np.column_stack([pref*z**(2*j)*t**k for j in range(2) for k in range(3)])

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',required=True);p.add_argument('--group',default='fit_train');p.add_argument('--holdout-group',default='fit_holdout');p.add_argument('--coefficients');p.add_argument('--bootstrap',type=int,default=100);a=p.parse_args();root=Path(a.run)/'analysis';E=load(root/'ensembles.json');raw=np.load(root/'replicates.npz');keys=[k for k,v in E.items() if v['group']==a.group and v['column']=='direct']
    if not keys:raise SystemExit('No fit training data')
    key=max(keys,key=lambda k:E[k]['power']);v=E[key];pts=np.array(v['points']);r,z=pts.T;y=np.array(v['mean_ry']);se=np.sqrt(np.diag(v['covariance_mean_ry2']));mask=z==0;cache=load(a.coefficients) if a.coefficients else None
    if cache and len(cache['b'])!=cache['order']:raise SystemExit('Coefficient cache is incomplete; resume coefficients.py first')
    if cache and cache['source_hashes']!=sources():raise SystemExit('Coefficient cache uses different source files; generate a new cache')
    c10=values(0.,cache)[1] if cache else C1
    def dofit(y):
        p=endpoint_fit(r[mask],y[mask],se[mask],c10)
        if cache:
            D=design(r,z);b=spin_base(r,z,p,cache);q=np.linalg.lstsq(D/se[:,None],(y-b)/se,rcond=None)[0];pred=b+D@q
        else:q=None;pred=endpoint(r[mask],p,c10)
        return p,q,pred
    pp,qq,pred=dofit(y);sel=np.ones(len(y),bool) if cache else mask;res=pred-y[sel]
    out={'ensemble':key,'warning':'Diagonal-weight fit objective is descriptive. Bootstrap preserves cross-point covariance. No accuracy claim until independent holdouts and grid/order checks pass.','endpoint_parameters':pp.tolist(),'spin_parameters':None if qq is None else qq.tolist(),'analytic_c1_zero':c10,'rms_mry':float(1000*np.sqrt(np.mean(res**2))),'max_abs_mry':float(1000*max(abs(res))),'weighted_objective':float(sum((res/se[sel])**2))}
    def evaluate(rr,zz):
        return spin_base(rr,zz,pp,cache)+design(rr,zz)@qq if cache else endpoint(np.asarray(rr)*np.where(np.asarray(zz)==1,A,1),pp,c10)
    holds=[k for k,w in E.items() if w['group']==a.holdout_group and w['column']=='direct']
    if holds:
        h=max(holds,key=lambda k:E[k]['power']);w=E[h];hr,hz=np.array(w['points']).T;hy=np.array(w['mean_ry']);hs=np.sqrt(np.diag(w['covariance_mean_ry2']));ok=np.ones(len(hr),bool) if cache else np.isin(hz,[0,1]);d=evaluate(hr[ok],hz[ok])-hy[ok]
        out['holdout']={'ensemble':h,'points':np.array(w['points'])[ok].tolist(),'residual_mry':(1000*d).tolist(),'sampling_pull':(d/hs[ok]).tolist(),'excluded_from_training':True}
    rng=np.random.default_rng(2941);pars=[];failed=0
    for _ in range(a.bootstrap):
        try:
            yy=bootstrap(raw[key],v['independent_points'],rng)+E2X;p,q,_=dofit(yy);pars.append(np.r_[p,q] if q is not None else p)
        except (RuntimeError,ValueError):failed+=1
    out['bootstrap']={'successful':len(pars),'failed':failed,'fixed_fit_weights':True,'percentiles':np.percentile(pars,[2.5,50,97.5],axis=0).tolist() if pars else None}
    out['K_kite_endpoint_rs70_mry']={}
    rr=70*A
    for h in [.03,.01,.003,.001]:
        f0,fp,fm=[endpoint(rr*np.exp(x),pp,c10) for x in [0,h,-h]];out['K_kite_endpoint_rs70_mry'][str(h)]=float(1000*((fp-2*f0+fm)/h**2-3*(fp-fm)/(2*h))/9)
    save(root/'fit_results.json',out)
    rr=np.geomspace(.001,1e8,300);zg=np.linspace(0,1,51) if cache else [0,1];predictions=[]
    for zz in zg:
        vals=evaluate(rr,np.full_like(rr,zz));predictions.extend([[float(x),float(zz),float(v)] for x,v in zip(rr,vals)])
    np.savetxt(root/'fit_grid.csv',predictions,delimiter=',',header='rs,zeta,energy_ry',comments='');print(root/'fit_results.json')
if __name__=='__main__':main()
