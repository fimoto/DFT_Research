#!/bin/sh
set -eu
test -d runs || { echo 'No runs directory.' >&2; exit 2; }
# Exclude only restart scratch state. Preserve all raw profiles and audit inputs.
tar --exclude='*/checkpoints' --exclude='*/locks' --exclude='*/postprocess.lock' \
    -czf BX14974_followup_results.tar.gz runs inputs previous/SNAPSHOT.json SHA256SUMS README_ja.md
echo 'Created BX14974_followup_results.tar.gz'
