# Numerical conventions and scope

All energies are Rydberg per electron. The Coulomb prefactor, BRM coupling convention and Lindhard kernel are inherited unchanged from `vendor/`. This kit changes task orchestration and statistical bookkeeping, not the physical diagram.

## Seed and covariance convention

A stream seed is `seed_base + gid*10000000 + node*2048 + 2*rep + term`, with `term=0,1`. The planner limits the numbers of points and replicas so those ranges do not overlap. `node=0` for a group sharing random numbers across densities/polarizations. For independent high-density points, `node` is their distinct index. Different groups have different `gid` values. PC/HPC profiles deliberately reuse stream families; never pool both profiles as independent ensembles. Distinct campaign bases must be spaced enough to keep **all ranges** disjoint, not merely differ by one.

Let `T[j,t,p]` be the term estimate for scramble j, term t and point p. The covariance of the energy mean is `(Cov_j T[:,0,:] + Cov_j T[:,1,:])/R`. For the high-density independent-point group only the diagonal survives. Bootstrap draws independent replica-index arrays for the two terms; within a term the same array is used at all intentionally paired points. Changing randomization counts uses prefixes, not new independent datasets.

Each integrand is sampled with the same Sobol points at target and reference density. The difference is taken **before** accumulating the sum. Its constant is zero; the direct and reference-energy columns each add the exact bare exchange constant once. Finite-reference energy is not automatically added to the difference column. This keeps bias visible and avoids using the asymptotic coefficients as sampled evidence for themselves.

## Ring energy

With alpha=(4/(9 pi))^(1/3), Q2=4 alpha rs/pi, and L_zeta(q,nu)=sum_sigma x_sigma L(q/x_sigma,nu/x_sigma^2)/2, the energy is

`e_ring = 3/(4 pi) * 2/(alpha rs)^2 * integral q^2 dq dnu [log(1+c)-c]`, `c=Q2 L_zeta/q^2`.

For small c the bracket is evaluated as its stable series. Quadrature uses logarithmic coordinates with separately specified order and range. Wider ranges at fixed order can worsen resolution; compare both together. The exact Misawa relation tests rescaling, but can hold even for coarse quadrature, so it does not replace order convergence.

## High-density fits

e2x is fixed. Joint regressors are `rs log(rs)^2`, `rs log(rs)`, and `rs`. Regression uses known estimated sampling covariance and does not rescale it by residual chi-square/dof. SVD is used for coefficient covariance. A singular covariance triggers a failure rather than a silent pseudoinverse. Fits with `rs^2` or `rs^2 log(rs)^2` nuisance terms are sensitivity models; their powers are not claimed to be derived. Bootstrap resamples the stored integrals and keeps the original regression weights. Model-truncation and variance-estimation uncertainties remain separate.

## Density-dependent spin fit

Write a=2^(-4/3), f_x=(M4-1)/(2^(1/3)-1), and e0(r) for the constrained unpolarized rational/cubic-switch fit. The endpoint base is

`e_base(r,z)=(1-f_x(z))*e0(r)+f_x(z)*e0(a*r)`.

Use w=1/[1+(r/r0)^3]. Add

`w*r*[Delta_c_hd(z)*log(r)^2+Delta_c1(z)*log(r)]`

and

`(1-w)*sum(k=1..3) A_k*[M_k(z)-(1-f_x+f_x*a^(-k/4))]/q_star(r)^k`,

where the three M_k here denote M4, M5, and S3=(1160 M6+891 M4 M5)/2051. Delta_c_hd and Delta_c1 are the exact spin coefficient minus the coefficient implied by the endpoint base, including the shift log(a) in the rescaled high-density logarithms.

The remaining fitted basis is

`z^2*(1-z^2)*r/(1+r)^2 * z^(2j) * tanh(log(r)/4)^k`, j=0,1 and k=0,1,2.

It is even in z and vanishes at both endpoints. At high density it is O(r), so it cannot change the two known logarithmic coefficients. At low density it is O(1/r), so it does not change the first three powers or their stated remainder order. This supplies a finite-dimensional **candidate** family, not a proof that six residual coefficients suffice. Endpoint evaluation is enforced exactly at z=0 and |z|=1. Independent holdouts determine whether to increase the residual basis.

## Remaining scientific limitations

The kit does not evaluate additional Fock or screened-ladder diagrams, prove a one-electron cancellation, or compute the full finite-wave-vector charge response. It supports the requested numerical checks for the existing ring-plus-kite approximation. A discrete spin minimum and an interpolation-based crossing are not by themselves a continuous phase-boundary calculation. Numerical convergence, independent representations and appropriately correlated uncertainty must be assessed before updating scientific claims.
