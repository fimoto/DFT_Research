"""Paired grid/cutoff changes and ring endpoint-identity checks, without fitted error claims."""
import argparse
from common import *
p=argparse.ArgumentParser();p.add_argument('--run',required=True);a=p.parse_args();root=Path(a.run)/'analysis';rings=load(root/'ring.json');axes=load(root/'axis.json');out={'ring':[],'axis':[],'warning':'Grid/range changes are sensitivity diagnostics, not rigorous truncation bounds. Axis changes preserve shared scramble covariance.'}
for point in sorted({(r['task']['rs'],r['task']['zeta']) for r in rings}):
 rr=[r for r in rings if (r['task']['rs'],r['task']['zeta'])==point];best=max(rr,key=lambda r:(r['task']['n'],r['task']['span']))
 out['ring'].append({'point':point,'settings':[[r['task']['n'],r['task']['span']] for r in rr],'energies_ry':[r['energy_ry'] for r in rr],'difference_from_finest_ry':[r['energy_ry']-best['energy_ry'] for r in rr]})
out['ring_identity']=[]
for r in rings:
 t=r['task']
 if t['zeta']!=1:continue
 matches=[v for v in rings if v['task']['rs']==t['rs']*2**(-4/3) and v['task']['zeta']==0 and v['task']['n']==t['n'] and v['task']['span']==t['span']]
 if matches:out['ring_identity'].append({'rs':t['rs'],'n':t['n'],'span':t['span'],'difference_ry':r['energy_ry']-.5*matches[0]['energy_ry']})
for point in sorted({(r['task']['rs'],r['task']['zeta']) for r in axes}):
 rr=[r for r in axes if (r['task']['rs'],r['task']['zeta'])==point];base=rr[0]
 for r in rr[1:]:
  if r['task']['seed']!=base['task']['seed'] or len(r['replicates_ry'])!=len(base['replicates_ry']):raise ValueError('unpaired axis runs')
  d=np.array(r['replicates_ry'])-base['replicates_ry'];out['axis'].append({'point':point,'base':base['task'],'refinement':r['task'],'paired_shift_mry':float(1000*d.mean()),'paired_se_mry':float(1000*d.std(ddof=1)/np.sqrt(len(d)))})
save(root/'numerical_diagnostics.json',out);print(root/'numerical_diagnostics.json')
