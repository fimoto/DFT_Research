"""Compute the S19 finite-part kernel once; evaluate c_hd,c1 at arbitrary zeta."""
import argparse,time
from common import *
sys.path.insert(0,str(ROOT/'vendor/validation/high_density'))
import hd_kernel as H
from ueg_exchange.lindhard import h_shell
from ueg_exchange.highdensity import alpha_shell,C_ln2_zeta
from ueg_exchange.constants import A0,Q_TF_SQ_COEFF

def values(zeta,cache):
    z=np.array(cache['z']);w=np.array(cache['weights']);b=np.array(cache['b']);av=alpha_shell(z)
    xs=[(1+zeta)**(1/3),(1-zeta)**(1/3)];aa=bb=al=0.
    for x in xs:
        if x==0:continue
        g=sum(.5*y*h_shell(x*z/y) for y in xs if y>0)/x**2;weight=x**3/2
        A=float(np.sum(w*g*av));B=float(np.sum(w*g*b));c=-A/9+float(np.sum(w*av*g*np.log(g)))/3
        aa+=weight*A;bb+=weight*B;al+=weight*c
    chd=-8*np.pi**2*A0/3*aa*Q_TF_SQ_COEFF
    c1=2*chd*np.log(Q_TF_SQ_COEFF)-2*A0*Q_TF_SQ_COEFF*(8*np.pi**2*al-2*bb/3)
    return float(chd),float(c1)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--order',type=int,default=160);p.add_argument('--output',required=True);p.add_argument('--zeta',nargs='+',type=float,default=[0,.2,.4,.6,.8,.9,1]);a=p.parse_args();path=Path(a.output)
    x,w=np.polynomial.legendre.leggauss(a.order);t=(x+1)/2;z=t/(1-t);weights=w/2/(1-t)**2
    if path.exists():
        c=load(path)
        if c['order']!=a.order or c['source_hashes']!=sources():raise SystemExit('Cache differs: use another output path')
    else:c={'order':a.order,'z':z.tolist(),'weights':weights.tolist(),'b':[],'source_hashes':sources(),'runtime':runtime()}
    for i in range(len(c['b']),len(z)):
        c['b'].append(float(H.b(float(z[i]))));save(path,c);print(f'B kernel {i+1}/{len(z)}',flush=True)
    c['coefficients']={str(z):{'c_hd_quadrature':values(z,c)[0],'c_hd_closed':float(C_ln2_zeta(z)),'c1':values(z,c)[1]} for z in a.zeta}
    save(path,c);print(path)
if __name__=='__main__':main()
