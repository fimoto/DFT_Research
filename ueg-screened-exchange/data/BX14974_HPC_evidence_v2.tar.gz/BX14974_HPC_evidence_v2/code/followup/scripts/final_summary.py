"""Collect the five outputs without equating job completion with scientific acceptance."""
import argparse
from common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('--runs',default='runs');a=p.parse_args();root=Path(a.runs)
    names=['14_low_density_map4','51_axis_resolution','33_spin_and_transition','34_density_curvature','41_fit_and_coefficients']
    out={'jobs':{},'screening_flags':[],'warning':'Flags are review prompts, not a family-wise statistical test or an automatic scientific verdict.'}
    for name in names:
        path=root/('hpc_'+name)
        if name.startswith('41'):
            f=path/'summary.json';ok=f.exists() and load(f).get('status')=='completed'
            out['jobs'][name]={'complete':ok,'summary':str(f)}
            if ok:
                data=load(f)
                for order,v in data['fits'].items():
                    if v['bootstrap']['failed']:out['screening_flags'].append(f'41 order {order}: bootstrap fit failures')
                    h=v.get('holdout',{});res=np.abs(h.get('residual_mry',[]))
                    if len(res):out['jobs'][name].setdefault('holdout_max_abs_mry',{})[order]=float(max(res))
        else:
            f=path/'analysis/followup_report.json';c=path/'analysis/completion.json'
            ok=f.exists() and c.exists() and not load(c)['missing']
            out['jobs'][name]={'complete':ok,'summary':str(f)}
            if ok:
                data=load(f)
                if name.startswith('14'):
                    vals=data['qmc']['map_comparisons'];best=max(v['power'] for v in vals)
                    for v in vals:
                        if v['power']==best and abs(v['standardized_difference'])>3:out['screening_flags'].append(f"14 rs={v['rs']}: independent maps differ by more than 3 combined SE")
                if name.startswith('51'):
                    for v in data['axis']['estimates']:
                        if v['setting']['label'] in ['joint_refined','wide_range','bare_q_refined'] and abs(v.get('standardized_difference',0))>3:
                            out['screening_flags'].append(f"51 {v['group']} rs={v['rs']} {v['setting']['label']}: discrepancy exceeds 3 combined SE")
    out['all_jobs_complete']=all(v['complete'] for v in out['jobs'].values());save(root/'FINAL_SUMMARY.json',out)
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
