"""Extrapolate from a LOCAL fresh benchmark; no hardware-independent wall-time claim."""
import argparse
from common import *
p=argparse.ArgumentParser();p.add_argument('--benchmark-run',required=True);p.add_argument('--input',required=True);p.add_argument('--workers',type=int,default=1);a=p.parse_args()
from plan import build
rr=[load(p) for p in (Path(a.benchmark_run)/'raw').glob('*.json')];rates=[]
for v in rr:
 t=v['task']
 if t['kind']=='qmc':rates.append(2*(1+len(t['references']))*2**max(t['powers'])/v['wall_seconds_last_invocation'])
if not rates:raise SystemExit('No completed benchmark task')
rate=float(np.median(rates));tasks=build(load(a.input));n=sum(2*(1+len(t['references']))*2**max(t['powers']) for t in tasks if t['kind']=='qmc')
print(json.dumps({'kernel_evaluations':n,'benchmark_evaluations_per_second':rate,'serial_hours':n/rate/3600,'ideal_parallel_hours':n/rate/3600/a.workers,'not_included':'ring/axis tasks, scheduler, load, memory bandwidth; density/scale-dependent cost; do not use resumed benchmark timings','warning':'Scaling estimate only; measure one representative task of each group.'},indent=2))
