"""Total-energy endpoint crossings, paired bootstrap, grid minima and curvatures."""
import argparse
from common import *
from analyze import bootstrap
from scipy.interpolate import PchipInterpolator,CubicSpline
from scipy.optimize import brentq

def roots(rs,y,cls=PchipInterpolator):
    x=np.log(rs);f=cls(x,y);out=[]
    for i in range(len(x)-1):
        if y[i]==0:out.append(float(rs[i]))
        elif y[i]*y[i+1]<0:out.append(float(np.exp(brentq(f,x[i],x[i+1]))))
    if y[-1]==0:out.append(float(rs[-1]))
    return out

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',required=True);p.add_argument('--group',default='endpoint');p.add_argument('--bootstrap',type=int,default=400);a=p.parse_args();root=Path(a.run)/'analysis';E=load(root/'ensembles.json');raw=np.load(root/'replicates.npz');keys=[k for k,v in E.items() if v['group']==a.group and v['column']=='direct'];
    if not keys:raise SystemExit('No selected ensemble')
    key=max(keys,key=lambda k:E[k]['power']);e=E[key];pts=[tuple(p) for p in e['points']];means=np.array(e['mean_ry']);terms=raw[key]
    rg=load(root/'ring.json');by={}
    for rec in rg:
        t=rec['task'];by.setdefault((t['rs'],t['zeta']),[]).append(rec)
    def ring_at(r,z):
        vals=by.get((r,z),[])
        if not vals:raise ValueError(f'No ring calculation at {r},{z}; run matching ring input.')
        v=max(vals,key=lambda x:(x['task']['n'],x['task']['span']));return v['energy_ry'],max(abs(x['energy_ry']-v['energy_ry']) for x in vals)
    rs=sorted(set(r for r,z in pts if z==0 and (r,1.) in pts));out={'ensemble':key,'units':'Ry except density','warning':'Bootstrap excludes ring quadrature, density/spin interpolation bias and all other systematics. Minima are over sampled states, not a proof of continuous global minimization.'};rng=np.random.default_rng(8713)
    def deltas(v,z):
        rr=sorted(set(r for r,zz in pts if zz==z and (r,0.) in pts));y=[];ks=[];err=[]
        for r in rr:
            a0,e0=ring_at(r,0.);az,ez=ring_at(r,z);dk=v[pts.index((r,z))]-v[pts.index((r,0.))];ks.append(dk);y.append(dk+az-a0+hf(r,z)-hf(r,0));err.append(e0+ez)
        return rr,np.array(y),ks,err
    for z in sorted(set(z for _,z in pts if z>0)):
        rr,y,ks,err=deltas(means,z)
        if len(rr)<2:continue
        bs=[];missing=0
        for _ in range(a.bootstrap):
            v=bootstrap(terms,e['independent_points'],rng)+E2X;_,yy,_,_=deltas(v,z);rrr=roots(rr,yy)
            if len(rrr)==1:bs.append(rrr[0])
            else:missing+=1
        out[str(z)]={'rs':rr,'delta_total_ry':y.tolist(),'delta_kite_ry':ks,'ring_variation_sum_ry':err,'pchip_crossings':roots(rr,y),'cubic_crossings':roots(rr,y,CubicSpline),'kite_crossings':roots(rr,ks),'bootstrap_unique_crossings':len(bs),'bootstrap_no_or_multiple_crossing':missing,'bootstrap_percentiles':np.percentile(bs,[2.5,50,97.5]).tolist() if bs else None}
    # Independent direct endpoint value vs exact rescaling, preserving paired scrambles.
    checks=[]
    for r in rs:
        pair=(r*2**(-4/3),0.)
        if pair in pts:
            i=pts.index((r,1.));j=pts.index(pair);d=terms[:,:,i]-terms[:,:,j];checks.append({'rs':r,'difference_ry':float(d.mean(0).sum()),'se_ry':float(np.sqrt(d.var(0,ddof=1).sum()/len(d)))})
    out['endpoint_identity_checks']=checks
    out['grid_minima']=[];out['spin_curvature']=[]
    for r in sorted({x for x,z in pts if (x,0.) in pts}):
        zs=sorted({z for x,z in pts if x==r});i0=pts.index((r,0.));e0,_=ring_at(r,0.);v=[]
        for z in zs:
            rz,_=ring_at(r,z);v.append(means[pts.index((r,z))]-means[i0]+rz-e0+hf(r,z)-hf(r,0))
        out['grid_minima'].append({'rs':r,'zeta':zs[int(np.argmin(v))],'delta_ry':float(min(v))})
        for maxz in [.04,.1,.2,.4]:
            use=np.array([z>0 and z<=maxz for z in zs]);zz=np.array(zs)[use]
            if len(zz)<2:continue
            A=np.column_stack([zz**2,zz**4]);c=np.linalg.lstsq(A,np.array(v)[use],rcond=None)[0];curv=[]
            for _ in range(a.bootstrap):
                samp=bootstrap(terms,e['independent_points'],rng)+E2X
                yy=np.array([samp[pts.index((r,z))]-samp[i0]+ring_at(r,z)[0]-e0+hf(r,z)-hf(r,0) for z in zz]);curv.append(2*np.linalg.lstsq(A,yy,rcond=None)[0][0])
            out['spin_curvature'].append({'rs':r,'zeta_max':maxz,'curvature_ry':float(2*c[0]),'bootstrap_percentiles':np.percentile(curv,[2.5,50,97.5]).tolist() if curv else None})
    save(root/f'polarization_{a.group}.json',out);print(root/f'polarization_{a.group}.json')
if __name__=='__main__':main()
