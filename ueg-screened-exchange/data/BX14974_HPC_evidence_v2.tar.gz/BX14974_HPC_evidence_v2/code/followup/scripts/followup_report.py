"""Paired numerical diagnostics. Report unresolved discrepancies without declaring convergence."""
import argparse
from common import *


def estimate(a):
    a=np.asarray(a)
    # QMC terms use independent scrambles; point differences must be taken first.
    return float(a.mean(0).sum()), float(np.sqrt(a.var(0,ddof=1).sum()/len(a)))


def previous_value(rs):
    choices={1:('40_global_fit','fit_train','direct'),10:('40_global_fit','fit_train','direct'),
        60:('32_curvatures','curvature','direct'),
        1e6:('10_low_density','low_density','difference_ref_1e+20'),
        1e8:('13_low_density_precision','low_density_precision','difference_ref_1e+30')}
    run,group,col=choices[rs]; folder=ROOT/'previous'/('hpc_'+run)
    ee=load(folder/'analysis/ensembles.json')
    # Discover the available reference instead of assuming a legacy reference choice.
    candidates=[v for v in ee.values() if v['group']==group and v['column']==col]
    if not candidates and rs==1e6:
        candidates=[v for v in ee.values() if [rs,0.] in v['points'] and v['column'].startswith('difference_ref_')]
        candidates=[v for v in candidates if float(v['column'].split('ref_')[1])==max(float(w['column'].split('ref_')[1]) for w in candidates)]
    if not candidates:raise ValueError('Missing baseline ensemble for '+str(rs))
    v=max(candidates,key=lambda v:v['power']);i=v['points'].index([rs,0.]);value=v['mean_ry'][i]
    if v['column'].startswith('difference_ref_'):value+=asymptotic_kite(float(v['column'].split('ref_')[1]),0)
    return {'run':run,'column':v['column'],'mean_ry':float(value),'se_ry':float(np.sqrt(v['covariance_mean_ry2'][i][i])),
            'reference_correction':'three-term asymptotic at reference density' if v['column'].startswith('difference') else None}


def axis_report(run):
    records=load(run/'analysis/axis.json');groups={}
    for rec in records:
        t=rec['task'];key=(t['group'],t['rs'],t['zeta'],t['setting_id'])
        groups.setdefault(key,[]).append(rec)
    out=[];paired=[];tables={}
    for key,rr in sorted(groups.items()):
        rr=sorted(rr,key=lambda r:r['task']['replicate_start']);t=rr[0]['task']
        offsets=[r['task']['replicate_start'] for r in rr]
        if offsets!=list(range(0,t['total_replicates'],t['replicates'])):raise ValueError('incomplete axis replicates')
        vals=np.concatenate([r['replicates_ry'] for r in rr]);mean=float(vals.mean());se=float(vals.std(ddof=1)/np.sqrt(len(vals)))
        rec={'group':key[0],'rs':key[1],'zeta':key[2],'setting':t,'R':len(vals),'mean_mry':1000*mean,'se_mry':1000*se}
        if t.get('bare'):reference={'run':'analytic E2X','mean_ry':float(E2X),'se_ry':0.}
        elif key[0].startswith('smoke'):reference=None
        else:reference=previous_value(key[1])
        if reference:
            diff=mean-reference['mean_ry'];sigma=np.hypot(se,reference['se_ry'])
            rec.update(reference=reference,delta_mry=1000*diff,combined_se_mry=1000*sigma,
                standardized_difference=float(diff/sigma) if sigma else None)
        if key[0]=='legacy_reproduction':
            old=load(ROOT/'previous/hpc_50_independent_axis/analysis/axis.json')
            old=next(r for r in old if r['task']['rs']==key[1] and r['task']['qmin']==t['qmin'] and r['task']['nq']==t['nq'])
            rec['legacy_replicate_max_abs_difference_ry']=float(np.max(abs(vals-np.array(old['replicates_ry']))))
        # Integrate each replicate's profile first, then estimate scatter. No independent-node assumption.
        tables[key]=vals;out.append(rec)
    for key,vals in tables.items():
        peers=[k for k in tables if k[:3]==key[:3]]
        base=next((k for k in peers if groups[k][0]['task']['label'] in ['m18','bare_m18']),min(peers))
        if key==base:continue
        b=tables[base]
        if len(vals)!=len(b):continue
        d=vals-b;paired.append({'group':key[0],'rs':key[1],
            'base':groups[base][0]['task']['label'],'test':groups[key][0]['task']['label'],
            'paired_shift_mry':float(1000*d.mean()),'paired_se_mry':float(1000*d.std(ddof=1)/np.sqrt(len(d)))})
    return {'estimates':out,'paired_refinements':paired,
        'warning':'Independent-route discrepancy and discretization shifts must be resolved before claiming agreement. SE is sampling uncertainty only; bare=True checks the analytic unscreened normalization.'}


def qmc_report(run):
    ee=load(run/'analysis/ensembles.json');aa=np.load(run/'analysis/replicates.npz')
    out={'power_changes':[],'map_comparisons':[]}
    for key,v in ee.items():
        lower=[(k,w) for k,w in ee.items() if w['group']==v['group'] and w['column']==v['column'] and w['power']<v['power']]
        if lower:
            k,w=max(lower,key=lambda kw:kw[1]['power']);d=aa[key]-aa[k]
            out['power_changes'].append({'group':v['group'],'column':v['column'],'powers':[w['power'],v['power']],
                'points':v['points'],'paired_shift_mry':(1000*d.mean(0).sum(0)).tolist(),
                'paired_se_mry':(1000*np.sqrt(d.var(0,ddof=1).sum(0)/len(d))).tolist()})
        if 'map4' in v['group'] and v['column']=='difference_ref_1e+30':
            for i,(r,z) in enumerate(v['points']):
                old=previous_value(r);val=v['mean_ry'][i]+asymptotic_kite(1e30,z);se=np.sqrt(v['covariance_mean_ry2'][i][i]);cs=np.hypot(se,old['se_ry'])
                out['map_comparisons'].append({'rs':r,'power':v['power'],'mean_mry':float(1000*val),'se_mry':float(1000*se),
                    'old':old,'independent_map_shift_mry':float(1000*(val-old['mean_ry'])),
                    'combined_se_mry':float(1000*cs),'standardized_difference':float((val-old['mean_ry'])/cs),
                    'three_term_mry':float(1000*asymptotic_kite(r,z))})
    return out


def spin_report(run):
    ee=load(run/'analysis/ensembles.json');aa=np.load(run/'analysis/replicates.npz');rr=load(run/'analysis/ring.json')
    rings={(v['task']['n'],v['task']['span'],v['task']['rs'],v['task']['zeta']):v['energy_ry'] for v in rr}
    settings=sorted({(k[0],k[1]) for k in rings});best=max(settings)
    out={'spin_curvature':[],'interior_vs_endpoints':[], 'warning':'Finite spin grids do not prove absence of an arbitrarily narrow minimum. Curvature is d2E/dzeta2; this is not charge compressibility or a finite-q CDW calculation.'}
    for key,e in ee.items():
        if e['column']!='direct' or e['group'] not in ['spin_precision','curvature_precision']:continue
        pts=[tuple(p) for p in e['points']];terms=aa[key]
        for r in sorted({p[0] for p in pts}):
            settings=sorted({(n,s) for n,s,x,z in rings if x==r and z==0.})
            best=max(settings)
            i0=pts.index((r,0.));zs=sorted(z for x,z in pts if x==r)
            def calc_weights(zz,degree):
                A=np.column_stack([zz**(2*j) for j in range(1,degree+1)])
                return 2*np.linalg.pinv(A)[0]
            if e['group']=='curvature_precision':
                for maxz in [.04,.1,.2]:
                    zz=np.array([z for z in zs if 0<z<=maxz]);ids=[pts.index((r,z)) for z in zz]
                    for degree in [2,3]:
                        if len(zz)<degree:continue
                        weights=calc_weights(zz,degree);qterms=(terms[:,:,ids]-terms[:,:,i0,None])@weights;qm,se=estimate(qterms)
                        hfpart=float(np.dot(weights,[hf(r,z)-hf(r,0) for z in zz]));rv=[]
                        for n,s in settings:
                            rv.append({'n':n,'span':s,'ring_curvature_mry':float(1000*np.dot(weights,[rings[n,s,r,z]-rings[n,s,r,0.] for z in zz]))})
                        out['spin_curvature'].append({'rs':r,'power':e['power'],'zeta_max':maxz,'polynomial_degree_in_zeta2':degree,
                            'kite_curvature_mry':1000*qm,'sampling_se_mry':1000*se,'hf_curvature_mry':1000*hfpart,
                            'ring_settings':rv,'total_curvature_mry':1000*(qm+hfpart)+rv[-1]['ring_curvature_mry']})
            else:
                n,s=best
                for z in zs:
                    if z in [0,1]:continue
                    i=pts.index((r,z));pairs=[]
                    for end in [0.,1.]:
                        j=pts.index((r,end));qm,se=estimate(terms[:,:,i]-terms[:,:,j]);rv=[rings[nn,ss,r,z]-rings[nn,ss,r,end] for nn,ss in settings]
                        pairs.append({'endpoint':end,'delta_total_mry':1000*(qm+hf(r,z)-hf(r,end)+rv[-1]),
                            'sampling_se_mry':1000*se,'ring_delta_range_mry':float(1000*np.ptp(rv))})
                    out['interior_vs_endpoints'].append({'rs':r,'zeta':z,'power':e['power'],'comparisons':pairs})
    return out


def density_report(run):
    ee=load(run/'analysis/ensembles.json');aa=np.load(run/'analysis/replicates.npz');rr=load(run/'analysis/ring.json')
    rings={(v['task']['n'],v['task']['span'],v['task']['rs']):v['energy_ry'] for v in rr}
    settings=sorted({(k[0],k[1]) for k in rings});out=[]
    for key,e in ee.items():
        if e['column']!='direct' or e['group']!='density_curvature':continue
        rs=np.array(e['points'])[:,0];terms=aa[key]
        for center in [60,70,75]:
            for h in [.005,.01,.02,.04]:
                stencils=[('3point',np.array([-1,0,1]),np.array([-1,0,1])/(2*h),np.array([1,-2,1])/h**2)]
                if h<=.02:stencils.append(('5point',np.arange(-2,3),np.array([1,-8,0,8,-1])/(12*h),np.array([-1,16,-30,16,-1])/(12*h**2)))
                for label,kk,d1,d2 in stencils:
                    targets=center*np.exp(kk*h);ids=[int(np.argmin(abs(rs-v))) for v in targets]
                    if not np.allclose(rs[ids],targets,rtol=1e-13,atol=0):raise ValueError('density stencil point missing')
                    w=(d2-3*d1)/9;i0=int(np.argmin(abs(rs-center)))
                    qm,se=estimate((terms[:,:,ids]-terms[:,:,i0,None])@w)
                    hfpart=float(np.dot(w,[hf(r,1)-hf(center,1) for r in rs[ids]]))
                    rv=[{'n':n,'span':s,'K_ring_mry':float(1000*np.dot(w,[rings[n,s,r]-rings[n,s,rs[i0]] for r in rs[ids]]))} for n,s in settings]
                    out.append({'rs':center,'zeta':1,'power':e['power'],'log_step':h,'stencil':label,
                        'K_kite_mry':1000*qm,'sampling_se_mry':1000*se,'K_hf_mry':1000*hfpart,
                        'ring_settings':rv,'K_total_mry':1000*(qm+hfpart)+rv[-1]['K_ring_mry']})
    return {'definition':'K = (D^2 E - 3 D E)/9, D=d/d(log rs); E is Ry/electron at fixed zeta. K = n*dmu/dn; inverse compressibility is n*K.',
        'warning':'Compare Sobol powers, finite-difference stencils/steps and ring orders separately. This does not locate a finite-q charge-density-wave instability.', 'estimates':out}


def main():
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);a=p.parse_args();run=Path(a.run)
    cfg=load(run/'manifest.json')['input'];names=[g['name'] for g in cfg['groups']]
    report={'qmc':qmc_report(run),'completion':load(run/'analysis/completion.json')}
    if any(g['kind']=='axis' for g in cfg['groups']):report['axis']=axis_report(run)
    if 'spin_precision' in names:report['spin']=spin_report(run)
    if 'density_curvature' in names:report['density']=density_report(run)
    save(run/'analysis/followup_report.json',report);print(run/'analysis/followup_report.json')


if __name__=='__main__':main()
