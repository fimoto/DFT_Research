"""Regenerate the shipped explicit JSON inputs; no calculation is launched."""
from common import *

def q(name,gid,rs,z,powers,R,**kw):return dict(name=name,gid=gid,kind='qmc',rs=rs,zeta=z,powers=powers,replicates=R,scale=2.,**kw)
def ring(g,orders,spans=[1.,1.25]):return dict(name='ring_'+g['name'],gid=30+g['gid'],kind='ring',rs=g['rs'],zeta=g['zeta'],orders=orders,spans=spans,scaled_endpoints=g.get('scaled_endpoints',False))
def write(profile,name,groups,base=100000000):
    save(ROOT/'inputs'/profile/(name+'.json'),{'schema':1,'profile':profile,'description':name,'seed_base':base,'chunk_power':12,'groups':groups})

def main():
 for profile in ['pc','hpc']:
    big=profile=='hpc';R=64 if big else 16;m=20 if big else 18
    ld=q('low_density',1,[1e6,1e7,1e8],[0.],list(range(15,23 if big else 22)),R,references=[1e24,1e30]);write(profile,'10_low_density',[ld])
    controls=[]
    for i,scale in enumerate([1.,2.,4.,'qstar']):
        g=q('map_'+str(i),2+i,[1e6,1e7,1e8],[0.],[16,18,20] if big else [15,17,19],32 if big else 8,references=[1e20,1e26,1e30]);g['scale']=scale;controls.append(g)
    write(profile,'11_reference_and_map_checks',controls)
    if big:write(profile,'12_low_density_extended',[q('low_density_extended',14,[1e8],[0.],list(range(21,26)),128,references=[1e24,1e30])])
    hd=q('high_density',6,[1e-4,3e-4,.001,.002,.003,.005,.01,.02,.03,.05,.1],[0.],[m-2,m-1,m],R,independent_points=True);write(profile,'20_high_density',[hd])
    end=q('endpoint',7,[300,350,380,400,420,440,450,460,470,480,500,520,550,600,650,700],[0.,1.],[m-1,m],R,scaled_endpoints=True)
    write(profile,'30_endpoint_crossing',[end,ring(end,[300,600,900] if big else [200,400,600])])
    spin=q('spin_scan',8,[110,200,300,380,420,450,460,470,500,550,600,700,800,1000,1300],[0,.02,.05,.1,.2,.4,.6,.8,.9,.95,.98,.99,1.],[m-1,m],R)
    write(profile,'31_spin_minimum',[spin,ring(spin,[400,800] if big else [200,400])])
    curv=q('curvature',9,[32,60,70,75,110],[0,.01,.02,.04,.06,.1,.2,.4,1.],[m-1,m],R)
    write(profile,'32_curvatures',[curv,ring(curv,[400,800] if big else [200,400])])
    train=q('fit_train',10,[.001,.003,.01,.03,.1,.3,1,3,7,10,30,100,300,1000,1e4,1e6,1e8],[0,.2,.4,.6,.8,.9,1],[m-1,m],R)
    hold=q('fit_holdout',11,[.002,.02,.2,2,5,20,70,200,500,3000,3e4],[0,.3,.7,1.],[m-1,m],R)
    write(profile,'40_global_fit',[train,hold])
    axis={'name':'axis_check','gid':12,'kind':'axis','rs':[1,10,60,1e6,1e8],'zeta':[0.], 'settings':[]}
    for nq,order,nk in [(24,12,48),(48,20,64),(96,32,96)]:
        axis['settings'].append(dict(power=14 if big else 11,replicates=16 if big else 4,nq=nq,order=order,nk=nk,qmin=1e-4,qmax=None))
    # Separate cutoff sensitivity from sample/quad order.
    axis['settings'].append(dict(power=14 if big else 11,replicates=16 if big else 4,nq=96,order=32,nk=96,qmin=1e-5,qmax=100000.))
    write(profile,'50_independent_axis',[axis])
 smoke=[q('low_density',1,[1e6,1e8],[0.],[8,10],2,references=[1e20,1e30]),q('high_density',6,[.001,.003,.01,.03,.1],[0.],[8,10],4,independent_points=True)]
 end=q('endpoint',7,[380,460,550],[0,1],[8,10],2,scaled_endpoints=True);smoke += [end,ring(end,[24,48],[1.])]
 train=q('fit_train',10,[.001,.01,.1,1,10,100,1000],[0,.4,.8,1],[8],2);smoke+=[train]
 write('smoke','00_smoke',smoke,base=900000000)
 bench=q('benchmark',13,[1e6],[0],[12,14],2,references=[1e24,1e30]);write('smoke','01_benchmark',[bench],base=900000000)
 print('Wrote inputs for smoke, PC and HPC. PC inputs are initial precision settings, not guaranteed referee accuracy.')
if __name__=='__main__':main()
