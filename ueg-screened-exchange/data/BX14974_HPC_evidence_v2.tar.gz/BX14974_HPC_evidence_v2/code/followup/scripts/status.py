import argparse,collections
from common import *
p=argparse.ArgumentParser();p.add_argument('--run',required=True);a=p.parse_args();run=Path(a.run);m=load(run/'manifest.json');out={}
for t in m['tasks']:
 g=out.setdefault(t['group'],{'total':0,'complete':0,'checkpoint':0,'locked':0});g['total']+=1
 for name,folder,suffix in [('complete','raw','.json'),('checkpoint','checkpoints','.json')]:g[name]+=int((run/folder/(f'{t["id"]:07d}'+suffix)).exists())
 g['locked']+=int((run/'locks'/str(t['id'])).exists())
print(json.dumps(out,indent=2))
