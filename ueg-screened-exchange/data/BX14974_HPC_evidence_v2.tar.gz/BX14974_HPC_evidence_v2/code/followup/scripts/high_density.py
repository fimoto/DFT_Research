"""Joint/null/remainder-sensitive fits with full covariance and replicate bootstrap."""
import argparse
from common import *
from analyze import bootstrap
from scipy.stats import norm
from ueg_exchange.constants import C_LN2
C1=0.011499642149291289

def regress(r,y,cov,variant='free'):
    X=r[:,None]*np.array([np.log(r)**2,np.log(r),np.ones(len(r))]).T
    fixed=np.zeros(len(r));names=['c_hd','c1','c2']
    if variant=='null':X=X[:,1:];names=names[1:]
    elif variant=='fixed':fixed=X[:,:2]@np.array([C_LN2,C1]);X=X[:,2:];names=['c2']
    elif variant.startswith('remainder'):
        tail=r**2*(np.log(r)**2 if variant=='remainder_log2' else 1)
        X=np.column_stack([X,tail]);names+=['nuisance_remainder']
    if len(r)<X.shape[1]:return None
    # High-density seeds are disjoint across points. Cholesky also supports nonsingular GLS.
    try:L=np.linalg.cholesky(cov)
    except np.linalg.LinAlgError:return {'failure':'covariance not positive definite; collect more independent replicates, do not silently pseudoinvert'}
    A=np.linalg.solve(L,X);b=np.linalg.solve(L,y-fixed)
    if np.linalg.matrix_rank(A)<len(names):return {'failure':'rank deficient'}
    p=np.linalg.lstsq(A,b,rcond=None)[0];_,sv,V=np.linalg.svd(A,full_matrices=False);C=(V.T/sv**2)@V
    se=np.sqrt(C.diagonal());out={'names':names,'coef':p.tolist(),'se':se.tolist(),'cov':C.tolist(),'corr':(C/np.outer(se,se)).tolist(),'Q':float(np.sum((A@p-b)**2)),'dof':int(len(r)-len(p)),'condition':float(sv[0]/sv[-1])}
    if 'c_hd' in names:
        d=abs(C_LN2)/se[0];out['conditional_power_5pct']=float(norm.cdf(-1.95996398454-d)+norm.sf(1.95996398454-d));out['analytic_chd']=C_LN2
    return out

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',required=True);p.add_argument('--group',default='high_density');p.add_argument('--bootstrap',type=int,default=400);a=p.parse_args();root=Path(a.run)/'analysis';E=load(root/'ensembles.json');raw=np.load(root/'replicates.npz');keys=[k for k,v in E.items() if v['group']==a.group and v['column']=='direct']
    if not keys:raise SystemExit('high-density group not aggregated')
    key=max(keys,key=lambda k:E[k]['power']);e=E[key];pts=np.array(e['points']);idx=np.where(pts[:,1]==0)[0];r=pts[idx,0];y=np.array(e['mean_ry'])[idx]-E2X;cov=np.array(e['covariance_mean_ry2'])[np.ix_(idx,idx)];terms=raw[key][:,:,idx];rng=np.random.default_rng(1197);out={}
    for cut in [.001,.003,.01,.03,.1]:
        m=r<=cut
        if m.sum()<3:continue
        fits={v:regress(r[m],y[m],cov[np.ix_(m,m)],v) for v in ['free','null','fixed','remainder_r2','remainder_log2']}
        bs=[]
        for _ in range(a.bootstrap):
            yy=bootstrap(terms,e['independent_points'],rng)
            f=regress(r[m],yy[m],cov[np.ix_(m,m)])
            if f and 'coef' in f:bs.append(f['coef'])
        fits['bootstrap']={'draws':len(bs),'fixed_weights':True,'percentiles_2_5_50_97_5':np.percentile(bs,[2.5,50,97.5],axis=0).tolist() if bs else None}
        out[str(cut)]=fits
    save(root/'high_density_fits.json',{'ensemble':key,'warning':'Power and covariance conditional on model/variances; r^2 and r^2 log^2 terms are sensitivity models, not derived remainder orders. Bootstrap keeps original GLS weights.','windows':out});print(root/'high_density_fits.json')
if __name__=='__main__':main()
