"""RPA ring energy (Ry/electron), log grids with explicit range/order checks."""
from common import *
from functools import lru_cache
from ueg_exchange.lindhard import lindhard_shape
from ueg_exchange.constants import q_tf_sq
@lru_cache(None)
def gauss(n):return np.polynomial.legendre.leggauss(n)
def log1pmx(c):
    c=np.asarray(c);out=np.empty_like(c);m=c<1e-3;x=c[m]
    out[m]=-x*x/2+x**3/3-x**4/4+x**5/5-x**6/6
    out[~m]=np.log1p(c[~m])-c[~m]
    return out

def ring(rs,zeta,n=400,span=1.):
    x,w=gauss(n);t=(x+1)/2;w=w/2;Q2=q_tf_sq(rs)
    sq=max(1.,Q2**.25);sn=max(1.,np.sqrt(Q2/3))
    lo,hi=np.log(sq)-7*span*np.log(10),np.log(sq)+7*span*np.log(10)
    q=np.exp(lo+t*(hi-lo));wq=w*(hi-lo)*q
    lo,hi=np.log(sn)-8*span*np.log(10),np.log(sn)+9*span*np.log(10)
    nu=np.exp(lo+t*(hi-lo));wn=w*(hi-lo)*nu
    total=0.
    # Bound the Lindhard temporary arrays independently of n^2.
    for k in range(0,n,8):
        qq=q[k:k+8,None];nn=nu[None,:];L=np.zeros((len(qq),n))
        for xs in ((1+zeta)**(1/3),(1-zeta)**(1/3)):
            if xs>0:L+=.5*xs*lindhard_shape(qq/xs,nn/xs**2)
        c=Q2*L/qq**2
        if np.any(c<0) or not np.isfinite(c).all():raise ArithmeticError('invalid Lindhard response')
        total+=np.sum((wq[k:k+8]*q[k:k+8]**2)[:,None]*wn[None,:]*log1pmx(c))
    return float(3/(4*np.pi)*2/(ALPHA_L*rs)**2*total)
