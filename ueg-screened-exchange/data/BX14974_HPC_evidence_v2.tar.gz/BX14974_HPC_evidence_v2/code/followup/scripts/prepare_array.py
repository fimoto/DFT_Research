"""Write Slurm or PBS Pro array scripts. Does NOT submit them."""
import argparse,shlex
from common import *
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',required=True);p.add_argument('--scheduler',choices=['slurm','pbs'],required=True);p.add_argument('--chunk',type=int,default=1000);p.add_argument('--concurrency',type=int,default=16);p.add_argument('--python',default=sys.executable);a=p.parse_args()
 run=Path(a.run).resolve();tasks=load(run/'manifest.json')['tasks'];folder=run/'jobs';folder.mkdir(exist_ok=True)
 if a.chunk<1 or a.concurrency<1:raise SystemExit('chunk/concurrency must be positive')
 for start in range(0,len(tasks),a.chunk):
    n=min(a.chunk,len(tasks)-start);path=folder/f'{a.scheduler}_{start:07d}.sh'
    if a.scheduler=='slurm':
      header=f'''#SBATCH --job-name=BX14974
#SBATCH --cpus-per-task=1
#SBATCH --mem=2G
#SBATCH --time=24:00:00
#SBATCH --array=0-{n-1}%{a.concurrency}
#SBATCH --output=bx14974-%A_%a.log
''';idx='${SLURM_ARRAY_TASK_ID}'
    else:
      header=f'''#PBS -N BX14974
#PBS -l select=1:ncpus=1:mem=2gb
#PBS -l walltime=24:00:00
#PBS -J 0-{n-1}%{a.concurrency}
#PBS -j oe
''';idx='${PBS_ARRAY_INDEX}'
    text='#!/usr/bin/env bash\n'+header+'# Add your site account/queue/partition directives ABOVE shell commands.\nset -euo pipefail\n'
    text+='export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1\n'
    text+='cd '+shlex.quote(str(ROOT))+'\n'
    text+=f'TASK_ID=$(({start} + {idx}))\n'
    text+=shlex.quote(a.python)+' scripts/run.py --run '+shlex.quote(str(run))+' --task "$TASK_ID"\n'
    path.write_text(text);path.chmod(0o755);print(('sbatch ' if a.scheduler=='slurm' else 'qsub ')+shlex.quote(str(path)))
 print('Scripts only; nothing submitted. Concurrency is per array. Submit chunks sequentially to maintain the requested cap.')
if __name__=='__main__':main()
