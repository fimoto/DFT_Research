"""Reuse frozen HPC 40; compute coefficient quadratures and predictive fit errors."""
import argparse,concurrent.futures,shutil,subprocess
from common import *
from coefficients import H,values
from ueg_exchange.highdensity import C_ln2_zeta


def kernel(job):
    order,i,z=job
    return order,i,float(H.b(z))


def verify_previous():
    ledger=load(ROOT/'previous/SNAPSHOT.json')
    for run,entry in ledger.items():
        for path,sha in entry['files'].items():
            f=ROOT/'previous'/run/path
            if hashlib.sha256(f.read_bytes()).hexdigest()!=sha:raise ValueError('Baseline snapshot changed: '+str(f))
    return hashlib.sha256((ROOT/'previous/SNAPSHOT.json').read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser();p.add_argument('--run',default='runs/hpc_41_fit_and_coefficients');p.add_argument('--workers',type=int,default=16)
    p.add_argument('--orders',type=int,nargs='+',default=[80,160,240]);p.add_argument('--bootstrap',type=int,default=500);a=p.parse_args()
    if a.workers<1 or a.bootstrap<2 or min(a.orders)<2:p.error('invalid work size')
    run=Path(a.run).resolve();run.mkdir(parents=True,exist_ok=True);lock=run/'postprocess.lock'
    try:lock.mkdir()
    except FileExistsError:raise SystemExit('Postprocess is locked; remove its lock only after confirming the previous process has stopped.')
    try:
        snapshot=verify_previous();mp=run/'manifest.json'
        obj={'source_hashes':sources(),'runtime':runtime(),'baseline_snapshot_sha256':snapshot,'orders':a.orders,'bootstrap':a.bootstrap}
        obj['fingerprint']=digest(obj)
        if mp.exists():
            old=load(mp);check=dict(old);sig=check.pop('fingerprint')
            if digest(check)!=sig:raise ValueError('modified manifest')
            if any(old[k]!=obj[k] for k in ['source_hashes','baseline_snapshot_sha256','orders','bootstrap']) or any(old['runtime'][k]!=obj['runtime'][k] for k in ['python','numpy','scipy','machine']):raise ValueError('Use a NEW run directory: setup changed')
        else:save(mp,obj)
        caches={};jobs=[]
        for order in a.orders:
            path=run/f'coefficients_{order}.json'
            if path.exists():
                c=load(path)
                if c['source_hashes']!=sources() or c['order']!=order:raise ValueError('Coefficient cache mismatch')
            else:
                x,w=np.polynomial.legendre.leggauss(order);t=(x+1)/2
                c={'order':order,'z':(t/(1-t)).tolist(),'weights':(w/2/(1-t)**2).tolist(),'b':[],'source_hashes':sources(),'runtime':runtime()}
            caches[order]=c
            jobs.extend((order,i,z) for i,z in enumerate(c['z']) if i>=len(c['b']))
        with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as ex:
            for order,i,value in ex.map(kernel,jobs):
                c=caches[order]
                if i!=len(c['b']):raise ValueError('out of order coefficient checkpoint')
                c['b'].append(value);save(run/f'coefficients_{order}.json',c);print(f'Coefficient {order}: {i+1}/{order}',flush=True)
        zetas=[0,.2,.3,.4,.6,.7,.8,.9,1.];comparison=[]
        for order,c in caches.items():
            c['coefficients']={str(z):{'c_hd_quadrature':values(z,c)[0],'c_hd_closed':float(C_ln2_zeta(z)),'c1':values(z,c)[1]} for z in zetas}
            save(run/f'coefficients_{order}.json',c)
            comparison.append({'order':order,'coefficients':c['coefficients']})
        save(run/'coefficient_convergence.json',comparison)
        for order in a.orders:
            cmd=[sys.executable,str(ROOT/'scripts/fit.py'),'--run',str(ROOT/'previous/hpc_40_global_fit'),
                '--coefficients',str(run/f'coefficients_{order}.json'),'--bootstrap',str(a.bootstrap),
                '--output-dir',str(run/f'fit_order_{order}')]
            subprocess.run(cmd,check=True)
        hd=run/'high_density';(hd/'analysis').mkdir(parents=True,exist_ok=True)
        for name in ['ensembles.json','replicates.npz']:
            shutil.copy2(ROOT/'previous/hpc_20_high_density/analysis'/name,hd/'analysis'/name)
        subprocess.run([sys.executable,str(ROOT/'scripts/high_density.py'),'--run',str(hd),'--bootstrap',str(a.bootstrap)],check=True)
        fits={str(o):load(run/f'fit_order_{o}/fit_results.json') for o in a.orders}
        save(run/'summary.json',{'status':'completed','fits':fits,'coefficient_convergence':comparison,
            'warning':'Completion is not an accuracy verdict. Compare holdout residuals including fit sampling uncertainty, quadrature-order changes, and direct 33/34 curvature data. Fixed candidate model was not selected or refitted on holdouts.'})
        print('POSTPROCESS COMPLETE',flush=True)
    finally:lock.rmdir()


if __name__=='__main__':main()
