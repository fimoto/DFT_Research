"""Small deterministic tests; no production-precision integrals are run."""
import sys,tempfile,unittest,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from common import *
from plan import build
from run import qmc_task
from ring import log1pmx,ring
from fit import endpoint,spin_base,design
from coefficients import values
from high_density import regress
from scipy.stats import qmc
import benites_direct as bd

class Workflow(unittest.TestCase):
 def test_no_accidental_seed_overlap(self):
    for p in (ROOT/'inputs').rglob('*.json'):
        tasks=build(load(p));owners={}
        for t in tasks:
            if t['kind']!='qmc':continue
            for term,seed in enumerate(t['seeds']):
                stream=(t['group'],t['point'] if t['independent_points'] else 0,t['rep'],term)
                self.assertEqual(owners.setdefault(seed,stream),stream)
 def test_resume_and_identical_reference(self):
    t={'rs':1e6,'zeta':0.,'scale':2.,'references':[1e6,1e30],'seeds':[908712,908713],'powers':[6,8],'chunk_power':4}
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/'part.json';a=qmc_task(t,p,'test',stop_after=3);self.assertIsNone(a)
        a=qmc_task(t,p,'test');b=qmc_task(t,Path(d)/'full.json','test')
        self.assertEqual(a['term_means'],b['term_means'])
        for term in (0,1):
            self.assertEqual(a['term_means']['8'][term][1],0.)
            u=qmc.Sobol(9,scramble=True,seed=t['seeds'][term]).random_base2(8)
            truth=bd.evaluate_term(u,t['rs'],0.,term+1,2.).mean()
            self.assertAlmostEqual(a['term_means']['8'][term][0],truth,places=13)
 def test_spin_reversal_integrand(self):
    u=qmc.Sobol(9,scramble=True,seed=754321).random_base2(7)
    for term in (1,2):np.testing.assert_allclose(bd.evaluate_term(u,10,.4,term,2),bd.evaluate_term(u,10,-.4,term,2),rtol=1e-13,atol=1e-14)
 def test_small_ring_argument(self):
    x=np.array([1e-14,1e-10,1e-6]);np.testing.assert_allclose(log1pmx(x),-x*x/2+x**3/3,rtol=1e-11)
 def test_high_density_known_coefficients(self):
    r=np.array([.0001,.0003,.001,.003,.01,.03]);p=np.array([-.000859445718977859,.011499642149291289,-.018]);X=r[:,None]*np.array([np.log(r)**2,np.log(r),np.ones(len(r))]).T
    f=regress(r,X@p,np.eye(len(r))*1e-14);np.testing.assert_allclose(f['coef'],p,rtol=1e-9,atol=1e-12);self.assertLess(f['Q'],1e-16)
 def test_fit_constraints(self):
    # Artificial finite-part B values test the algebraic endpoint constraints only.
    t,w=np.polynomial.legendre.leggauss(16);t=(t+1)/2;cache={'z':(t/(1-t)).tolist(),'weights':(w/2/(1-t)**2).tolist(),'b':np.zeros(16).tolist()}
    ch,c1=values(0,cache);chf,c1f=values(1,cache);a=2**(-4/3)
    self.assertAlmostEqual(chf,a*ch,places=14);self.assertAlmostEqual(c1f,a*(c1+2*np.log(a)*ch),places=14)
    r=np.geomspace(.001,1e8,20);p=[-.018,0.,.7,.06,3.]
    np.testing.assert_allclose(spin_base(r,np.ones(len(r)),p,cache),endpoint(a*r,p,c1),rtol=1e-13)
    np.testing.assert_allclose(spin_base(r,np.zeros(len(r)),p,cache),endpoint(r,p,c1),rtol=1e-13)
    self.assertTrue(np.all(design(r,np.zeros(len(r)))==0));self.assertTrue(np.all(design(r,np.ones(len(r)))==0))
    from ueg_exchange.constants import asymptotic_kite
    # Difference from the three-term LD series must scale no slower than 1/r.
    rr=np.array([1e12,1e16]);d=(endpoint(rr,p,c1)-asymptotic_kite(rr))*rr
    self.assertLess(abs(d[1]),max(abs(d[0])*2,1e-8))
if __name__=='__main__':unittest.main(verbosity=2)
