"""Additional regression tests for replicate splitting and density derivatives."""
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from common import *
from plan import build
from followup_report import estimate,previous_value
import reviewer_numerics as rn


class Followup(unittest.TestCase):
    def test_axis_blocks_preserve_replicates(self):
        kw=dict(rs=10,power=4,nq=4,order=3,nk=4,qmin=1e-5,qmax=1e5)
        whole=rn.energy(**kw,reps=4,seed=27182)
        parts=[rn.energy(**kw,reps=2,seed=27182+j) for j in [0,2]]
        np.testing.assert_array_equal(whole['replicates'],np.concatenate([p['replicates'] for p in parts]))

    def test_axis_full_replica_coverage(self):
        cfg=load(ROOT/'inputs/51_axis_resolution.json');tasks=build(cfg);seen={}
        for t in tasks:
            key=(t['group'],t['rs'],t['setting_id'])
            seen.setdefault(key,[]).extend(range(t['replicate_start'],t['replicate_start']+t['replicates']))
            self.assertEqual(t['seed']-t['replicate_start'],cfg['seed_base']+t['gid']*10000000)
        for key,replicas in seen.items():
            t=next(t for t in tasks if (t['group'],t['rs'],t['setting_id'])==key)
            self.assertEqual(replicas,list(range(t['total_replicates'])))

    def test_density_stencils(self):
        cfg=load(ROOT/'inputs/34_density_curvature.json');rs=np.array(cfg['groups'][0]['rs'])
        for center in [60,70,75]:
            for h in [.005,.01,.02]:
                k=np.arange(-2,3);target=center*np.exp(k*h)
                for r in target:self.assertLess(np.min(abs(rs-r))/r,1e-13)
                d1=np.array([1,-8,0,8,-1])/(12*h);d2=np.array([-1,16,-30,16,-1])/(12*h*h)
                # E(x)=2+3x+5x^2+7x^3+11x^4: K(0)=(10-9)/9.
                x=k*h;y=2+3*x+5*x*x+7*x**3+11*x**4
                self.assertAlmostEqual(float(np.dot((d2-3*d1)/9,y-y[2])),1/9,places=9)

    def test_baseline_references_available(self):
        for r in [1,10,60,1e6,1e8]:
            value=previous_value(r);self.assertTrue(np.isfinite(value['mean_ry']));self.assertGreater(value['se_ry'],0)

    def test_paired_error(self):
        # Removing a shared point fluctuation must remove its contribution to error.
        rng=np.random.default_rng(7);base=rng.normal(size=(8,2));d=(base+3)-base
        mean,se=estimate(d);self.assertAlmostEqual(mean,6);self.assertLess(se,1e-14)


if __name__=='__main__':unittest.main(verbosity=2)
