#!/bin/sh
#$ -S /bin/sh
#$ -pe def_slot 16
#$ -cwd
#$ -j y
#$ -q mjobs.q

set -eu
if [ "$#" -ne 1 ]; then
    echo 'Usage: qsub run_hpc_age.sh inputs/14_low_density_map4.json' >&2
    exit 2
fi
test -f scripts/plan.py || { echo 'Submit from BX14974_followup directory.' >&2; exit 2; }
input=$1
test -f "$input" || { echo "Missing input: $input" >&2; exit 2; }
venv=${BX_VENV:-../BX14974_additional_calculations/.venv}
test -f "$venv/bin/activate" || { echo "Set BX_VENV to an existing venv, or create .venv and use qsub -v BX_VENV=.venv ..." >&2; exit 2; }
. "$venv/bin/activate"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
workers=${NSLOTS:-16}
case "$workers" in ''|*[!0-9]*|0) echo 'Invalid NSLOTS' >&2; exit 2;; esac
if [ -n "${PE_HOSTFILE:-}" ]; then
    echo 'Allocated hosts and slots:'
    cat "$PE_HOSTFILE"
    test "$(awk '{print $1}' "$PE_HOSTFILE" | sort -u | wc -l)" -eq 1 || {
        echo 'Multiple hosts: this ProcessPool job requires one host via def_slot.' >&2; exit 2;
    }
fi
name=$(basename "$input" .json)
run=runs/hpc_$name
mkdir -p "$run"
# Planning errors propagate directly; piping through tee must not hide a Python failure.
python scripts/plan.py "$input" --run "$run"
{
    echo "START: $input; workers=$workers"
    date
    python scripts/run.py --run "$run" --workers "$workers"
    python scripts/analyze.py --run "$run"
    python scripts/followup_report.py --run "$run"
    case "$name" in
        33_*) python scripts/polarization.py --run "$run" --group spin_precision --bootstrap 1000 ;;
    esac
    echo 'RUN COMPLETE'
    date
} >> "$run/execution.log" 2>&1
echo "Completed: $run; see execution.log and analysis/"
