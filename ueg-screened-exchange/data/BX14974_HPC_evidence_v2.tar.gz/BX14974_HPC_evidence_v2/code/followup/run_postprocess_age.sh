#!/bin/sh
#$ -S /bin/sh
#$ -pe def_slot 16
#$ -cwd
#$ -j y
#$ -q mjobs.q
set -eu
test -f scripts/postprocess.py || { echo 'Submit from BX14974_followup directory.' >&2; exit 2; }
venv=${BX_VENV:-../BX14974_additional_calculations/.venv}
test -f "$venv/bin/activate" || { echo 'Set BX_VENV to the existing Python venv.' >&2; exit 2; }
. "$venv/bin/activate"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
if [ -n "${PE_HOSTFILE:-}" ]; then
    cat "$PE_HOSTFILE"
    test "$(awk '{print $1}' "$PE_HOSTFILE" | sort -u | wc -l)" -eq 1 || { echo 'def_slot must allocate one host.' >&2; exit 2; }
fi
run=runs/hpc_41_fit_and_coefficients
mkdir -p "$run"
python scripts/postprocess.py --run "$run" --workers "${NSLOTS:-16}" --orders 80 160 240 --bootstrap 500 >> "$run/execution.log" 2>&1
echo "Completed: $run"
